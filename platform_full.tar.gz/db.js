/**
 * db.js — 모든 데이터베이스 접근을 이 한 모듈에 격리.
 * (Autoscale 배포에서 Postgres로 바꿔야 할 때 이 파일만 교체하면 되도록.)
 *
 * SQLite 파일: data/app.db  /  업로드: data/uploads/
 */
'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const CONTENT_DIR = path.join(ROOT, 'content');
const DB_PATH = path.join(DATA_DIR, 'app.db');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const TOTAL_DAYS = 20;
const WEEKS = [
  { week: 1, label: '1주차 · 회사 세우기', days: [1, 2, 3, 4, 5] },
  { week: 2, label: '2주차 · 매일 저절로', days: [6, 7, 8, 9, 10] },
  { week: 3, label: '3주차 · 부서 늘리기', days: [11, 12, 13, 14, 15] },
  { week: 4, label: '4주차 · 내 회사로', days: [16, 17, 18, 19, 20] },
];

// ───────────────────────── 스키마 ─────────────────────────
db.exec(`
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  used_by INTEGER,
  used_at TEXT
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nickname TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  code_id INTEGER,
  cheer_message TEXT,
  consent_at TEXT,
  is_graduate INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS consents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  version TEXT NOT NULL,
  agreed_refund INTEGER NOT NULL,
  agreed_copy INTEGER NOT NULL,
  agreed_privacy INTEGER NOT NULL,
  ip TEXT,
  user_agent TEXT,
  agreed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS missions (
  day INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  body_md TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  edited_by_admin INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day INTEGER NOT NULL,
  memo TEXT,
  status TEXT NOT NULL DEFAULT 'submitted', -- submitted | approved | revision
  comment TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  reviewed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_sub_user_day ON submissions(user_id, day, id);
CREATE INDEX IF NOT EXISTS idx_sub_status ON submissions(status, created_at);

CREATE TABLE IF NOT EXISTS submission_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  submission_id INTEGER NOT NULL,
  filename TEXT NOT NULL UNIQUE,
  original_name TEXT,
  size INTEGER,
  FOREIGN KEY(submission_id) REFERENCES submissions(id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  message TEXT NOT NULL,
  link TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  read_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS access_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day INTEGER NOT NULL,
  viewed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  user_agent TEXT,
  first_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(user_id, device_id)
);
CREATE TABLE IF NOT EXISTS login_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  device_id TEXT,
  ip TEXT,
  user_agent TEXT,
  result TEXT NOT NULL, -- ok | blocked_device | wrong_password
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_login_events_user ON login_events(user_id, created_at);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS admin_notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  text TEXT NOT NULL,
  sent INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- 코스(과정): 정규과정 1개(평생·자동 최신본) + 옵션 과정(플랫폼별 별도 결제). 2026-09-13 수강권 모델
CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'regular', -- regular | option
  total_days INTEGER NOT NULL DEFAULT 20,
  trial_days INTEGER NOT NULL DEFAULT 0, -- 체험 계정이 볼 수 있는 Day 수 (정규과정 3)
  purchase_url TEXT,                      -- "결제하고 이어서 하기" 버튼이 여는 주소(리틀리)
  is_active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  version_note TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS course_missions (
  course_id INTEGER NOT NULL,
  day INTEGER NOT NULL,
  title TEXT NOT NULL,
  body_md TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  edited_by_admin INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(course_id, day)
);
-- 수강권: 계정이 아니라 수강권에 권한을 붙인다 (체험 trial / 결제 paid)
CREATE TABLE IF NOT EXISTS enrollments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  course_id INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'trial', -- trial | paid
  cohort TEXT,
  code_id INTEGER,
  memo TEXT,
  granted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(user_id, course_id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS cohorts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL DEFAULT 1,
  name TEXT NOT NULL UNIQUE,
  capacity INTEGER NOT NULL DEFAULT 30,
  status TEXT NOT NULL DEFAULT 'open', -- open | closed
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  course_id INTEGER NOT NULL,
  kind TEXT NOT NULL, -- stalled
  sent_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  sess TEXT NOT NULL,
  expired INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expired ON sessions(expired);
`);

// ───────────────────────── 미션 시드 ─────────────────────────
/** 본문 첫 `# 제목`에서 제목 추출. "Day N — " 접두어는 화면에서 따로 붙이므로 제거. */
function extractTitle(md, day) {
  const m = md.match(/^#\s+(.+)$/m);
  if (!m) return `Day ${day}`;
  return m[1].trim().replace(/^Day\s*\d+\s*[—–:\-]\s*/i, '').trim() || `Day ${day}`;
}

// 기존 DB에 feedback 컬럼이 없으면 추가 (2026-09-12: 제출 시 교재 개선 피드백 수집)
try {
  const cols = db.prepare("PRAGMA table_info('submissions')").all().map((c) => c.name);
  if (!cols.includes('feedback')) db.exec('ALTER TABLE submissions ADD COLUMN feedback TEXT');
  if (!cols.includes('feedback_json')) db.exec('ALTER TABLE submissions ADD COLUMN feedback_json TEXT');
} catch (e) { console.error('[migration feedback]', e); }

// 2026-09-13 수강권 모델 마이그레이션: 컬럼 추가 + 정규과정 코스 시드 + 기존 미션·사용자 옮기기
try {
  const addCol = (table, col, def) => { const cols = db.prepare(`PRAGMA table_info('${table}')`).all().map((c) => c.name); if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`); };
  addCol('codes', 'course_id', 'INTEGER NOT NULL DEFAULT 1');
  addCol('codes', 'cohort', 'TEXT');
  addCol('codes', 'memo', 'TEXT');
  addCol('submissions', 'course_id', 'INTEGER NOT NULL DEFAULT 1');
  addCol('access_logs', 'course_id', 'INTEGER NOT NULL DEFAULT 1');
  addCol('users', 'cheer_hidden', 'INTEGER NOT NULL DEFAULT 0');
  addCol('users', 'code_fails', 'INTEGER NOT NULL DEFAULT 0');
  addCol('users', 'code_lock_until', 'TEXT');
  if (!db.prepare('SELECT id FROM courses WHERE id = 1').get()) {
    db.prepare(`INSERT INTO courses(id, slug, title, kind, total_days, trial_days, purchase_url, sort) VALUES(1, 'main', 'AI 직원 회사 만들기 20일', 'regular', 20, 3, '', 0)`).run();
  }
  if (!db.prepare('SELECT COUNT(*) AS n FROM course_missions').get().n && db.prepare('SELECT COUNT(*) AS n FROM missions').get().n) {
    db.exec('INSERT OR IGNORE INTO course_missions(course_id, day, title, body_md, updated_at, edited_by_admin) SELECT 1, day, title, body_md, updated_at, edited_by_admin FROM missions');
  }
  if (!db.prepare('SELECT id FROM cohorts WHERE name = ?').get('1기')) db.prepare('INSERT INTO cohorts(course_id, name, capacity) VALUES(1, ?, 30)').run('1기');
  // 코드로 가입한 기존 사용자 = 정규과정 결제 수강권(1기)
  db.exec(`INSERT OR IGNORE INTO enrollments(user_id, course_id, kind, cohort, code_id, granted_at)
    SELECT u.id, 1, 'paid', '1기', u.code_id, u.created_at FROM users u WHERE u.code_id IS NOT NULL`);
} catch (e) { console.error('[migration courses]', e); }

// 관리자(대표)에게 보낸 텔레그램 알림 기록 — 로디가 대화창에 같은 내용을 다시 띄우기 위해 (2026-09-12 대표 지시)
function addAdminNotice(text, sent) {
  return db.prepare('INSERT INTO admin_notices(text, sent) VALUES(?, ?)').run(String(text).slice(0, 4000), sent ? 1 : 0).lastInsertRowid;
}
function listAdminNotices(sinceId, limit) {
  return db.prepare('SELECT id, text, sent, created_at FROM admin_notices WHERE id > ? ORDER BY id ASC LIMIT ?').all(Number(sinceId) || 0, Math.min(Number(limit) || 100, 500));
}

// 교재 파일 → DB. 정규과정(main)은 content/dayNN.md, 옵션 과정은 content/<slug>/dayNN.md
function seedMissions() {
  const get = db.prepare('SELECT day, edited_by_admin FROM course_missions WHERE course_id = ? AND day = ?');
  const upsert = db.prepare(`INSERT INTO course_missions(course_id, day, title, body_md) VALUES(?,?,?,?)
    ON CONFLICT(course_id, day) DO UPDATE SET title=excluded.title, body_md=excluded.body_md, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')`);
  const tx = db.transaction(() => {
    for (const c of listCourses(false)) {
      const dir = c.slug === 'main' ? CONTENT_DIR : path.join(CONTENT_DIR, c.slug);
      for (let day = 1; day <= c.total_days; day++) {
        const file = path.join(dir, `day${String(day).padStart(2, '0')}.md`);
        let md;
        if (fs.existsSync(file)) md = fs.readFileSync(file, 'utf8');
        else md = `# Day ${day} — (준비 중)\n\n이 미션은 곧 공개됩니다.`;
        const row = get.get(c.id, day);
        // 관리자가 편집한 미션은 파일로 덮어쓰지 않는다 (DB 우선)
        if (row && row.edited_by_admin) continue;
        upsert.run(c.id, day, extractTitle(md, day), md);
      }
    }
  });
  tx();
}

// ───────────────────────── 코스 · 수강권 · 기수 (2026-09-13) ─────────────────────────
function listCourses(activeOnly = true) {
  return db.prepare(`SELECT * FROM courses ${activeOnly ? 'WHERE is_active = 1' : ''} ORDER BY sort, id`).all();
}
function getCourse(idOrSlug) {
  if (/^\d+$/.test(String(idOrSlug))) return db.prepare('SELECT * FROM courses WHERE id = ?').get(Number(idOrSlug));
  return db.prepare('SELECT * FROM courses WHERE slug = ?').get(String(idOrSlug));
}
function createCourse({ slug, title, kind, totalDays, trialDays, purchaseUrl }) {
  const r = db.prepare('INSERT INTO courses(slug, title, kind, total_days, trial_days, purchase_url, sort) VALUES(?,?,?,?,?,?, (SELECT COALESCE(MAX(sort),0)+1 FROM courses))')
    .run(slug, title, kind === 'regular' ? 'regular' : 'option', Number(totalDays) || 10, Number(trialDays) || 0, purchaseUrl || '');
  return getCourse(r.lastInsertRowid);
}
function updateCourse(id, { title, totalDays, trialDays, purchaseUrl, isActive, versionNote }) {
  db.prepare('UPDATE courses SET title = ?, total_days = ?, trial_days = ?, purchase_url = ?, is_active = ?, version_note = ? WHERE id = ?')
    .run(title, Number(totalDays) || 1, Number(trialDays) || 0, purchaseUrl || '', isActive ? 1 : 0, versionNote || null, id);
}
function enrollmentsOf(userId) {
  return db.prepare(`SELECT e.*, c.slug, c.title, c.kind AS course_kind, c.total_days, c.trial_days, c.is_active
    FROM enrollments e JOIN courses c ON c.id = e.course_id WHERE e.user_id = ? AND c.is_active = 1 ORDER BY c.sort, c.id`).all(userId);
}
function getEnrollment(userId, courseId) {
  return db.prepare('SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?').get(userId, courseId);
}
// 수강권 부여: 체험(trial)은 이미 결제(paid)가 있으면 건드리지 않음. 결제는 체험을 덮어씀(승격).
function grantEnrollment({ userId, courseId, kind, cohort, codeId, memo }) {
  const cur = getEnrollment(userId, courseId);
  if (cur && cur.kind === 'paid' && kind !== 'paid') return cur;
  db.prepare(`INSERT INTO enrollments(user_id, course_id, kind, cohort, code_id, memo) VALUES(?,?,?,?,?,?)
    ON CONFLICT(user_id, course_id) DO UPDATE SET kind = excluded.kind, cohort = COALESCE(excluded.cohort, enrollments.cohort), code_id = COALESCE(excluded.code_id, enrollments.code_id), memo = COALESCE(excluded.memo, enrollments.memo), granted_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`)
    .run(userId, courseId, kind === 'paid' ? 'paid' : 'trial', cohort || null, codeId || null, memo || null);
  return getEnrollment(userId, courseId);
}
function revokeEnrollment(userId, courseId) { db.prepare('DELETE FROM enrollments WHERE user_id = ? AND course_id = ?').run(userId, courseId); }
const CODE_MAX_FAILS = 5, CODE_LOCK_MIN = 10;
// 설정 화면에서 코드 입력 → 그 코드가 여는 코스의 결제 수강권. 5회 실패 시 10분 잠금(추측 공격 방지).
// 카톡에서 복사한 코드는 공백·줄바꿈이 섞이고 하이픈이 빠지기도 함 → 영숫자만 남기고 SJ1-XXXX-XXXX-XXXX 로 재조립 (2026-09-14)
function normalizeCode(raw) {
  const a = String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (a.length < 4) return a;
  return a.slice(0, 3) + '-' + a.slice(3).match(/.{1,4}/g).join('-');   // 앞 3자(SJ1) + 4자씩
}
function redeemCode(userId, rawCode) {
  const u = findUserById(userId);
  if (u.code_lock_until && Date.parse(u.code_lock_until) > Date.now()) return { ok: false, error: 'LOCKED', until: u.code_lock_until };
  const code = normalizeCode(rawCode);
  const c = db.prepare('SELECT * FROM codes WHERE code = ?').get(code);
  if (c && c.used_by === userId) return { ok: false, error: 'MINE' };      // 본인이 이미 쓴 코드를 다시 넣는 흔한 실수 → 잠금 카운트 안 함
  if (!c || c.used_by) {
    const fails = (u.code_fails || 0) + 1;
    const lock = fails >= CODE_MAX_FAILS ? new Date(Date.now() + CODE_LOCK_MIN * 60000).toISOString() : null;
    db.prepare('UPDATE users SET code_fails = ?, code_lock_until = ? WHERE id = ?').run(lock ? 0 : fails, lock, userId);
    return { ok: false, error: c ? 'USED' : 'INVALID', left: lock ? 0 : CODE_MAX_FAILS - fails, until: lock };
  }
  const tx = db.transaction(() => {
    db.prepare(`UPDATE codes SET used_by = ?, used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ? AND used_by IS NULL`).run(userId, c.id);
    db.prepare('UPDATE users SET code_fails = 0, code_lock_until = NULL WHERE id = ?').run(userId);
    return grantEnrollment({ userId, courseId: c.course_id || 1, kind: 'paid', cohort: c.cohort, codeId: c.id, memo: c.memo });
  });
  const e = tx();
  return { ok: true, enrollment: e, course: getCourse(e.course_id), code: c };
}
function listCohorts() {
  return db.prepare(`SELECT co.*, c.title AS course_title,
    (SELECT COUNT(*) FROM enrollments e WHERE e.cohort = co.name AND e.course_id = co.course_id AND e.kind = 'paid') AS enrolled,
    (SELECT COUNT(*) FROM codes k WHERE k.cohort = co.name AND k.course_id = co.course_id AND k.used_by IS NULL) AS codes_free
    FROM cohorts co JOIN courses c ON c.id = co.course_id ORDER BY co.id`).all();
}
function createCohort({ courseId, name, capacity }) { db.prepare('INSERT INTO cohorts(course_id, name, capacity) VALUES(?,?,?)').run(courseId || 1, name, Number(capacity) || 30); }
function setCohortStatus(id, status) { db.prepare('UPDATE cohorts SET status = ? WHERE id = ?').run(status === 'closed' ? 'closed' : 'open', id); }
// 다짐·응원 메시지: 숨김 아닌 모든 수강생의 한 줄 (메인 화면 무작위 노출)
function listCheers() {
  return db.prepare(`SELECT u.id, u.nickname, u.cheer_message, (SELECT cohort FROM enrollments e WHERE e.user_id = u.id AND e.kind = 'paid' ORDER BY e.id LIMIT 1) AS cohort
    FROM users u WHERE u.cheer_message IS NOT NULL AND TRIM(u.cheer_message) <> '' AND u.cheer_hidden = 0`).all();
}
function setCheer(userId, msg) { db.prepare('UPDATE users SET cheer_message = ? WHERE id = ?').run(msg || null, userId); }
function setCheerHidden(userId, hidden) { db.prepare('UPDATE users SET cheer_hidden = ? WHERE id = ?').run(hidden ? 1 : 0, userId); }
// 3일 무제출 리마인드 대상: 결제 수강권 + 정체 3일 이상 + 최근 3일 안에 리마인드 안 보냄 + 미완주
function usersNeedingReminder() {
  const out = [];
  const since = new Date(Date.now() - 3 * 86400000).toISOString();
  for (const e of db.prepare(`SELECT e.* FROM enrollments e WHERE e.kind = 'paid'`).all()) {
    const u = findUserById(e.user_id); if (!u || !u.consent_at) continue;
    const c = getCourse(e.course_id); if (!c) continue;
    const p = progressOf(u, c, e);
    if (!p.stalled || p.completed) continue;
    const recent = db.prepare('SELECT id FROM reminders WHERE user_id = ? AND course_id = ? AND sent_at >= ?').get(u.id, c.id, since);
    if (recent) continue;
    out.push({ user: u, course: c, p });
  }
  return out;
}
function recordReminder(userId, courseId) { db.prepare("INSERT INTO reminders(user_id, course_id, kind) VALUES(?,?,'stalled')").run(userId, courseId); }

// ───────────────────────── 입장 코드 ─────────────────────────
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 헷갈리는 0/O, 1/I 제외
// 16자 무작위(대문자+숫자, 0/O·1/I 제외): SJ1-7K3M-QW9P-2ZDX — 추측·분석으로 유추 불가 (2026-09-13 대표 지시)
function randomCode() {
  const bytes = require('crypto').randomBytes(12);
  let body = '';
  for (let i = 0; i < 12; i++) body += CODE_CHARS[bytes[i] % CODE_CHARS.length];
  return 'SJ1-' + body.slice(0, 4) + '-' + body.slice(4, 8) + '-' + body.slice(8, 12);
}

function createCodes(count, opts = {}) {
  const ins = db.prepare('INSERT OR IGNORE INTO codes(code, course_id, cohort, memo) VALUES(?,?,?,?)');
  const made = [];
  const tx = db.transaction(() => {
    while (made.length < count) {
      const c = randomCode();
      const r = ins.run(c, opts.courseId || 1, opts.cohort || null, opts.memo || null);
      if (r.changes) made.push(c);
    }
  });
  tx();
  return made;
}

function listCodes() {
  return db.prepare(`SELECT c.*, u.nickname AS used_by_nickname, co.title AS course_title
    FROM codes c LEFT JOIN users u ON u.id = c.used_by LEFT JOIN courses co ON co.id = c.course_id
    ORDER BY c.id DESC`).all();
}

function findCode(code) {
  return db.prepare('SELECT * FROM codes WHERE code = ?').get(String(code || '').trim().toUpperCase());
}

// ───────────────────────── 사용자 ─────────────────────────
function findUserByNickname(nick) {
  return db.prepare('SELECT * FROM users WHERE nickname = ? COLLATE NOCASE').get(nick);   // 아이폰이 첫 글자를 대문자로 바꿔도 로그인되게 (2026-09-14)
}
function findUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

// 가입 = 체험 계정(정규과정 Day 1~3). 코드가 같이 오면 그 자리에서 결제 수강권까지.
function createUser({ nickname, passwordHash, cheerMessage, code }) {
  const tx = db.transaction(() => {
    let c = null;
    if (code) {
      c = db.prepare('SELECT * FROM codes WHERE code = ? AND used_by IS NULL').get(code);
      if (!c) throw new Error('CODE_INVALID');
    }
    const r = db.prepare('INSERT INTO users(nickname, password_hash, code_id, cheer_message) VALUES(?,?,?,?)')
      .run(nickname, passwordHash, c ? c.id : null, cheerMessage || null);
    const userId = r.lastInsertRowid;
    const main = getCourse('main');
    grantEnrollment({ userId, courseId: main.id, kind: 'trial' });
    if (c) {
      db.prepare(`UPDATE codes SET used_by = ?, used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(userId, c.id);
      grantEnrollment({ userId, courseId: c.course_id || main.id, kind: 'paid', cohort: c.cohort, codeId: c.id, memo: c.memo });
    }
    return findUserById(userId);
  });
  return tx();
}
const createUserWithCode = createUser;

function touchLogin(userId) {
  db.prepare(`UPDATE users SET last_login_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(userId);
}

function recordConsent({ userId, version, refund, copy, privacy, ip, userAgent }) {
  const tx = db.transaction(() => {
    db.prepare(`INSERT INTO consents(user_id, version, agreed_refund, agreed_copy, agreed_privacy, ip, user_agent)
      VALUES(?,?,?,?,?,?,?)`).run(userId, version, refund ? 1 : 0, copy ? 1 : 0, privacy ? 1 : 0, ip || null, userAgent || null);
    db.prepare(`UPDATE users SET consent_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(userId);
  });
  tx();
}

function setPassword(userId, passwordHash) {
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, userId);
}

function setGraduate(userId, flag) {
  db.prepare('UPDATE users SET is_graduate = ? WHERE id = ?').run(flag ? 1 : 0, userId);
}

function listUsers() {
  return db.prepare('SELECT * FROM users ORDER BY id ASC').all();
}

// ───────────────────────── 미션 ─────────────────────────
function getMission(day, courseId = 1) {
  return db.prepare('SELECT * FROM course_missions WHERE course_id = ? AND day = ?').get(courseId, day);
}
function listMissions(courseId = 1) {
  return db.prepare('SELECT course_id, day, title, updated_at, edited_by_admin FROM course_missions WHERE course_id = ? ORDER BY day').all(courseId);
}
function updateMission(day, title, bodyMd, courseId = 1) {
  db.prepare(`UPDATE course_missions SET title = ?, body_md = ?, edited_by_admin = 1,
    updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE course_id = ? AND day = ?`).run(title, bodyMd, courseId, day);
}

// ───────────────────────── 제출 ─────────────────────────
function latestSubmissionsByUser(userId, courseId = 1) {
  // 각 Day의 "가장 최근" 제출 1건씩
  return db.prepare(`SELECT s.* FROM submissions s
    WHERE s.user_id = ? AND s.course_id = ? AND s.id = (SELECT MAX(id) FROM submissions WHERE user_id = s.user_id AND course_id = s.course_id AND day = s.day)
    ORDER BY s.day`).all(userId, courseId);
}

function latestSubmission(userId, day, courseId = 1) {
  return db.prepare('SELECT * FROM submissions WHERE user_id = ? AND course_id = ? AND day = ? ORDER BY id DESC LIMIT 1').get(userId, courseId, day);
}

function submissionHistory(userId, day, courseId = 1) {
  const rows = db.prepare('SELECT * FROM submissions WHERE user_id = ? AND course_id = ? AND day = ? ORDER BY id DESC').all(userId, courseId, day);
  for (const r of rows) r.images = imagesOf(r.id);
  return rows;
}

function imagesOf(submissionId) {
  return db.prepare('SELECT * FROM submission_images WHERE submission_id = ? ORDER BY id').all(submissionId);
}

function createSubmission({ userId, day, memo, feedback, feedbackJson, images, courseId = 1 }) {
  const tx = db.transaction(() => {
    const r = db.prepare('INSERT INTO submissions(user_id, course_id, day, memo, feedback, feedback_json) VALUES(?,?,?,?,?,?)').run(userId, courseId, day, memo || null, feedback || null, feedbackJson || null);
    const ins = db.prepare('INSERT INTO submission_images(submission_id, filename, original_name, size) VALUES(?,?,?,?)');
    for (const im of images) ins.run(r.lastInsertRowid, im.filename, im.originalname, im.size);
    return r.lastInsertRowid;
  });
  return tx();
}

// 교재 개선 피드백(제출 때 받는 "아쉬운 점·보완할 점") 모아보기 — Day별, 최신순
// Day별 집계: 평균 난이도(1~4), 시간 분포, 응답 수
function feedbackStats() {
  const rows = db.prepare(`SELECT day, feedback_json FROM submissions WHERE feedback_json IS NOT NULL`).all();
  const by = {};
  for (const r of rows) {
    let f; try { f = JSON.parse(r.feedback_json); } catch { continue; }
    const b = (by[r.day] = by[r.day] || { n: 0, diffSum: 0, diffN: 0, hard: 0, times: {}, stuck: [] });
    b.n++;
    if (f.difficulty) { b.diffSum += f.difficulty; b.diffN++; if (f.difficulty >= 3) b.hard++; }
    if (f.time) b.times[f.time] = (b.times[f.time] || 0) + 1;
    if (f.stuck && !/^없음?$/.test(f.stuck)) b.stuck.push(f.stuck);
  }
  for (const d of Object.keys(by)) { const b = by[d]; b.avgDifficulty = b.diffN ? Math.round((b.diffSum / b.diffN) * 10) / 10 : null; b.hardRate = b.diffN ? Math.round((b.hard / b.diffN) * 100) : null; }
  return by;
}

function allCourseFeedback() {
  return db.prepare(`SELECT s.id, s.day, s.feedback, s.feedback_json, s.created_at, u.nickname
    FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.feedback IS NOT NULL AND TRIM(s.feedback) <> '' ORDER BY s.day, s.created_at DESC`).all();
}

function getSubmission(id) {
  const s = db.prepare(`SELECT s.*, u.nickname, c.slug AS course_slug, c.title AS course_title FROM submissions s JOIN users u ON u.id = s.user_id LEFT JOIN courses c ON c.id = s.course_id WHERE s.id = ?`).get(id);
  if (s) s.images = imagesOf(s.id);
  return s;
}

function findImage(filename) {
  return db.prepare(`SELECT i.*, s.user_id FROM submission_images i JOIN submissions s ON s.id = i.submission_id WHERE i.filename = ?`).get(filename);
}

function reviewSubmission({ id, status, comment }) {
  const tx = db.transaction(() => {
    const s = db.prepare('SELECT * FROM submissions WHERE id = ?').get(id);
    if (!s) throw new Error('NOT_FOUND');
    db.prepare(`UPDATE submissions SET status = ?, comment = ?, reviewed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`)
      .run(status, comment || null, id);
    const course = getCourse(s.course_id || 1);
    const prefix = course && course.slug !== 'main' ? `/c/${course.slug}` : '';
    const enr = getEnrollment(s.user_id, course ? course.id : 1); const total = course ? course.total_days : 20;
    const trialEnd = enr && enr.kind === 'trial' && s.day >= (course ? course.trial_days : 3);
    let msg, link = `${prefix}/day/${s.day}`;
    if (status !== 'approved') msg = `Day ${s.day} 미션에 보완 요청이 왔어요. 코멘트를 확인하고 다시 제출해 주세요.`;
    else if (s.day >= total) { msg = `Day ${s.day} 승인 — 20일 완주, 수료입니다! 대시보드에서 수료 화면을 확인해 주세요.`; link = prefix || '/'; }
    else if (trialEnd) { msg = `Day ${s.day} 미션이 승인되었습니다. 무료 체험은 여기까지예요 — Day ${s.day + 1}부터는 결제 후 입장 코드를 넣으면 이어집니다.`; link = prefix || '/'; }
    else { msg = `Day ${s.day} 미션이 승인되었습니다. Day ${s.day + 1}이 열렸어요!`; link = `${prefix}/day/${s.day + 1}`; }
    db.prepare('INSERT INTO notifications(user_id, message, link) VALUES(?,?,?)').run(s.user_id, msg, link);
    return db.prepare('SELECT * FROM submissions WHERE id = ?').get(id);
  });
  return tx();
}

function pendingQueue() {
  const rows = db.prepare(`SELECT s.*, u.nickname, c.slug AS course_slug, c.title AS course_title FROM submissions s JOIN users u ON u.id = s.user_id LEFT JOIN courses c ON c.id = s.course_id
    WHERE s.status = 'submitted' ORDER BY s.created_at ASC, s.id ASC`).all();
  for (const r of rows) r.images = imagesOf(r.id);
  return rows;
}

function recentReviewed(limit = 30) {
  return db.prepare(`SELECT s.*, u.nickname FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.status <> 'submitted' ORDER BY s.reviewed_at DESC LIMIT ?`).all(limit);
}

function allSubmissions() {
  return db.prepare(`SELECT s.*, u.nickname,
    (SELECT COUNT(*) FROM submission_images i WHERE i.submission_id = s.id) AS image_count
    FROM submissions s JOIN users u ON u.id = s.user_id ORDER BY s.id`).all();
}

function recentFeedbackForUser(userId, limit = 5) {
  return db.prepare(`SELECT * FROM submissions WHERE user_id = ? AND status <> 'submitted'
    ORDER BY reviewed_at DESC LIMIT ?`).all(userId, limit);
}

// ───────────────────────── 알림 ─────────────────────────
function unreadNotifications(userId) {
  return db.prepare('SELECT * FROM notifications WHERE user_id = ? AND read_at IS NULL ORDER BY id DESC').all(userId);
}
function markNotificationsRead(userId) {
  db.prepare(`UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND read_at IS NULL`).run(userId);
}
// PC에서 대시보드를 한 번 열면 폰에서 알림이 사라지는 문제 → 대시보드에서는 하루 지난 것만, 해당 Day 페이지를 열면 그 Day 알림만 읽음 처리 (2026-09-14)
function markOldNotificationsRead(userId, hours = 24) {
  db.prepare(`UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND read_at IS NULL AND created_at < strftime('%Y-%m-%dT%H:%M:%fZ','now', ?)`).run(userId, `-${hours} hours`);
}
function markNotificationsReadByLink(userId, link) {
  db.prepare(`UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND read_at IS NULL AND link = ?`).run(userId, link);
}

function logAccess(userId, day, courseId = 1) {
  db.prepare('INSERT INTO access_logs(user_id, course_id, day) VALUES(?,?,?)').run(userId, courseId, day);
}

// ───────────────────────── 운영 설정 (재시작 없이 관리자 화면에서 바꾸는 값: 문의 링크·문구) ─────────────────────────
function getSetting(key, fallback = '') {
  const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  db.prepare(`INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`).run(key, String(value || ''));
}

// ───────────────────────── 기기 제한 · 로그인 기록 (계정 공유 방지, 2026-09-11 대표 결정: 기기 2대) ─────────────────────────
const MAX_DEVICES = Number(process.env.MAX_DEVICES) || 3;   // 폰(카톡 안 브라우저) + 폰 크롬 + PC 가 각각 다른 '기기'로 잡혀서 2대는 정상 사용자도 막힘 (2026-09-14)
function listDevices(userId) {
  return db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY first_seen').all(userId);
}
// 로그인 시 호출: 등록된 기기면 갱신, 자리가 남으면 등록, 꽉 찼으면 차단(ok:false)
function registerDevice(userId, deviceId, userAgent) {
  const found = db.prepare('SELECT id FROM devices WHERE user_id = ? AND device_id = ?').get(userId, deviceId);
  if (found) {
    db.prepare(`UPDATE devices SET last_seen = strftime('%Y-%m-%dT%H:%M:%fZ','now'), user_agent = ? WHERE id = ?`).run(userAgent || null, found.id);
    return { ok: true, count: listDevices(userId).length };
  }
  const count = listDevices(userId).length;
  if (count >= MAX_DEVICES) return { ok: false, count };
  db.prepare('INSERT INTO devices(user_id, device_id, user_agent) VALUES(?,?,?)').run(userId, deviceId, userAgent || null);
  return { ok: true, count: count + 1, isNew: true };
}
function resetDevices(userId) { db.prepare('DELETE FROM devices WHERE user_id = ?').run(userId); }
function logLogin({ userId, deviceId, ip, userAgent, result }) {
  db.prepare('INSERT INTO login_events(user_id, device_id, ip, user_agent, result) VALUES(?,?,?,?,?)').run(userId, deviceId || null, ip || null, userAgent || null, result);
}
function addNotification(userId, message, link) {
  db.prepare('INSERT INTO notifications(user_id, message, link) VALUES(?,?,?)').run(userId, message, link || null);
}
// 최근 N일 의심 징후: 차단된 기기 시도 수, 서로 다른 IP 수, 최근 로그인 기록
function securityReport(days = 7) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const users = db.prepare('SELECT id, nickname FROM users ORDER BY id').all();
  return users.map((u) => {
    const ev = db.prepare('SELECT * FROM login_events WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC').all(u.id, since);
    const blocked = ev.filter((e) => e.result === 'blocked_device').length;
    const ips = new Set(ev.filter((e) => e.result === 'ok' && e.ip).map((e) => e.ip));
    return { user: u, devices: listDevices(u.id), blocked, distinctIps: ips.size, okLogins: ev.filter((e) => e.result === 'ok').length, lastEvents: ev.slice(0, 10),
      suspicious: blocked >= 2 || ips.size >= 4 };
  });
}
// 자동 경고: 최근 7일 차단 시도 2회 이상이면 대시보드 알림 1회(24시간 내 중복 금지)
function autoWarnSuspicious() {
  const rep = securityReport(7).filter((r) => r.blocked >= 2);
  const warned = [];
  for (const r of rep) {
    const recent = db.prepare(`SELECT id FROM notifications WHERE user_id = ? AND message LIKE '%등록되지 않은 기기%' AND created_at >= ?`).get(r.user.id, new Date(Date.now() - 86400000).toISOString());
    if (recent) continue;
    addNotification(r.user.id, `등록되지 않은 기기에서 로그인 시도가 ${r.blocked}회 있었습니다. 이 계정은 본인 1인 · 기기 ${MAX_DEVICES}대까지 쓸 수 있어요. 카톡 안에서 링크를 열면 새 기기로 잡힐 수 있으니, 폰에서는 크롬(또는 사파리)으로 여는 걸 추천합니다. 기기를 바꾸셨거나 막히면 문의 주세요 — 바로 풀어드립니다.`, null);
    warned.push(r.user.nickname);
  }
  return warned;
}

// ───────────────────────── 진행 계산 ─────────────────────────
/**
 * 사용자 진행 상태 요약: 잠금/승인/진행률/주차/정체 일수
 */
function progressOf(user, course, enrollment) {
  course = course || getCourse('main');
  if (enrollment === undefined) enrollment = getEnrollment(user.id, course.id) || null;
  const total = course.total_days;
  // 수강권이 여는 범위: 결제 = 전부, 체험 = trial_days, 없음 = 0
  const maxDay = user.is_graduate ? total : (!enrollment ? 0 : (enrollment.kind === 'paid' ? total : course.trial_days));
  const latest = latestSubmissionsByUser(user.id, course.id);
  const byDay = new Map(latest.map((s) => [s.day, s]));
  const approvedDays = new Set(latest.filter((s) => s.status === 'approved').map((s) => s.day));

  const days = [];
  for (let d = 1; d <= total; d++) {
    const s = byDay.get(d) || null;
    const seqOk = user.is_graduate ? true : d === 1 || approvedDays.has(d - 1);
    const paywalled = d > maxDay;                       // 순서와 무관하게 수강권 밖 → "결제하고 이어서 하기"
    const unlocked = seqOk && !paywalled;
    days.push({ day: d, unlocked, paywalled, submission: s, status: s ? s.status : (unlocked ? 'open' : 'locked') });
  }

  const approvedCount = approvedDays.size;
  const percent = Math.round((approvedCount / total) * 100);
  const weekDefs = course.slug === 'main' && total === TOTAL_DAYS ? WEEKS
    : Array.from({ length: Math.ceil(total / 5) }, (_, i) => ({ week: i + 1, label: `${i + 1}주차`, days: Array.from({ length: Math.min(5, total - i * 5) }, (_, k) => i * 5 + k + 1) }));
  const weeks = weekDefs.map((w) => {
    const done = w.days.filter((d) => approvedDays.has(d)).length;
    return { ...w, done, total: w.days.length, percent: Math.round((done / w.days.length) * 100) };
  });

  // 오늘 미션 = 아직 승인되지 않은 가장 낮은 Day (열려 있는 것)
  const today = days.find((d) => d.status !== 'approved' && d.unlocked) || null;
  const completed = approvedCount >= total;
  // 체험이 끝난 상태: 열 수 있는 Day를 전부 승인받았고 다음이 결제 벽
  const trialDone = !!enrollment && enrollment.kind === 'trial' && !completed && maxDay < total && days.slice(0, maxDay).every((d) => d.status === 'approved');

  // 정체: 마지막 승인 시각(없으면 동의/가입 시각) 이후 경과 일수
  const lastApproved = latest.filter((s) => s.status === 'approved' && s.reviewed_at)
    .sort((a, b) => (a.reviewed_at < b.reviewed_at ? 1 : -1))[0];
  const lastSubmitted = db.prepare('SELECT MAX(created_at) AS t FROM submissions WHERE user_id = ? AND course_id = ?').get(user.id, course.id).t;
  // 정체 기준 시각 = 마지막 승인 / 마지막 제출 / 동의 중 가장 최근 (제출해 두고 운영자 승인을 기다리는 사람을 '정체'로 잘못 잡지 않게)
  const anchor = [lastApproved && lastApproved.reviewed_at, lastSubmitted, enrollment && enrollment.granted_at, user.consent_at || user.created_at].filter(Boolean).sort().pop();
  const stallDays = Math.floor((Date.now() - Date.parse(anchor)) / 86400000);
  const stalled = !completed && !trialDone && stallDays >= 3;   // 체험 끝난 사람(결제 대기)은 '멈춤' 아님 (2026-09-14)

  return {
    days, approvedCount, total, percent, weeks, today, completed, course, enrollment, maxDay, trialDone,
    isTrial: !!enrollment && enrollment.kind === 'trial', isPaid: !!enrollment && enrollment.kind === 'paid',
    lastApprovedAt: lastApproved ? lastApproved.reviewed_at : null, hasApproval: !!lastApproved,
    lastSubmittedAt: lastSubmitted || null,
    stallDays, stalled,
    pendingCount: latest.filter((s) => s.status === 'submitted').length,
  };
}

function stats() {
  return {
    users: db.prepare('SELECT COUNT(*) AS n FROM users').get().n,
    paid: db.prepare(`SELECT COUNT(DISTINCT user_id) AS n FROM enrollments WHERE kind = 'paid'`).get().n,
    trial: db.prepare(`SELECT COUNT(*) AS n FROM users u WHERE NOT EXISTS (SELECT 1 FROM enrollments e WHERE e.user_id = u.id AND e.kind = 'paid')`).get().n,
    pending: db.prepare(`SELECT COUNT(*) AS n FROM submissions WHERE status = 'submitted'`).get().n,
    approved: db.prepare(`SELECT COUNT(*) AS n FROM submissions WHERE status = 'approved'`).get().n,
    codesFree: db.prepare('SELECT COUNT(*) AS n FROM codes WHERE used_by IS NULL').get().n,
    codesTotal: db.prepare('SELECT COUNT(*) AS n FROM codes').get().n,
  };
}

module.exports = { normalizeCode, markOldNotificationsRead, markNotificationsReadByLink,
  db, DATA_DIR, UPLOAD_DIR, CONTENT_DIR, TOTAL_DAYS, WEEKS,
  seedMissions, extractTitle, addAdminNotice, listAdminNotices,
  createCodes, listCodes, findCode,
  findUserByNickname, findUserById, createUser, createUserWithCode, touchLogin,
  listCourses, getCourse, createCourse, updateCourse, enrollmentsOf, getEnrollment, grantEnrollment, revokeEnrollment, redeemCode,
  listCohorts, createCohort, setCohortStatus, listCheers, setCheer, setCheerHidden, usersNeedingReminder, recordReminder, CODE_MAX_FAILS, CODE_LOCK_MIN, recordConsent, setGraduate, setPassword, listUsers,
  getMission, listMissions, updateMission,
  latestSubmission, submissionHistory, createSubmission, getSubmission, findImage, reviewSubmission,
  pendingQueue, recentReviewed, allSubmissions, recentFeedbackForUser,
  unreadNotifications, markNotificationsRead, logAccess,
  progressOf, stats,
  getSetting, setSetting, allCourseFeedback, feedbackStats,
  MAX_DEVICES, listDevices, registerDevice, resetDevices, logLogin, addNotification, securityReport, autoWarnSuspicious,
};
