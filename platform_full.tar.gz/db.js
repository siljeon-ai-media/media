/**
 * db.js — 모든 데이터베이스 접근을 이 한 모듈에 격리.
 * (Autoscale 배포에서 Postgres로 바꿔야 할 때 이 파일만 교체하면 되도록.)
 *
 * SQLite 파일: data/app.db  /  업로드: data/uploads/
 */
'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const CONTENT_DIR = path.join(ROOT, 'content');
const DB_PATH = path.join(DATA_DIR, 'app.db');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const TOTAL_DAYS = 20;
const WEEKS = [
  { week: 1, label: '1주차 · 사무실 만들기', days: [1, 2, 3, 4, 5] },
  { week: 2, label: '2주차 · 첫 출근', days: [6, 7, 8, 9, 10] },
  { week: 3, label: '3주차 · 두 번째 업무', days: [11, 12, 13, 14, 15] },
  { week: 4, label: '4주차 · 회사 완성', days: [16, 17, 18, 19, 20] },
];

// ───────────────────────── 스키마 ─────────────────────────
db.exec(`
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  used_by INTEGER,
  used_at TEXT
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nickname TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  code_id INTEGER,
  cheer_message TEXT,
  consent_at TEXT,
  is_graduate INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS consents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  version TEXT NOT NULL,
  agreed_refund INTEGER NOT NULL,
  agreed_copy INTEGER NOT NULL,
  agreed_privacy INTEGER NOT NULL,
  ip TEXT,
  user_agent TEXT,
  agreed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS missions (
  day INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  body_md TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  edited_by_admin INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day INTEGER NOT NULL,
  memo TEXT,
  status TEXT NOT NULL DEFAULT 'submitted', -- submitted | approved | revision
  comment TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  reviewed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_sub_user_day ON submissions(user_id, day, id);
CREATE INDEX IF NOT EXISTS idx_sub_status ON submissions(status, created_at);

CREATE TABLE IF NOT EXISTS submission_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  submission_id INTEGER NOT NULL,
  filename TEXT NOT NULL UNIQUE,
  original_name TEXT,
  size INTEGER,
  FOREIGN KEY(submission_id) REFERENCES submissions(id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  message TEXT NOT NULL,
  link TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  read_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS access_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day INTEGER NOT NULL,
  viewed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  user_agent TEXT,
  first_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(user_id, device_id)
);
CREATE TABLE IF NOT EXISTS login_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  device_id TEXT,
  ip TEXT,
  user_agent TEXT,
  result TEXT NOT NULL, -- ok | blocked_device | wrong_password
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_login_events_user ON login_events(user_id, created_at);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  sess TEXT NOT NULL,
  expired INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expired ON sessions(expired);
`);

// ───────────────────────── 미션 시드 ─────────────────────────
/** 본문 첫 `# 제목`에서 제목 추출. "Day N — " 접두어는 화면에서 따로 붙이므로 제거. */
function extractTitle(md, day) {
  const m = md.match(/^#\s+(.+)$/m);
  if (!m) return `Day ${day}`;
  return m[1].trim().replace(/^Day\s*\d+\s*[—–:\-]\s*/i, '').trim() || `Day ${day}`;
}

// 기존 DB에 feedback 컬럼이 없으면 추가 (2026-09-12: 제출 시 교재 개선 피드백 수집)
try {
  const cols = db.prepare("PRAGMA table_info('submissions')").all().map((c) => c.name);
  if (!cols.includes('feedback')) db.exec('ALTER TABLE submissions ADD COLUMN feedback TEXT');
  if (!cols.includes('feedback_json')) db.exec('ALTER TABLE submissions ADD COLUMN feedback_json TEXT');
} catch (e) { console.error('[migration feedback]', e); }

function seedMissions() {
  const get = db.prepare('SELECT day, edited_by_admin FROM missions WHERE day = ?');
  const upsert = db.prepare(`INSERT INTO missions(day, title, body_md) VALUES(?,?,?)
    ON CONFLICT(day) DO UPDATE SET title=excluded.title, body_md=excluded.body_md, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')`);
  const tx = db.transaction(() => {
    for (let day = 1; day <= TOTAL_DAYS; day++) {
      const file = path.join(CONTENT_DIR, `day${String(day).padStart(2, '0')}.md`);
      let md;
      if (fs.existsSync(file)) md = fs.readFileSync(file, 'utf8');
      else md = `# Day ${day} — (준비 중)\n\n이 미션은 곧 공개됩니다.`;
      const row = get.get(day);
      // 관리자가 편집한 미션은 파일로 덮어쓰지 않는다 (DB 우선)
      if (row && row.edited_by_admin) continue;
      upsert.run(day, extractTitle(md, day), md);
    }
  });
  tx();
}

// ───────────────────────── 입장 코드 ─────────────────────────
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 헷갈리는 0/O, 1/I 제외
function randomCode() {
  let s = 'SJ1-';
  const bytes = require('crypto').randomBytes(4);
  for (let i = 0; i < 4; i++) s += CODE_CHARS[bytes[i] % CODE_CHARS.length];
  return s;
}

function createCodes(count) {
  const ins = db.prepare('INSERT OR IGNORE INTO codes(code) VALUES(?)');
  const made = [];
  const tx = db.transaction(() => {
    while (made.length < count) {
      const c = randomCode();
      const r = ins.run(c);
      if (r.changes) made.push(c);
    }
  });
  tx();
  return made;
}

function listCodes() {
  return db.prepare(`SELECT c.*, u.nickname AS used_by_nickname
    FROM codes c LEFT JOIN users u ON u.id = c.used_by
    ORDER BY c.id DESC`).all();
}

function findCode(code) {
  return db.prepare('SELECT * FROM codes WHERE code = ?').get(String(code || '').trim().toUpperCase());
}

// ───────────────────────── 사용자 ─────────────────────────
function findUserByNickname(nick) {
  return db.prepare('SELECT * FROM users WHERE nickname = ?').get(nick);
}
function findUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function createUserWithCode({ nickname, passwordHash, cheerMessage, code }) {
  const tx = db.transaction(() => {
    const c = db.prepare('SELECT * FROM codes WHERE code = ? AND used_by IS NULL').get(code);
    if (!c) throw new Error('CODE_INVALID');
    const r = db.prepare('INSERT INTO users(nickname, password_hash, code_id, cheer_message) VALUES(?,?,?,?)')
      .run(nickname, passwordHash, c.id, cheerMessage || null);
    db.prepare(`UPDATE codes SET used_by = ?, used_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`)
      .run(r.lastInsertRowid, c.id);
    return findUserById(r.lastInsertRowid);
  });
  return tx();
}

function touchLogin(userId) {
  db.prepare(`UPDATE users SET last_login_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(userId);
}

function recordConsent({ userId, version, refund, copy, privacy, ip, userAgent }) {
  const tx = db.transaction(() => {
    db.prepare(`INSERT INTO consents(user_id, version, agreed_refund, agreed_copy, agreed_privacy, ip, user_agent)
      VALUES(?,?,?,?,?,?,?)`).run(userId, version, refund ? 1 : 0, copy ? 1 : 0, privacy ? 1 : 0, ip || null, userAgent || null);
    db.prepare(`UPDATE users SET consent_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`).run(userId);
  });
  tx();
}

function setPassword(userId, passwordHash) {
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, userId);
}

function setGraduate(userId, flag) {
  db.prepare('UPDATE users SET is_graduate = ? WHERE id = ?').run(flag ? 1 : 0, userId);
}

function listUsers() {
  return db.prepare('SELECT * FROM users ORDER BY id ASC').all();
}

// ───────────────────────── 미션 ─────────────────────────
function getMission(day) {
  return db.prepare('SELECT * FROM missions WHERE day = ?').get(day);
}
function listMissions() {
  return db.prepare('SELECT day, title, updated_at, edited_by_admin FROM missions ORDER BY day').all();
}
function updateMission(day, title, bodyMd) {
  db.prepare(`UPDATE missions SET title = ?, body_md = ?, edited_by_admin = 1,
    updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE day = ?`).run(title, bodyMd, day);
}

// ───────────────────────── 제출 ─────────────────────────
function latestSubmissionsByUser(userId) {
  // 각 Day의 "가장 최근" 제출 1건씩
  return db.prepare(`SELECT s.* FROM submissions s
    WHERE s.user_id = ? AND s.id = (SELECT MAX(id) FROM submissions WHERE user_id = s.user_id AND day = s.day)
    ORDER BY s.day`).all(userId);
}

function latestSubmission(userId, day) {
  return db.prepare('SELECT * FROM submissions WHERE user_id = ? AND day = ? ORDER BY id DESC LIMIT 1').get(userId, day);
}

function submissionHistory(userId, day) {
  const rows = db.prepare('SELECT * FROM submissions WHERE user_id = ? AND day = ? ORDER BY id DESC').all(userId, day);
  for (const r of rows) r.images = imagesOf(r.id);
  return rows;
}

function imagesOf(submissionId) {
  return db.prepare('SELECT * FROM submission_images WHERE submission_id = ? ORDER BY id').all(submissionId);
}

function createSubmission({ userId, day, memo, feedback, feedbackJson, images }) {
  const tx = db.transaction(() => {
    const r = db.prepare('INSERT INTO submissions(user_id, day, memo, feedback, feedback_json) VALUES(?,?,?,?,?)').run(userId, day, memo || null, feedback || null, feedbackJson || null);
    const ins = db.prepare('INSERT INTO submission_images(submission_id, filename, original_name, size) VALUES(?,?,?,?)');
    for (const im of images) ins.run(r.lastInsertRowid, im.filename, im.originalname, im.size);
    return r.lastInsertRowid;
  });
  return tx();
}

// 교재 개선 피드백(제출 때 받는 "아쉬운 점·보완할 점") 모아보기 — Day별, 최신순
// Day별 집계: 평균 난이도(1~4), 시간 분포, 응답 수
function feedbackStats() {
  const rows = db.prepare(`SELECT day, feedback_json FROM submissions WHERE feedback_json IS NOT NULL`).all();
  const by = {};
  for (const r of rows) {
    let f; try { f = JSON.parse(r.feedback_json); } catch { continue; }
    const b = (by[r.day] = by[r.day] || { n: 0, diffSum: 0, diffN: 0, hard: 0, times: {}, stuck: [] });
    b.n++;
    if (f.difficulty) { b.diffSum += f.difficulty; b.diffN++; if (f.difficulty >= 3) b.hard++; }
    if (f.time) b.times[f.time] = (b.times[f.time] || 0) + 1;
    if (f.stuck && !/^없음?$/.test(f.stuck)) b.stuck.push(f.stuck);
  }
  for (const d of Object.keys(by)) { const b = by[d]; b.avgDifficulty = b.diffN ? Math.round((b.diffSum / b.diffN) * 10) / 10 : null; b.hardRate = b.diffN ? Math.round((b.hard / b.diffN) * 100) : null; }
  return by;
}

function allCourseFeedback() {
  return db.prepare(`SELECT s.id, s.day, s.feedback, s.feedback_json, s.created_at, u.nickname
    FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.feedback IS NOT NULL AND TRIM(s.feedback) <> '' ORDER BY s.day, s.created_at DESC`).all();
}

function getSubmission(id) {
  const s = db.prepare(`SELECT s.*, u.nickname FROM submissions s JOIN users u ON u.id = s.user_id WHERE s.id = ?`).get(id);
  if (s) s.images = imagesOf(s.id);
  return s;
}

function findImage(filename) {
  return db.prepare(`SELECT i.*, s.user_id FROM submission_images i JOIN submissions s ON s.id = i.submission_id WHERE i.filename = ?`).get(filename);
}

function reviewSubmission({ id, status, comment }) {
  const tx = db.transaction(() => {
    const s = db.prepare('SELECT * FROM submissions WHERE id = ?').get(id);
    if (!s) throw new Error('NOT_FOUND');
    db.prepare(`UPDATE submissions SET status = ?, comment = ?, reviewed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`)
      .run(status, comment || null, id);
    const msg = status === 'approved'
      ? `Day ${s.day} 미션이 승인되었습니다. 다음 미션이 열렸어요!`
      : `Day ${s.day} 미션에 보완 요청이 왔어요. 코멘트를 확인하고 다시 제출해 주세요.`;
    db.prepare('INSERT INTO notifications(user_id, message, link) VALUES(?,?,?)').run(s.user_id, msg, `/day/${s.day}`);
    return db.prepare('SELECT * FROM submissions WHERE id = ?').get(id);
  });
  return tx();
}

function pendingQueue() {
  const rows = db.prepare(`SELECT s.*, u.nickname FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.status = 'submitted' ORDER BY s.created_at ASC, s.id ASC`).all();
  for (const r of rows) r.images = imagesOf(r.id);
  return rows;
}

function recentReviewed(limit = 30) {
  return db.prepare(`SELECT s.*, u.nickname FROM submissions s JOIN users u ON u.id = s.user_id
    WHERE s.status <> 'submitted' ORDER BY s.reviewed_at DESC LIMIT ?`).all(limit);
}

function allSubmissions() {
  return db.prepare(`SELECT s.*, u.nickname,
    (SELECT COUNT(*) FROM submission_images i WHERE i.submission_id = s.id) AS image_count
    FROM submissions s JOIN users u ON u.id = s.user_id ORDER BY s.id`).all();
}

function recentFeedbackForUser(userId, limit = 5) {
  return db.prepare(`SELECT * FROM submissions WHERE user_id = ? AND status <> 'submitted'
    ORDER BY reviewed_at DESC LIMIT ?`).all(userId, limit);
}

// ───────────────────────── 알림 ─────────────────────────
function unreadNotifications(userId) {
  return db.prepare('SELECT * FROM notifications WHERE user_id = ? AND read_at IS NULL ORDER BY id DESC').all(userId);
}
function markNotificationsRead(userId) {
  db.prepare(`UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE user_id = ? AND read_at IS NULL`).run(userId);
}

function logAccess(userId, day) {
  db.prepare('INSERT INTO access_logs(user_id, day) VALUES(?,?)').run(userId, day);
}

// ───────────────────────── 운영 설정 (재시작 없이 관리자 화면에서 바꾸는 값: 문의 링크·문구) ─────────────────────────
function getSetting(key, fallback = '') {
  const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  db.prepare(`INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`).run(key, String(value || ''));
}

// ───────────────────────── 기기 제한 · 로그인 기록 (계정 공유 방지, 2026-09-11 대표 결정: 기기 2대) ─────────────────────────
const MAX_DEVICES = Number(process.env.MAX_DEVICES) || 2;
function listDevices(userId) {
  return db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY first_seen').all(userId);
}
// 로그인 시 호출: 등록된 기기면 갱신, 자리가 남으면 등록, 꽉 찼으면 차단(ok:false)
function registerDevice(userId, deviceId, userAgent) {
  const found = db.prepare('SELECT id FROM devices WHERE user_id = ? AND device_id = ?').get(userId, deviceId);
  if (found) {
    db.prepare(`UPDATE devices SET last_seen = strftime('%Y-%m-%dT%H:%M:%fZ','now'), user_agent = ? WHERE id = ?`).run(userAgent || null, found.id);
    return { ok: true, count: listDevices(userId).length };
  }
  const count = listDevices(userId).length;
  if (count >= MAX_DEVICES) return { ok: false, count };
  db.prepare('INSERT INTO devices(user_id, device_id, user_agent) VALUES(?,?,?)').run(userId, deviceId, userAgent || null);
  return { ok: true, count: count + 1, isNew: true };
}
function resetDevices(userId) { db.prepare('DELETE FROM devices WHERE user_id = ?').run(userId); }
function logLogin({ userId, deviceId, ip, userAgent, result }) {
  db.prepare('INSERT INTO login_events(user_id, device_id, ip, user_agent, result) VALUES(?,?,?,?,?)').run(userId, deviceId || null, ip || null, userAgent || null, result);
}
function addNotification(userId, message, link) {
  db.prepare('INSERT INTO notifications(user_id, message, link) VALUES(?,?,?)').run(userId, message, link || null);
}
// 최근 N일 의심 징후: 차단된 기기 시도 수, 서로 다른 IP 수, 최근 로그인 기록
function securityReport(days = 7) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const users = db.prepare('SELECT id, nickname FROM users ORDER BY id').all();
  return users.map((u) => {
    const ev = db.prepare('SELECT * FROM login_events WHERE user_id = ? AND created_at >= ? ORDER BY created_at DESC').all(u.id, since);
    const blocked = ev.filter((e) => e.result === 'blocked_device').length;
    const ips = new Set(ev.filter((e) => e.result === 'ok' && e.ip).map((e) => e.ip));
    return { user: u, devices: listDevices(u.id), blocked, distinctIps: ips.size, okLogins: ev.filter((e) => e.result === 'ok').length, lastEvents: ev.slice(0, 10),
      suspicious: blocked >= 2 || ips.size >= 4 };
  });
}
// 자동 경고: 최근 7일 차단 시도 2회 이상이면 대시보드 알림 1회(24시간 내 중복 금지)
function autoWarnSuspicious() {
  const rep = securityReport(7).filter((r) => r.blocked >= 2);
  const warned = [];
  for (const r of rep) {
    const recent = db.prepare(`SELECT id FROM notifications WHERE user_id = ? AND message LIKE '%등록되지 않은 기기%' AND created_at >= ?`).get(r.user.id, new Date(Date.now() - 86400000).toISOString());
    if (recent) continue;
    addNotification(r.user.id, `등록되지 않은 기기에서 로그인 시도가 ${r.blocked}회 있었습니다. 이 계정은 본인 1인 · 기기 ${MAX_DEVICES}대까지만 이용할 수 있고, 공유가 확인되면 이용이 정지됩니다. 기기를 바꾸신 거라면 문의해 주세요.`, null);
    warned.push(r.user.nickname);
  }
  return warned;
}

// ───────────────────────── 진행 계산 ─────────────────────────
/**
 * 사용자 진행 상태 요약: 잠금/승인/진행률/주차/정체 일수
 */
function progressOf(user) {
  const latest = latestSubmissionsByUser(user.id);
  const byDay = new Map(latest.map((s) => [s.day, s]));
  const approvedDays = new Set(latest.filter((s) => s.status === 'approved').map((s) => s.day));

  const days = [];
  for (let d = 1; d <= TOTAL_DAYS; d++) {
    const s = byDay.get(d) || null;
    const unlocked = user.is_graduate ? true : d === 1 || approvedDays.has(d - 1);
    days.push({ day: d, unlocked, submission: s, status: s ? s.status : (unlocked ? 'open' : 'locked') });
  }

  const approvedCount = approvedDays.size;
  const percent = Math.round((approvedCount / TOTAL_DAYS) * 100);
  const weeks = WEEKS.map((w) => {
    const done = w.days.filter((d) => approvedDays.has(d)).length;
    return { ...w, done, total: w.days.length, percent: Math.round((done / w.days.length) * 100) };
  });

  // 오늘 미션 = 아직 승인되지 않은 가장 낮은 Day (열려 있는 것)
  const today = days.find((d) => d.status !== 'approved' && d.unlocked) || null;
  const completed = approvedCount >= TOTAL_DAYS;

  // 정체: 마지막 승인 시각(없으면 동의/가입 시각) 이후 경과 일수
  const lastApproved = latest.filter((s) => s.status === 'approved' && s.reviewed_at)
    .sort((a, b) => (a.reviewed_at < b.reviewed_at ? 1 : -1))[0];
  const lastSubmitted = db.prepare('SELECT MAX(created_at) AS t FROM submissions WHERE user_id = ?').get(user.id).t;
  // 정체 기준 시각 = 마지막 승인 / 마지막 제출 / 동의 중 가장 최근 (제출해 두고 운영자 승인을 기다리는 사람을 '정체'로 잘못 잡지 않게)
  const anchor = [lastApproved && lastApproved.reviewed_at, lastSubmitted, user.consent_at || user.created_at].filter(Boolean).sort().pop();
  const stallDays = Math.floor((Date.now() - Date.parse(anchor)) / 86400000);
  const stalled = !completed && stallDays >= 3;

  return {
    days, approvedCount, total: TOTAL_DAYS, percent, weeks, today, completed,
    lastApprovedAt: lastApproved ? lastApproved.reviewed_at : null,
    lastSubmittedAt: lastSubmitted || null,
    stallDays, stalled,
    pendingCount: latest.filter((s) => s.status === 'submitted').length,
  };
}

function stats() {
  return {
    users: db.prepare('SELECT COUNT(*) AS n FROM users').get().n,
    pending: db.prepare(`SELECT COUNT(*) AS n FROM submissions WHERE status = 'submitted'`).get().n,
    approved: db.prepare(`SELECT COUNT(*) AS n FROM submissions WHERE status = 'approved'`).get().n,
    codesFree: db.prepare('SELECT COUNT(*) AS n FROM codes WHERE used_by IS NULL').get().n,
    codesTotal: db.prepare('SELECT COUNT(*) AS n FROM codes').get().n,
  };
}

module.exports = {
  db, DATA_DIR, UPLOAD_DIR, CONTENT_DIR, TOTAL_DAYS, WEEKS,
  seedMissions, extractTitle,
  createCodes, listCodes, findCode,
  findUserByNickname, findUserById, createUserWithCode, touchLogin, recordConsent, setGraduate, setPassword, listUsers,
  getMission, listMissions, updateMission,
  latestSubmission, submissionHistory, createSubmission, getSubmission, findImage, reviewSubmission,
  pendingQueue, recentReviewed, allSubmissions, recentFeedbackForUser,
  unreadNotifications, markNotificationsRead, logAccess,
  progressOf, stats,
  getSetting, setSetting, allCourseFeedback, feedbackStats,
  MAX_DEVICES, listDevices, registerDevice, resetDevices, logLogin, addNotification, securityReport, autoWarnSuspicious,
};
