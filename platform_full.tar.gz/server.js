/**
 * siljeon.ai 1기 챌린지 플랫폼 — 서버 진입점
 * 실행: npm start  →  http://localhost:3000
 */
'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const bcrypt = require('bcryptjs');

const dbm = require('./db');
const SqliteStore = require('./lib/session-store');
const telegram = require('./lib/telegram');
const md = require('./lib/markdown');
const consentText = require('./lib/consent');

const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin1234';
const ADMIN_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);
const COHORT = process.env.COHORT || '1기';
const CONTACT = process.env.CONTACT_INFO || '인스타그램 @siljeon.ai DM';
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

if (!process.env.SESSION_SECRET) {
  console.warn('[경고] SESSION_SECRET 환경변수가 없어 임시 비밀키를 씁니다. 서버를 재시작하면 모두 로그아웃됩니다.');
}
if (ADMIN_PASSWORD === 'admin1234') {
  console.warn('[경고] ADMIN_PASSWORD 환경변수가 없어 기본값(admin1234)을 씁니다. 배포 전에 꼭 바꾸세요.');
}

dbm.seedMissions();

const app = express();
app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(express.json({ limit: '1mb' }));
app.use('/public', express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

app.use(session({
  store: new SqliteStore(dbm.db),
  secret: SESSION_SECRET,
  name: 'sj.sid',
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: 'auto',
    maxAge: 1000 * 60 * 60 * 24 * 14,
  },
}));

// ───────────────────────── 공통 헬퍼 ─────────────────────────
const KST = new Intl.DateTimeFormat('ko-KR', {
  timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
});
function fmt(iso) {
  if (!iso) return '-';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return KST.format(new Date(t)).replace(/\. /g, '.').replace(/\.$/, '');
}
function daysAgo(iso) {
  if (!iso) return null;
  return Math.floor((Date.now() - Date.parse(iso)) / 86400000);
}
const STATUS_LABEL = { submitted: '검토 대기', approved: '승인', revision: '보완 요청', open: '진행 가능', locked: '잠김' };

const CHEERS = [
  '오늘 한 걸음이면 충분합니다. 미션 하나만 끝내요.',
  '완벽하게 말고, 일단 제출. 피드백이 나머지를 채웁니다.',
  '4주 뒤 아침, AI 직원이 먼저 출근해 있을 거예요.',
  '막히면 캡처해서 그대로 제출하세요. 그게 가장 빠른 길입니다.',
  '어제의 나보다 미션 하나 더. 그게 전부입니다.',
];

app.use((req, res, next) => {
  res.locals.fmt = fmt;
  res.locals.daysAgo = daysAgo;
  res.locals.STATUS_LABEL = STATUS_LABEL;
  res.locals.COHORT = COHORT;
  res.locals.CONTACT = dbm.getSetting('contact_label', CONTACT);          // 문의 안내 문구 (예: "카카오톡 1기 단톡방")
  res.locals.CONTACT_URL = dbm.getSetting('contact_url', 'https://www.instagram.com/siljeon.ai/'); // 문의 버튼이 여는 주소
  res.locals.TOTAL_DAYS = dbm.TOTAL_DAYS;
  res.locals.currentUser = null;
  res.locals.todayDay = null;
  res.locals.completed = false;
  res.locals.prefix = '';                 // 코스 주소 접두어: 정규과정 '' / 옵션 과정 '/c/<slug>'
  res.locals.course = null;
  res.locals.myEnrollments = [];
  res.locals.myCohort = COHORT;
  res.locals.isAdmin = Boolean(req.session.isAdmin);
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  if (req.session.userId) {
    const u = dbm.findUserById(req.session.userId);
    if (u) {
      req.user = u; res.locals.currentUser = u;
      const ens = dbm.enrollmentsOf(u.id); res.locals.myEnrollments = ens;
      const paidMain = ens.find((e) => e.slug === 'main' && e.kind === 'paid');
      res.locals.myCohort = paidMain && paidMain.cohort ? paidMain.cohort : (ens.some((e) => e.kind === 'paid') ? '수강생' : '체험');
      // 폰 바닥 알약 내비용: 오늘 미션 번호 (동의 전엔 없음)
      if (u.consent_at) { try { const tp = dbm.progressOf(u); res.locals.todayDay = tp.today ? tp.today.day : null; res.locals.completed = !!tp.completed; } catch { res.locals.todayDay = null; } }
    }
    else delete req.session.userId;
  }
  next();
});

// 코스 해석: /c/:slug/... 는 그 코스, 나머지는 정규과정(main). 뷰에서 링크는 prefix + '/day/N'
function resolveCourse(req, res, next) {
  const slug = req.params.slug || 'main';
  const c = dbm.getCourse(slug);
  if (!c || (!c.is_active && !req.session.isAdmin)) return res.status(404).render('error', { title: '없는 과정', message: '존재하지 않는 과정입니다.' });
  req.course = c; res.locals.course = c;
  req.prefix = c.slug === 'main' ? '' : `/c/${c.slug}`; res.locals.prefix = req.prefix;
  req.enrollment = req.user ? (dbm.getEnrollment(req.user.id, c.id) || null) : null;
  next();
}

function setFlash(req, type, text) { req.session.flash = { type, text }; }

function requireUser(req, res, next) {
  if (!req.user) {
    req.session.returnTo = req.originalUrl;
    return res.redirect('/login');
  }
  next();
}
function requireConsent(req, res, next) {
  if (!req.user.consent_at) return res.redirect('/consent');
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) {
    req.session.returnTo = req.originalUrl;
    return res.redirect('/admin/login');
  }
  next();
}
function requireAdminApi(req, res, next) {
  const key = req.get('x-admin-password') || (req.get('authorization') || '').replace(/^Bearer\s+/i, '');
  if (req.session.isAdmin || (key && bcrypt.compareSync(key, ADMIN_HASH))) return next();
  return res.status(401).json({ ok: false, error: 'unauthorized' });
}
function parseDay(req, res, next) {
  const n = Number(req.params.n);
  const total = req.course ? req.course.total_days : dbm.TOTAL_DAYS;
  if (!Number.isInteger(n) || n < 1 || n > total) return res.status(404).render('error', { title: '없는 미션', message: '존재하지 않는 미션 번호입니다.' });
  req.day = n;
  next();
}

// 로그인 실패 제한 (메모리 기반) — 실패만 센다. 성공하면 초기화.
const attempts = new Map();
function rateLimit(keyFn, max = 20, windowMs = 15 * 60 * 1000) {
  return (req, res, next) => {
    const key = keyFn(req);
    const now = Date.now();
    const rec = attempts.get(key) || { n: 0, t: now };
    if (now - rec.t > windowMs) { rec.n = 0; rec.t = now; }
    attempts.set(key, rec);
    if (rec.n >= max) return res.status(429).render('error', { title: '잠시 후 다시 시도', message: '실패한 시도가 너무 많습니다. 15분 뒤 다시 시도해 주세요.' });
    req.loginFailed = () => { rec.n += 1; };
    req.loginSucceeded = () => { attempts.delete(key); };
    next();
  };
}
const loginLimiter = rateLimit((req) => `login:${req.ip}`);
const adminLimiter = rateLimit((req) => `admin:${req.ip}`, 10);

// ───────────────────────── 업로드 ─────────────────────────
const ALLOWED_MIME = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const upload = multer({
  storage: multer.diskStorage({
    destination: dbm.UPLOAD_DIR,
    filename: (req, file, cb) => {
      const ext = ALLOWED_MIME[file.mimetype] || 'bin';
      cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`);
    },
  }),
  limits: { fileSize: MAX_IMAGE_BYTES, files: 3 },
  fileFilter: (req, file, cb) => {
    const extOk = /\.(jpe?g|png|webp)$/i.test(file.originalname || '');
    if (ALLOWED_MIME[file.mimetype] && extOk) return cb(null, true);
    return cb(new Error('이미지는 jpg / png / webp 파일만 올릴 수 있어요.'));
  },
});

// ───────────────────────── 공개: 로그인 / 가입 ─────────────────────────
app.get('/login', (req, res) => {
  if (req.user) return res.redirect('/');
  res.render('login', { title: '로그인', error: null });
});

// 기기 식별 쿠키(브라우저마다 1개, 2년). 지우면 새 기기로 취급됨 — 그래서 한도는 2대.
const DEVICE_COOKIE = 'sj.dev';
function deviceIdOf(req, res) {
  const raw = String((req.headers.cookie || '').split(';').map((c) => c.trim()).find((c) => c.startsWith(DEVICE_COOKIE + '=')) || '').slice(DEVICE_COOKIE.length + 1);
  if (/^[a-f0-9]{32}$/.test(raw)) return raw;
  const id = crypto.randomBytes(16).toString('hex');
  res.cookie(DEVICE_COOKIE, id, { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: 1000 * 60 * 60 * 24 * 730 });
  return id;
}

app.post('/login', loginLimiter, (req, res) => {
  const nickname = String(req.body.nickname || '').trim();
  const password = String(req.body.password || '');
  const user = nickname && dbm.findUserByNickname(nickname);
  const ua = (req.get('user-agent') || '').slice(0, 200);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    req.loginFailed();
    if (user) dbm.logLogin({ userId: user.id, ip: req.ip, userAgent: ua, result: 'wrong_password' });
    return res.status(401).render('login', { title: '로그인', error: '닉네임 또는 비밀번호가 맞지 않아요.' });
  }
  const deviceId = deviceIdOf(req, res);
  const dev = dbm.registerDevice(user.id, deviceId, ua);
  if (!dev.ok) {
    dbm.logLogin({ userId: user.id, deviceId, ip: req.ip, userAgent: ua, result: 'blocked_device' });
    telegram.notifyAdmin(`⚠️ [${user.nickname}] 등록되지 않은 기기(${dev.count + 1}번째)에서 로그인 시도 차단 · IP ${req.ip}`);
    return res.status(403).render('login', { title: '로그인', error: `이 계정은 기기 ${dbm.MAX_DEVICES}대(예: 폰 1대 + 컴퓨터 1대)까지만 쓸 수 있어요. 기기를 새로 바꾸셨다면 ${dbm.getSetting('contact_label', CONTACT)}으로 알려주세요 — 확인 후 바로 풀어드립니다.` });
  }
  dbm.logLogin({ userId: user.id, deviceId, ip: req.ip, userAgent: ua, result: 'ok' });
  req.loginSucceeded();
  const to = req.session.returnTo && req.session.returnTo.startsWith('/') && !req.session.returnTo.startsWith('//') ? req.session.returnTo : '/';
  req.session.regenerate((err) => {
    if (err) return res.status(500).render('error', { title: '오류', message: '세션 오류가 발생했어요. 다시 시도해 주세요.' });
    req.session.userId = user.id;
    dbm.touchLogin(user.id);
    res.redirect(to);
  });
});

// 비밀번호 재설정(본인 확인 = 닉네임 + 그 계정을 만든 입장 코드). 기존 비밀번호는 암호화 저장이라 알려줄 수 없고, 새로 정한다.
app.get('/forgot', (req, res) => {
  if (req.user) return res.redirect('/');
  res.render('forgot', { title: '비밀번호 재설정', error: null, form: {} });
});
app.post('/forgot', loginLimiter, (req, res) => {
  const nickname = String(req.body.nickname || '').trim();
  const code = String(req.body.code || '').trim().toUpperCase();
  const password = String(req.body.password || '');
  const password2 = String(req.body.password2 || '');
  const form = { nickname, code };
  const fail = (msg) => { req.loginFailed(); return res.status(400).render('forgot', { title: '비밀번호 재설정', error: msg, form }); };
  const user = nickname && dbm.findUserByNickname(nickname);
  const c = code && dbm.findCode(code);
  if (!user || !c || c.used_by !== user.id) return fail('닉네임과 입장 코드가 서로 맞지 않아요. 구매할 때 받은 파일의 코드를 다시 확인해 주세요.');
  if (password.length < 6) return fail('새 비밀번호는 6자 이상으로 해 주세요.');
  if (password !== password2) return fail('새 비밀번호 두 칸이 서로 달라요.');
  dbm.setPassword(user.id, bcrypt.hashSync(password, 10));
  dbm.logLogin({ userId: user.id, ip: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 200), result: 'password_reset' });
  req.loginSucceeded();
  setFlash(req, 'ok', '비밀번호를 새로 만들었어요. 이제 로그인하세요.');
  res.redirect('/login');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

app.get('/signup', (req, res) => {
  if (req.user) return res.redirect('/');
  const code = String(req.query.code || '').trim().toUpperCase();
  res.render('signup', { title: '무료 체험 가입', code, error: null, form: {}, trialDays: dbm.getCourse('main').trial_days });
});
const CODE_RE = /^SJ\d-[A-Z0-9]{4}(-[A-Z0-9]{4}-[A-Z0-9]{4})?$/; // 옛 8자(SJ1-XXXX)·새 16자 둘 다

app.post('/signup', loginLimiter, (req, res) => {
  if (req.user) return res.redirect('/');
  const code = String(req.body.code || '').trim().toUpperCase();
  const company = String(req.body.company || '').trim().replace(/[\[\]\/]/g, '');
  const password = String(req.body.password || '');
  const password2 = String(req.body.password2 || '');
  const cheer = String(req.body.cheer || '').trim().slice(0, 100);
  const form = { code, company, cheer };
  const trialDays = dbm.getCourse('main').trial_days;
  const fail = (msg) => { req.loginFailed(); return res.status(400).render('signup', { title: '무료 체험 가입', code, error: msg, form, trialDays }); };

  if (code) {
    if (!CODE_RE.test(code)) return fail('입장 코드 형식이 맞지 않아요. 예: SJ1-7K3M-QW9P-2ZDX (코드가 아직 없으면 비워 두세요 — 무료 체험으로 시작됩니다)');
    const c = dbm.findCode(code);
    if (!c) return fail('등록되지 않은 입장 코드예요. 1기방에서 받은 코드를 다시 확인해 주세요. (코드가 없으면 비워 두고 가입 → 나중에 설정에서 입력)');
    if (c.used_by) return fail('이미 사용된 입장 코드예요. 코드 1개는 계정 1개에만 쓸 수 있어요.');
  }
  if (company.length < 1 || company.length > 20) return fail('업체명(또는 이름)은 1~20자로 적어 주세요.');
  if (password.length < 6) return fail('비밀번호는 6자 이상으로 해 주세요.');
  if (password !== password2) return fail('비밀번호 두 칸이 서로 달라요.');

  const nickname = company;
  if (dbm.findUserByNickname(nickname) || dbm.findUserByNickname(`${company}/${COHORT}`)) return fail(`"${nickname}" 상호는 이미 가입되어 있어요. 조금 바꿔 주세요(예: 실전AI자동화 김포점).`);

  let user;
  try {
    user = dbm.createUser({ nickname, passwordHash: bcrypt.hashSync(password, 10), cheerMessage: cheer, code: code || null });
  } catch (e) {
    return fail('가입 처리 중 문제가 생겼어요. 코드가 방금 사용됐을 수 있어요.');
  }
  if (code) { telegram.notifyAdmin(`🎟 [${nickname}] 가입과 동시에 입장 코드 사용 → 결제 수강권. 클로드 앱을 확인 부탁드립니다.`); dbm.addAdminNotice(`🎟 [${nickname}] 가입+코드 ${code} 사용(결제 수강권)`, telegram.enabled()); }
  else { dbm.addAdminNotice(`🆕 [${nickname}] 무료 체험 가입`, false); }
  req.loginSucceeded();
  const devId = deviceIdOf(req, res);
  dbm.registerDevice(user.id, devId, (req.get('user-agent') || '').slice(0, 200));
  dbm.logLogin({ userId: user.id, deviceId: devId, ip: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 200), result: 'ok' });
  req.session.regenerate(() => {
    req.session.userId = user.id;
    res.redirect('/consent');
  });
});

// ───────────────────────── 동의 화면 ─────────────────────────
app.get('/consent', requireUser, (req, res) => {
  if (req.user.consent_at) return res.redirect('/');
  res.render('consent', { title: '입장 전 동의', consent: consentText, error: null });
});

app.post('/consent', requireUser, (req, res) => {
  if (req.user.consent_at) return res.redirect('/');
  const refund = req.body.agree_refund === 'on';
  const copy = req.body.agree_copy === 'on';
  const privacy = req.body.agree_privacy === 'on';
  if (!refund || !copy || !privacy) {
    return res.status(400).render('consent', { title: '입장 전 동의', consent: consentText, error: '세 항목 모두 확인·동의해야 입장할 수 있어요.' });
  }
  dbm.recordConsent({ userId: req.user.id, version: consentText.VERSION, refund, copy, privacy, ip: req.ip, userAgent: req.get('user-agent') });
  setFlash(req, 'ok', '동의가 저장되었어요. 환영합니다!');
  res.redirect('/');
});

// ───────────────────────── 대시보드 ─────────────────────────
function renderDashboard(req, res) {
  const course = req.course;
  const p = dbm.progressOf(req.user, course, req.enrollment);
  const missions = dbm.listMissions(course.id);
  const titles = new Map(missions.map((m) => [m.day, m.title]));
  const notifications = dbm.unreadNotifications(req.user.id);
  dbm.markNotificationsRead(req.user.id);
  const feedback = dbm.recentFeedbackForUser(req.user.id, 5).filter((f) => (f.course_id || 1) === course.id);
  // 다짐·응원 한 줄: 기본 문구 + 모든 수강생의 다짐(숨김 제외). 본인 것은 2배 가중. (2026-09-13 대표: 가입 때 적은 다짐이 메인에 무작위로 돌게)
  const others = dbm.listCheers().filter((c) => c.id !== req.user.id);
  const pool = CHEERS.map((t) => ({ text: t, who: '오늘의 한 줄' }))
    .concat(others.map((c) => ({ text: c.cheer_message, who: `${c.nickname}${c.cohort ? ' · ' + c.cohort : ''} 님의 다짐` })));
  if (req.user.cheer_message && !req.user.cheer_hidden) pool.push({ text: req.user.cheer_message, who: '내가 남긴 한 줄' }, { text: req.user.cheer_message, who: '내가 남긴 한 줄' });
  const pick = pool[Math.floor(Math.random() * pool.length)];
  const allCourses = dbm.listCourses(true);
  res.render('dashboard', {
    title: course.slug === 'main' ? '대시보드' : course.title, p, titles, notifications, feedback,
    cheer: pick.text, cheerWho: pick.who, cheerIsMine: pick.who === '내가 남긴 한 줄',
    allCourses, purchaseUrl: course.purchase_url || dbm.getSetting('purchase_url', ''),
  });
}
app.get('/', requireUser, requireConsent, resolveCourse, renderDashboard);
app.get('/c/:slug', requireUser, requireConsent, resolveCourse, renderDashboard);

// ───────────────────────── 설정: 입장 코드 입력(승격) · 다짐 한 줄 ─────────────────────────
app.get('/settings', requireUser, requireConsent, (req, res) => {
  res.render('settings', { title: '설정', error: null, ok: null, codes: dbm.enrollmentsOf(req.user.id) });
});
app.post('/settings/code', requireUser, requireConsent, loginLimiter, (req, res) => {
  const raw = String(req.body.code || '').trim().toUpperCase().replace(/\s+/g, '');
  const r = dbm.redeemCode(req.user.id, raw);
  if (!r.ok) {
    req.loginFailed();
    let msg = '등록되지 않은 코드예요. 1기방에서 받은 코드를 그대로(띄어쓰기 없이) 넣어 주세요.';
    if (r.error === 'USED') msg = '이미 사용된 코드예요. 코드 1개는 계정 1개에만 쓸 수 있어요. 본인이 쓴 게 아니라면 문의해 주세요.';
    if (r.error === 'LOCKED' || r.until) msg = `틀린 입력이 ${dbm.CODE_MAX_FAILS}회라 ${dbm.CODE_LOCK_MIN}분 동안 잠겼어요. 잠시 후 다시 시도해 주세요.`;
    else if (r.left !== undefined && r.left > 0) msg += ` (남은 시도 ${r.left}회)`;
    return res.status(400).render('settings', { title: '설정', error: msg, ok: null, codes: dbm.enrollmentsOf(req.user.id) });
  }
  req.loginSucceeded();
  const c = r.course;
  const label = c.slug === 'main' ? `정규과정 ${r.enrollment.cohort || ''}`.trim() : c.title;
  telegram.notifyAdmin(`🎟 [${req.user.nickname}] ${label} 승격 완료. 클로드 앱을 확인 부탁드립니다.`);
  dbm.addAdminNotice(`🎟 [${req.user.nickname}] 코드 ${r.code.code} 사용 → ${label} 승격${r.code.memo ? ' (메모: ' + r.code.memo + ')' : ''}`, telegram.enabled());
  dbm.addNotification(req.user.id, `${label} 수강권이 열렸어요. 이제 모든 Day를 순서대로 진행할 수 있습니다.`, c.slug === 'main' ? '/' : `/c/${c.slug}`);
  setFlash(req, 'ok', `${label} 수강권이 열렸어요! 진행 기록은 그대로 이어집니다.`);
  res.redirect(c.slug === 'main' ? '/' : `/c/${c.slug}`);
});
app.post('/settings/cheer', requireUser, requireConsent, (req, res) => {
  const cheer = String(req.body.cheer || '').trim().slice(0, 100);
  dbm.setCheer(req.user.id, cheer);
  setFlash(req, 'ok', cheer ? '다짐 한 줄을 저장했어요. 메인 화면에 가끔 보입니다.' : '다짐 한 줄을 비웠어요.');
  res.redirect('/settings');
});

// ───────────────────────── Day 페이지 ─────────────────────────
app.get(['/day/:n', '/c/:slug/day/:n'], requireUser, requireConsent, resolveCourse, parseDay, (req, res) => {
  const day = req.day; const course = req.course; const prefix = req.prefix;
  const p = dbm.progressOf(req.user, course, req.enrollment);
  const info = p.days[day - 1];
  const mission = dbm.getMission(day, course.id);
  if (!info.unlocked) {
    return res.status(403).render('day_locked', { title: `Day ${day} 잠김`, day, mission, p, paywalled: info.paywalled, purchaseUrl: course.purchase_url || dbm.getSetting('purchase_url', '') });
  }
  dbm.logAccess(req.user.id, day, course.id);
  const history = dbm.submissionHistory(req.user.id, day, course.id);
  const latest = history[0] || null;
  const canSubmit = !latest || latest.status === 'revision';
  const html = md.render(mission.body_md);
  res.render('day', {
    title: `Day ${day} · ${mission.title}`, day, mission, html, history, latest, canSubmit, p,
    watermark: `[${req.user.nickname}] 전용 · 재배포 금지`,
    prevDay: day > 1 ? day - 1 : null,
    nextDay: day < course.total_days ? day + 1 : null,
    nextUnlocked: day < course.total_days ? p.days[day].unlocked : false,
    nextPaywalled: day < course.total_days ? p.days[day].paywalled : false,
    purchaseUrl: course.purchase_url || dbm.getSetting('purchase_url', ''),
  });
});

app.get(['/day/:n/submit', '/c/:slug/day/:n/submit'], requireUser, requireConsent, resolveCourse, parseDay, (req, res) => {
  const day = req.day; const course = req.course; const prefix = req.prefix;
  const p = dbm.progressOf(req.user, course, req.enrollment);
  if (!p.days[day - 1].unlocked) return res.redirect(`${prefix}/day/${day}`);
  const latest = dbm.latestSubmission(req.user.id, day, course.id);
  if (latest && latest.status !== 'revision') {
    setFlash(req, 'info', latest.status === 'approved' ? '이미 승인된 미션이에요.' : '검토 대기 중이에요. 결과가 나오면 알려드릴게요.');
    return res.redirect(`${prefix}/day/${day}`);
  }
  const mission = dbm.getMission(day, course.id);
  res.render('submit', { title: `Day ${day} 제출`, day, mission, latest, error: null });
});

app.post(['/day/:n/submit', '/c/:slug/day/:n/submit'], requireUser, requireConsent, resolveCourse, parseDay, (req, res) => {
  const day = req.day; const course = req.course; const prefix = req.prefix;
  const p = dbm.progressOf(req.user, course, req.enrollment);
  if (!p.days[day - 1].unlocked) return res.status(403).redirect(`${prefix}/day/${day}`);
  const latest = dbm.latestSubmission(req.user.id, day, course.id);
  if (latest && latest.status !== 'revision') return res.redirect(`${prefix}/day/${day}`);
  const mission = dbm.getMission(day, course.id);

  upload.array('images', 3)(req, res, (err) => {
    const files = req.files || [];
    const cleanup = () => files.forEach((f) => fs.unlink(f.path, () => {}));
    const fail = (msg, code = 400) => {
      cleanup();
      res.status(code).render('submit', { title: `Day ${day} 제출`, day, mission, latest, error: msg });
    };
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return fail('이미지 1장은 5MB 이하여야 해요. 폰 캡처는 보통 1~2MB입니다.');
      if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') return fail('이미지는 최대 3장까지예요.');
      return fail(err.message || '업로드 중 문제가 생겼어요.');
    }
    if (files.length < 1) return fail('캡처 이미지를 1장 이상 올려 주세요.');
    const memo = String(req.body.memo || '').trim().slice(0, 2000);
    // 교재 개선 피드백: 객관식 3 + 주관식 2 (전부 선택). 읽기용 문장 + 구조(JSON) 둘 다 저장
    const fb = {
      difficulty: Number(req.body.fb_difficulty) || null,           // 1 쉬움 ~ 4 혼자선 못 함
      time: Number(req.body.fb_time) || null,                       // 분
      stuck: String(req.body.fb_stuck || '').trim().slice(0, 60),
      unclear: String(req.body.fb_unclear || '').trim().slice(0, 1000),
      wish: String(req.body.fb_wish || '').trim().slice(0, 1000),
    };
    const DIFF = { 1: '쉬움', 2: '보통', 3: '어려움', 4: '혼자선 못 함' };
    const parts = [];
    if (fb.difficulty) parts.push(`난이도: ${DIFF[fb.difficulty]}`);
    if (fb.time) parts.push(`걸린 시간: ${fb.time >= 120 ? '1시간 넘게' : fb.time + '분'}`);
    if (fb.stuck) parts.push(`멈춘 곳: ${fb.stuck}`);
    if (fb.unclear) parts.push(`이해 안 됨/화면 다름: ${fb.unclear}`);
    if (fb.wish) parts.push(`바꾸면 좋겠다: ${fb.wish}`);
    const feedback = parts.join('\n');
    const id = dbm.createSubmission({ userId: req.user.id, day, memo, feedback, feedbackJson: parts.length ? JSON.stringify(fb) : null, images: files, courseId: course.id });
    const kind = latest ? '재제출' : '제출';
    const cLabel = course.slug === 'main' ? '' : `[${course.title}] `;
    // 텔레그램은 짧은 안내만(2026-09-13 대표 지시), 본문은 admin_notices → 로디가 대화창에 게시
    telegram.notifyAdmin(`📥 [${req.user.nickname}] ${cLabel}Day ${day} ${kind} 도착 (제출 #${id}). 클로드 앱을 확인 부탁드립니다.`);
    dbm.addAdminNotice(`📥 [${req.user.nickname}] ${cLabel}Day ${day} ${kind}\n${mission.title}\n메모: ${memo ? memo.slice(0, 200) : '(없음)'}${feedback ? '\n💬 교재 피드백: ' + feedback.slice(0, 200) : ''}\n제출 #${id} · 이미지 ${files.length}장`, telegram.enabled());
    setFlash(req, 'ok', `Day ${day} 미션을 ${kind}했어요. 피드백이 오면 대시보드에 표시됩니다.`);
    res.redirect(`${prefix}/day/${day}`);
  });
});

// 업로드 이미지 — 본인 또는 관리자만
app.get('/uploads/:file', requireUser, (req, res) => {
  const file = String(req.params.file || '');
  if (!/^[\w.-]+$/.test(file)) return res.status(404).end();
  const img = dbm.findImage(file);
  if (!img) return res.status(404).end();
  if (img.user_id !== req.user.id && !req.session.isAdmin) return res.status(403).end();
  res.set('Cache-Control', 'private, max-age=600');
  res.sendFile(path.join(dbm.UPLOAD_DIR, file));
});
// 관리자 전용 이미지 경로 (수강생 로그인 없이도 관리자 세션이면 열람)
app.get('/admin/uploads/:file', requireAdmin, (req, res) => {
  const file = String(req.params.file || '');
  if (!/^[\w.-]+$/.test(file) || !dbm.findImage(file)) return res.status(404).end();
  res.set('Cache-Control', 'private, max-age=600');
  res.sendFile(path.join(dbm.UPLOAD_DIR, file));
});

// ───────────────────────── 관리자 ─────────────────────────
app.get('/admin/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin');
  res.render('admin/login', { title: '관리자 로그인', error: null });
});
app.post('/admin/login', adminLimiter, (req, res) => {
  const pw = String(req.body.password || '');
  if (!bcrypt.compareSync(pw, ADMIN_HASH)) {
    req.loginFailed();
    return res.status(401).render('admin/login', { title: '관리자 로그인', error: '비밀번호가 맞지 않아요.' });
  }
  req.loginSucceeded();
  const userId = req.session.userId; // 수강생으로도 로그인돼 있으면 유지
  const to = req.session.returnTo && req.session.returnTo.startsWith('/admin') ? req.session.returnTo : '/admin';
  req.session.regenerate(() => {
    req.session.isAdmin = true;
    if (userId) req.session.userId = userId;
    res.redirect(to);
  });
});
app.post('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

function userRows() {
  return dbm.listUsers().map((u) => ({ user: u, p: dbm.progressOf(u), enrollments: dbm.enrollmentsOf(u.id) }));
}

// 배포 자동화 (2026-09-12 v2): 로디가 필요할 때마다 스스로 반영하기 위한 장치.
//  - 화면 패치(views/public/content) = 관리자 버튼 또는 API
//  - 전체(server.js·lib·db.js 포함) = API + restart=1 → 적용 후 프로세스 종료 → Reserved VM/Run 관리자가 자동 재시작
//  - 인증: 관리자 세션 / X-Admin-Password / X-Deploy-Token(배포 전용 비밀값, Secrets DEPLOY_TOKEN)
const PATCH_URL = process.env.PATCH_URL || 'https://siljeon-ai-media.github.io/media/platform_patch.tar.gz';
const FULL_URL = process.env.FULL_URL || 'https://siljeon-ai-media.github.io/media/platform_full.tar.gz';
const DEPLOY_TOKEN = process.env.DEPLOY_TOKEN || '';

async function applyUpdate(scope) {
  const { execFileSync } = require('child_process');
  const os = require('os');
  const full = scope === 'full';
  const tmpName = `patch-${Date.now()}.tar.gz`;
  const tmp = path.join(os.tmpdir(), tmpName);
  const tarOpt = { cwd: os.tmpdir(), encoding: 'utf8', maxBuffer: 50 * 1024 * 1024 }; // 윈도우 tar가 'C:'를 원격 호스트로 오해하지 않게 상대 경로로
  try {
    const url = (full ? FULL_URL : PATCH_URL) + '?t=' + Date.now();
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) throw new Error(`다운로드 실패 HTTP ${r.status}`);
    fs.writeFileSync(tmp, Buffer.from(await r.arrayBuffer()));
    const list = execFileSync('tar', ['-tzf', tmpName], tarOpt).split('\n').filter(Boolean);
    const allow = full ? /^(\.\/)?(views|public|content|lib|server\.js|boot\.js|db\.js|package\.json|package-lock\.json|README\.md|SPEC\.md|TEST_LOG\.md|seed_codes\.js|\.env\.example|\.gitignore)(\/|$)/ : /^(views|public|content)\//;
    if (list.some((f) => /^(\.\/)?\.$/.test(f))) { /* './' 항목은 무시 */ }
    const bad = list.find((f) => f !== './' && (!allow.test(f) || f.includes('..')));
    if (bad) throw new Error(`허용되지 않은 경로: ${bad}`);
    execFileSync('tar', ['-xzf', tmpName, '-C', __dirname], tarOpt);
    app.set('view cache', false);
    if (list.some((f) => /(^|\/)content\//.test(f)) && typeof dbm.seedMissions === 'function') dbm.seedMissions();
    return { ok: true, files: list.length, scope: full ? 'full' : 'patch' };
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

app.post('/admin/update', requireAdmin, async (req, res) => {
  try {
    const r = await applyUpdate('patch');
    req.session.flash = { type: 'ok', text: `화면 패치 적용 완료 (${r.files}개 파일). 새로고침(Ctrl+Shift+R)하면 반영됩니다.` };
  } catch (e) {
    req.session.flash = { type: 'err', text: `패치 실패: ${e.message}` };
  }
  res.redirect('/admin');
});

function requireDeploy(req, res, next) {
  const t = req.get('x-deploy-token');
  if (DEPLOY_TOKEN && t && t === DEPLOY_TOKEN) return next();
  return requireAdminApi(req, res, next);
}
// 로디용: POST /api/admin/update?scope=patch|full&restart=1  (헤더 X-Deploy-Token 또는 X-Admin-Password)
app.post('/api/admin/update', requireDeploy, async (req, res) => {
  const scope = String(req.query.scope || req.body.scope || 'patch');
  const restart = String(req.query.restart || req.body.restart || '') === '1';
  try {
    const r = await applyUpdate(scope);
    res.json({ ...r, restart });
    if (restart) {
      console.log('[deploy] 재시작 요청 — 3초 뒤 프로세스 종료(실행 관리자가 다시 띄움)');
      setTimeout(() => process.exit(0), 3000);
    }
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});
// 로디용: 대표에게 간 텔레그램 알림을 그대로 다시 읽기 (GET /api/admin/notices?since=<마지막 id>)
app.get('/api/admin/notices', requireDeploy, (req, res) => {
  res.json({ ok: true, rows: dbm.listAdminNotices(req.query.since, req.query.limit) });
});
// 로디용 백업: GET /api/admin/backup → data/ (app.db + uploads) 를 tar.gz 로 내려받음.
// 왜: 레플릿 공식 문서가 "배포된 앱의 파일에 저장한 데이터에 기대지 말라"고 함 — 레플릿에서 '다시 배포'를 누르면 파일이 초기화될 수 있어 주기적으로 밖에 복사해 둔다. (2026-09-12)
app.get('/api/admin/backup', requireDeploy, (req, res) => {
  const { spawn } = require('child_process');
  try { dbm.db.pragma('wal_checkpoint(TRUNCATE)'); } catch {}
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader('Content-Disposition', `attachment; filename="siljeon_data_${new Date().toISOString().slice(0, 10)}.tar.gz"`);
  const tar = spawn('tar', ['-czf', '-', '-C', __dirname, 'data']);
  tar.stdout.pipe(res);
  tar.stderr.on('data', (d) => console.warn('[backup]', String(d).trim()));
  tar.on('error', (e) => { console.warn('[backup] 실패:', e.message); if (!res.headersSent) res.status(500).end(); else res.end(); });
});
app.get('/api/admin/version', requireDeploy, (req, res) => {
  let started = process.uptime();
  let st = null; try { st = fs.statSync(path.join(__dirname, 'server.js')).mtime; } catch {}
  res.json({ ok: true, uptimeSec: Math.round(started), serverJsModified: st, node: process.version });
});

app.get('/admin', requireAdmin, (req, res) => {
  const s = dbm.stats();
  const rows = userRows();
  const stalled = rows.filter((r) => r.p.stalled && r.user.consent_at);
  const queue = dbm.pendingQueue();
  res.render('admin/index', { title: '관리자', s, stalled, queue: queue.slice(0, 5), queueTotal: queue.length, telegramOn: telegram.enabled() });
});

app.get('/admin/queue', requireAdmin, (req, res) => {
  const queue = dbm.pendingQueue();
  const recent = dbm.recentReviewed(20);
  res.render('admin/queue', { title: '제출 대기열', queue, recent });
});

app.get('/admin/submission/:id', requireAdmin, (req, res) => {
  const s = dbm.getSubmission(Number(req.params.id));
  if (!s) return res.status(404).render('error', { title: '없음', message: '제출을 찾을 수 없어요.' });
  const mission = dbm.getMission(s.day);
  const history = dbm.submissionHistory(s.user_id, s.day);
  const user = dbm.findUserById(s.user_id);
  res.render('admin/submission', { title: `제출 #${s.id}`, s, mission, history, user, p: dbm.progressOf(user) });
});

function doReview(req, res, asJson) {
  const id = Number(req.params.id);
  const action = String(req.body.action || (req.body.approve !== undefined ? 'approve' : (req.body.revision !== undefined ? 'revision' : '')));
  const comment = String(req.body.comment || '').trim().slice(0, 4000);
  if (!['approve', 'revision'].includes(action)) {
    return asJson ? res.status(400).json({ ok: false, error: 'action must be approve|revision' }) : res.status(400).send('bad action');
  }
  if (action === 'revision' && !comment) {
    if (asJson) return res.status(400).json({ ok: false, error: 'comment required for revision' });
    setFlash(req, 'err', '보완 요청에는 코멘트(무엇을 고칠지)를 꼭 적어 주세요.');
    return res.redirect(`/admin/submission/${id}`);
  }
  let updated;
  try {
    updated = dbm.reviewSubmission({ id, status: action === 'approve' ? 'approved' : 'revision', comment });
  } catch (e) {
    return asJson ? res.status(404).json({ ok: false, error: 'not found' }) : res.status(404).send('not found');
  }
  if (asJson) return res.json({ ok: true, submission: updated });
  setFlash(req, 'ok', action === 'approve' ? `제출 #${id} 승인 완료. 수강생에게 다음 Day가 열렸어요.` : `제출 #${id} 보완 요청을 보냈어요.`);
  res.redirect('/admin/queue');
}
app.post('/admin/submission/:id/review', requireAdmin, (req, res) => doReview(req, res, false));

app.get('/admin/users', requireAdmin, (req, res) => {
  res.render('admin/users', { title: '수강생 목록', rows: userRows(), courses: dbm.listCourses(false), cohorts: dbm.listCohorts() });
});
// 비밀번호 잊은 수강생: 관리자가 임시 비밀번호 발급 → DM으로 전달 → 본인이 로그인 후 사용 (변경 기능은 추후)
app.post('/admin/users/:id/reset-password', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (!u) return res.redirect('/admin/users');
  const temp = 'sj' + crypto.randomBytes(3).toString('hex'); // 예: sj3f9a1c (8자)
  dbm.setPassword(u.id, bcrypt.hashSync(temp, 10));
  setFlash(req, 'ok', `${u.nickname} 임시 비밀번호: ${temp}  — 수강생에게 DM으로 전달하세요. (이 화면을 닫으면 다시 볼 수 없어요)`);
  res.redirect('/admin/users');
});
app.get('/admin/feedback', requireAdmin, (req, res) => {
  res.render('admin/feedback', { title: '교재 피드백 모음', rows: dbm.allCourseFeedback(), stats: dbm.feedbackStats(), missions: dbm.listMissions() });
});
app.get('/api/admin/feedback', requireAdminApi, (req, res) => res.json({ ok: true, stats: dbm.feedbackStats(), rows: dbm.allCourseFeedback() }));
app.get('/admin/settings', requireAdmin, (req, res) => {
  res.render('admin/settings', { title: '운영 설정', contactLabel: dbm.getSetting('contact_label', CONTACT), contactUrl: dbm.getSetting('contact_url', 'https://www.instagram.com/siljeon.ai/'), purchaseUrl: dbm.getSetting('purchase_url', '') });
});
app.post('/admin/settings', requireAdmin, (req, res) => {
  const label = String(req.body.contact_label || '').trim().slice(0, 60);
  const url = String(req.body.contact_url || '').trim().slice(0, 300);
  if (url && !/^https?:\/\//.test(url)) { setFlash(req, 'err', '문의 링크는 https:// 로 시작해야 해요.'); return res.redirect('/admin/settings'); }
  if (label) dbm.setSetting('contact_label', label);
  if (url) dbm.setSetting('contact_url', url);
  const purchase = String(req.body.purchase_url || '').trim().slice(0, 300);
  if (purchase && !/^https?:\/\//.test(purchase)) { setFlash(req, 'err', '판매 페이지 주소는 https:// 로 시작해야 해요.'); return res.redirect('/admin/settings'); }
  dbm.setSetting('purchase_url', purchase);
  setFlash(req, 'ok', '저장했어요. 모든 화면의 문의 버튼·문구에 바로 반영됩니다.');
  res.redirect('/admin/settings');
});
app.post('/admin/users/:id/reset-devices', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (u) { dbm.resetDevices(u.id); setFlash(req, 'ok', `${u.nickname} 등록 기기를 비웠어요. 다음 로그인 기기부터 다시 등록됩니다.`); }
  res.redirect('/admin/users');
});
app.get('/admin/security', requireAdmin, (req, res) => {
  res.render('admin/security', { title: '보안 점검', rows: dbm.securityReport(7), maxDevices: dbm.MAX_DEVICES });
});
app.post('/admin/security/warn', requireAdmin, (req, res) => {
  const warned = dbm.autoWarnSuspicious();
  setFlash(req, 'ok', warned.length ? `경고 알림 보냄: ${warned.join(', ')}` : '경고 대상이 없어요.');
  res.redirect('/admin/security');
});
app.get('/api/admin/security', requireAdminApi, (req, res) => res.json({ ok: true, maxDevices: dbm.MAX_DEVICES, rows: dbm.securityReport(Number(req.query.days) || 7) }));
app.post('/admin/users/:id/graduate', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (u) {
    dbm.setGraduate(u.id, !u.is_graduate);
    setFlash(req, 'ok', `${u.nickname} 졸업생 모드 ${u.is_graduate ? '해제' : '켬'}.`);
  }
  res.redirect('/admin/users');
});

function csv(rows, headers) {
  const esc = (v) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [headers.map((h) => esc(h.label)).join(',')];
  for (const r of rows) lines.push(headers.map((h) => esc(typeof h.get === 'function' ? h.get(r) : r[h.key])).join(','));
  return '﻿' + lines.join('\r\n');
}
app.get('/admin/users.csv', requireAdmin, (req, res) => {
  const rows = userRows();
  const body = csv(rows, [
    { label: '닉네임', get: (r) => r.user.nickname },
    { label: '가입일', get: (r) => fmt(r.user.created_at) },
    { label: '동의시각', get: (r) => fmt(r.user.consent_at) },
    { label: '승인 미션 수', get: (r) => r.p.approvedCount },
    { label: '진행률(%)', get: (r) => r.p.percent },
    { label: '마지막 제출', get: (r) => fmt(r.p.lastSubmittedAt) },
    { label: '마지막 승인', get: (r) => fmt(r.p.lastApprovedAt) },
    { label: '정체 일수', get: (r) => r.p.stallDays },
    { label: '대기 중 제출', get: (r) => r.p.pendingCount },
    { label: '수강권', get: (r) => r.enrollments.map((e) => `${e.title}:${e.kind === 'paid' ? '결제' : '체험'}${e.cohort ? '/' + e.cohort : ''}`).join(' | ') },
    { label: '다짐', get: (r) => r.user.cheer_message || '' },
    { label: '졸업생 모드', get: (r) => (r.user.is_graduate ? 'Y' : 'N') },
    { label: '마지막 로그인', get: (r) => fmt(r.user.last_login_at) },
  ]);
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="users-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(body);
});
app.get('/admin/submissions.csv', requireAdmin, (req, res) => {
  const rows = dbm.allSubmissions();
  const body = csv(rows, [
    { label: '제출ID', key: 'id' },
    { label: '닉네임', key: 'nickname' },
    { label: 'Day', key: 'day' },
    { label: '상태', get: (r) => STATUS_LABEL[r.status] || r.status },
    { label: '제출시각', get: (r) => fmt(r.created_at) },
    { label: '검토시각', get: (r) => fmt(r.reviewed_at) },
    { label: '이미지 수', key: 'image_count' },
    { label: '메모', key: 'memo' },
    { label: '교재 피드백', key: 'feedback' },
    { label: '코멘트', key: 'comment' },
  ]);
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="submissions-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(body);
});

app.get('/admin/codes', requireAdmin, (req, res) => {
  const codes = dbm.listCodes();
  const made = req.session.madeCodes || null;
  delete req.session.madeCodes;
  res.render('admin/codes', { title: '입장 코드', codes, made, baseUrl: `${req.protocol}://${req.get('host')}`, courses: dbm.listCourses(false), cohorts: dbm.listCohorts() });
});
app.post('/admin/codes', requireAdmin, (req, res) => {
  const n = Math.min(100, Math.max(1, Number(req.body.count) || 1));
  const course = dbm.getCourse(String(req.body.course_id || '1')) || dbm.getCourse('main');
  const cohort = String(req.body.cohort || '').trim().slice(0, 20) || null;
  const memo = String(req.body.memo || '').trim().slice(0, 80) || null;
  req.session.madeCodes = dbm.createCodes(n, { courseId: course.id, cohort, memo });
  res.redirect('/admin/codes');
});
app.post('/admin/cohorts', requireAdmin, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 20);
  if (name) { try { dbm.createCohort({ courseId: Number(req.body.course_id) || 1, name, capacity: Number(req.body.capacity) || 30 }); setFlash(req, 'ok', `기수 "${name}" 추가.`); } catch (e) { setFlash(req, 'err', '같은 이름의 기수가 이미 있어요.'); } }
  res.redirect('/admin/codes');
});
app.post('/admin/cohorts/:id/status', requireAdmin, (req, res) => { dbm.setCohortStatus(Number(req.params.id), String(req.body.status || 'open')); res.redirect('/admin/codes'); });

// 코스(과정) 관리: 정규과정 1개 + 옵션 과정 추가. 옵션 과정 교재는 content/<slug>/dayNN.md
app.get('/admin/courses', requireAdmin, (req, res) => {
  res.render('admin/courses', { title: '과정 관리', courses: dbm.listCourses(false), purchaseUrl: dbm.getSetting('purchase_url', '') });
});
app.post('/admin/courses', requireAdmin, (req, res) => {
  const slug = String(req.body.slug || '').trim().toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 30);
  const title = String(req.body.title || '').trim().slice(0, 60);
  if (!slug || !title || slug === 'main' || dbm.getCourse(slug)) { setFlash(req, 'err', '주소 이름(영문·숫자·-)과 제목이 필요하고, 이미 있는 이름은 안 돼요.'); return res.redirect('/admin/courses'); }
  dbm.createCourse({ slug, title, kind: 'option', totalDays: Number(req.body.total_days) || 10, trialDays: Number(req.body.trial_days) || 0, purchaseUrl: String(req.body.purchase_url || '').trim() });
  dbm.seedMissions();
  setFlash(req, 'ok', `"${title}" 과정을 만들었어요. 교재는 content/${slug}/day01.md… 파일 또는 미션 편집에서.`);
  res.redirect('/admin/courses');
});
app.post('/admin/courses/:id', requireAdmin, (req, res) => {
  const c = dbm.getCourse(String(Number(req.params.id)));
  if (!c) return res.redirect('/admin/courses');
  dbm.updateCourse(c.id, { title: String(req.body.title || c.title).trim().slice(0, 60), totalDays: Number(req.body.total_days) || c.total_days, trialDays: Number(req.body.trial_days) || 0, purchaseUrl: String(req.body.purchase_url || '').trim(), isActive: req.body.is_active === 'on', versionNote: String(req.body.version_note || '').trim().slice(0, 80) });
  dbm.seedMissions();
  setFlash(req, 'ok', `"${c.title}" 저장.`);
  res.redirect('/admin/courses');
});
// 수강권 수동 부여/회수 (코드 없이 — 예: 환불 후 회수, 특별 초대)
app.post('/admin/users/:id/enroll', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  const c = dbm.getCourse(String(req.body.course_id || '1'));
  if (u && c) {
    if (req.body.action === 'revoke') { dbm.revokeEnrollment(u.id, c.id); setFlash(req, 'ok', `${u.nickname}: ${c.title} 수강권 회수.`); }
    else { dbm.grantEnrollment({ userId: u.id, courseId: c.id, kind: 'paid', cohort: String(req.body.cohort || '').trim() || null, memo: String(req.body.memo || '').trim() || '관리자 수동' }); setFlash(req, 'ok', `${u.nickname}: ${c.title} 결제 수강권 부여.`); }
  }
  res.redirect('/admin/users');
});
app.post('/admin/users/:id/cheer-hide', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (u) { dbm.setCheerHidden(u.id, !u.cheer_hidden); setFlash(req, 'ok', `${u.nickname} 다짐 메시지 ${u.cheer_hidden ? '다시 표시' : '숨김'}.`); }
  res.redirect('/admin/users');
});

app.get(['/admin/missions', '/admin/c/:slug/missions'], requireAdmin, resolveCourse, (req, res) => {
  res.render('admin/missions', { title: '미션 목록', missions: dbm.listMissions(req.course.id), courses: dbm.listCourses(false) });
});
app.get(['/admin/day/:n/edit', '/admin/c/:slug/day/:n/edit'], requireAdmin, resolveCourse, parseDay, (req, res) => {
  const mission = dbm.getMission(req.day, req.course.id);
  res.render('admin/day_edit', { title: `Day ${req.day} 편집`, day: req.day, mission, preview: md.render(mission.body_md), adminPrefix: req.course.slug === 'main' ? '/admin' : `/admin/c/${req.course.slug}` });
});
app.post(['/admin/day/:n/edit', '/admin/c/:slug/day/:n/edit'], requireAdmin, resolveCourse, parseDay, (req, res) => {
  const body = String(req.body.body_md || '');
  const title = String(req.body.title || '').trim().replace(/^Day\s*\d+\s*[—–:\-]\s*/i, '') || dbm.extractTitle(body, req.day);
  dbm.updateMission(req.day, title, body, req.course.id);
  setFlash(req, 'ok', `Day ${req.day} 미션을 저장했어요. (파일보다 이 내용이 우선 적용됩니다)`);
  res.redirect(`${req.course.slug === 'main' ? '/admin' : '/admin/c/' + req.course.slug}/day/${req.day}/edit`);
});

// ───────────────────────── 관리자 API (로디의 AI 1차 피드백용) ─────────────────────────
// 헤더 X-Admin-Password: <ADMIN_PASSWORD>
app.get('/api/admin/queue', requireAdminApi, (req, res) => {
  res.json({ ok: true, queue: dbm.pendingQueue() });
});
app.get('/api/admin/submission/:id', requireAdminApi, (req, res) => {
  const s = dbm.getSubmission(Number(req.params.id));
  if (!s) return res.status(404).json({ ok: false, error: 'not found' });
  res.json({ ok: true, submission: s, history: dbm.submissionHistory(s.user_id, s.day) });
});
app.post('/api/admin/submission/:id/review', requireAdminApi, (req, res) => doReview(req, res, true));

app.get('/healthz', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ───────────────────────── 404 / 오류 ─────────────────────────
app.use((req, res) => res.status(404).render('error', { title: '페이지 없음', message: '요청하신 페이지를 찾을 수 없어요.' }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[server error]', err);
  if (res.headersSent) return;
  res.status(500).render('error', { title: '오류', message: '서버에 문제가 생겼어요. 잠시 후 다시 시도해 주세요.' });
});

// 6시간마다 자동: 최근 7일 차단 시도 2회 이상 계정에 대시보드 경고 + 관리자 텔레그램 알림
setInterval(() => {
  try {
    const warned = dbm.autoWarnSuspicious();
    if (warned.length) telegram.notifyAdmin(`🔒 계정 공유 의심 자동 경고 발송: ${warned.join(', ')}`);
  } catch (e) { console.error('[security scan]', e); }
}, 6 * 60 * 60 * 1000).unref();

// 매일: 결제 수강생 중 3일 무제출이면 대시보드 알림 1회(3일마다) + 관리자에게 짧은 텔레그램(누가 멈췄는지는 admin_notices 본문에)
function runReminders() {
  try {
    const list = dbm.usersNeedingReminder();
    for (const { user, course, p } of list) {
      const prefix = course.slug === 'main' ? '' : `/c/${course.slug}`;
      dbm.addNotification(user.id, `${p.stallDays}일째 제출이 없어요. 괜찮습니다 — 막힌 화면 캡처 한 장만 올려도 운영자가 잡아드립니다.${p.today ? ' 지금 할 미션: Day ' + p.today.day : ''}`, p.today ? `${prefix}/day/${p.today.day}` : (prefix || '/'));
      dbm.recordReminder(user.id, course.id);
    }
    if (list.length) {
      dbm.addAdminNotice(`⏰ 3일 무제출 리마인드 발송: ${list.map(({ user, p }) => `${user.nickname}(${p.stallDays}일)`).join(', ')}`, telegram.enabled());
      telegram.notifyAdmin(`⏰ 수강생 ${list.length}명에게 3일 무제출 리마인드를 보냈습니다. 클로드 앱을 확인 부탁드립니다.`);
    }
  } catch (e) { console.error('[reminders]', e); }
}
setTimeout(runReminders, 60 * 1000);
setInterval(runReminders, 24 * 60 * 60 * 1000).unref();

const server = app.listen(PORT, () => {
  console.log(`✅ siljeon.ai 챌린지 플랫폼 실행 중: http://localhost:${PORT}`);
  console.log(`   관리자: http://localhost:${PORT}/admin  ·  텔레그램 알림: ${telegram.enabled() ? '켜짐' : '꺼짐(ENV 없음)'}`);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));

module.exports = app;
