/**
 * siljeon.ai 1기 챌린지 플랫폼 — 서버 진입점
 * 실행: npm start  →  http://localhost:3000
 */
'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const bcrypt = require('bcryptjs');

const dbm = require('./db');
const SqliteStore = require('./lib/session-store');
const telegram = require('./lib/telegram');
const md = require('./lib/markdown');
const consentText = require('./lib/consent');

const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin1234';
const ADMIN_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);
const COHORT = process.env.COHORT || '1기';
const CONTACT = process.env.CONTACT_INFO || '인스타그램 @siljeon.ai DM';
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

if (!process.env.SESSION_SECRET) {
  console.warn('[경고] SESSION_SECRET 환경변수가 없어 임시 비밀키를 씁니다. 서버를 재시작하면 모두 로그아웃됩니다.');
}
if (ADMIN_PASSWORD === 'admin1234') {
  console.warn('[경고] ADMIN_PASSWORD 환경변수가 없어 기본값(admin1234)을 씁니다. 배포 전에 꼭 바꾸세요.');
}

dbm.seedMissions();

const app = express();
app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(express.json({ limit: '1mb' }));
app.use('/public', express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

app.use(session({
  store: new SqliteStore(dbm.db),
  secret: SESSION_SECRET,
  name: 'sj.sid',
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: 'auto',
    maxAge: 1000 * 60 * 60 * 24 * 14,
  },
}));

// ───────────────────────── 공통 헬퍼 ─────────────────────────
const KST = new Intl.DateTimeFormat('ko-KR', {
  timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
});
function fmt(iso) {
  if (!iso) return '-';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return KST.format(new Date(t)).replace(/\. /g, '.').replace(/\.$/, '');
}
function daysAgo(iso) {
  if (!iso) return null;
  return Math.floor((Date.now() - Date.parse(iso)) / 86400000);
}
const STATUS_LABEL = { submitted: '검토 대기', approved: '승인', revision: '보완 요청', open: '진행 가능', locked: '잠김' };

const CHEERS = [
  '오늘 한 걸음이면 충분합니다. 미션 하나만 끝내요.',
  '완벽하게 말고, 일단 제출. 피드백이 나머지를 채웁니다.',
  '4주 뒤 아침, AI 직원이 먼저 출근해 있을 거예요.',
  '막히면 캡처해서 그대로 제출하세요. 그게 가장 빠른 길입니다.',
  '어제의 나보다 미션 하나 더. 그게 전부입니다.',
];

app.use((req, res, next) => {
  res.locals.fmt = fmt;
  res.locals.daysAgo = daysAgo;
  res.locals.STATUS_LABEL = STATUS_LABEL;
  res.locals.COHORT = COHORT;
  res.locals.CONTACT = dbm.getSetting('contact_label', CONTACT);          // 문의 안내 문구 (예: "카카오톡 1기 단톡방")
  res.locals.CONTACT_URL = dbm.getSetting('contact_url', 'https://www.instagram.com/siljeon.ai/'); // 문의 버튼이 여는 주소
  res.locals.TOTAL_DAYS = dbm.TOTAL_DAYS;
  res.locals.currentUser = null;
  res.locals.todayDay = null;
  res.locals.completed = false;
  res.locals.isAdmin = Boolean(req.session.isAdmin);
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  if (req.session.userId) {
    const u = dbm.findUserById(req.session.userId);
    if (u) {
      req.user = u; res.locals.currentUser = u;
      // 폰 바닥 알약 내비용: 오늘 미션 번호 (동의 전엔 없음)
      if (u.consent_at) { try { const tp = dbm.progressOf(u); res.locals.todayDay = tp.today ? tp.today.day : null; res.locals.completed = !!tp.completed; } catch { res.locals.todayDay = null; } }
    }
    else delete req.session.userId;
  }
  next();
});

function setFlash(req, type, text) { req.session.flash = { type, text }; }

function requireUser(req, res, next) {
  if (!req.user) {
    req.session.returnTo = req.originalUrl;
    return res.redirect('/login');
  }
  next();
}
function requireConsent(req, res, next) {
  if (!req.user.consent_at) return res.redirect('/consent');
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) {
    req.session.returnTo = req.originalUrl;
    return res.redirect('/admin/login');
  }
  next();
}
function requireAdminApi(req, res, next) {
  const key = req.get('x-admin-password') || (req.get('authorization') || '').replace(/^Bearer\s+/i, '');
  if (req.session.isAdmin || (key && bcrypt.compareSync(key, ADMIN_HASH))) return next();
  return res.status(401).json({ ok: false, error: 'unauthorized' });
}
function parseDay(req, res, next) {
  const n = Number(req.params.n);
  if (!Number.isInteger(n) || n < 1 || n > dbm.TOTAL_DAYS) return res.status(404).render('error', { title: '없는 미션', message: '존재하지 않는 미션 번호입니다.' });
  req.day = n;
  next();
}

// 로그인 실패 제한 (메모리 기반) — 실패만 센다. 성공하면 초기화.
const attempts = new Map();
function rateLimit(keyFn, max = 20, windowMs = 15 * 60 * 1000) {
  return (req, res, next) => {
    const key = keyFn(req);
    const now = Date.now();
    const rec = attempts.get(key) || { n: 0, t: now };
    if (now - rec.t > windowMs) { rec.n = 0; rec.t = now; }
    attempts.set(key, rec);
    if (rec.n >= max) return res.status(429).render('error', { title: '잠시 후 다시 시도', message: '실패한 시도가 너무 많습니다. 15분 뒤 다시 시도해 주세요.' });
    req.loginFailed = () => { rec.n += 1; };
    req.loginSucceeded = () => { attempts.delete(key); };
    next();
  };
}
const loginLimiter = rateLimit((req) => `login:${req.ip}`);
const adminLimiter = rateLimit((req) => `admin:${req.ip}`, 10);

// ───────────────────────── 업로드 ─────────────────────────
const ALLOWED_MIME = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const upload = multer({
  storage: multer.diskStorage({
    destination: dbm.UPLOAD_DIR,
    filename: (req, file, cb) => {
      const ext = ALLOWED_MIME[file.mimetype] || 'bin';
      cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`);
    },
  }),
  limits: { fileSize: MAX_IMAGE_BYTES, files: 3 },
  fileFilter: (req, file, cb) => {
    const extOk = /\.(jpe?g|png|webp)$/i.test(file.originalname || '');
    if (ALLOWED_MIME[file.mimetype] && extOk) return cb(null, true);
    return cb(new Error('이미지는 jpg / png / webp 파일만 올릴 수 있어요.'));
  },
});

// ───────────────────────── 공개: 로그인 / 가입 ─────────────────────────
app.get('/login', (req, res) => {
  if (req.user) return res.redirect('/');
  res.render('login', { title: '로그인', error: null });
});

// 기기 식별 쿠키(브라우저마다 1개, 2년). 지우면 새 기기로 취급됨 — 그래서 한도는 2대.
const DEVICE_COOKIE = 'sj.dev';
function deviceIdOf(req, res) {
  const raw = String((req.headers.cookie || '').split(';').map((c) => c.trim()).find((c) => c.startsWith(DEVICE_COOKIE + '=')) || '').slice(DEVICE_COOKIE.length + 1);
  if (/^[a-f0-9]{32}$/.test(raw)) return raw;
  const id = crypto.randomBytes(16).toString('hex');
  res.cookie(DEVICE_COOKIE, id, { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: 1000 * 60 * 60 * 24 * 730 });
  return id;
}

app.post('/login', loginLimiter, (req, res) => {
  const nickname = String(req.body.nickname || '').trim();
  const password = String(req.body.password || '');
  const user = nickname && dbm.findUserByNickname(nickname);
  const ua = (req.get('user-agent') || '').slice(0, 200);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    req.loginFailed();
    if (user) dbm.logLogin({ userId: user.id, ip: req.ip, userAgent: ua, result: 'wrong_password' });
    return res.status(401).render('login', { title: '로그인', error: '닉네임 또는 비밀번호가 맞지 않아요.' });
  }
  const deviceId = deviceIdOf(req, res);
  const dev = dbm.registerDevice(user.id, deviceId, ua);
  if (!dev.ok) {
    dbm.logLogin({ userId: user.id, deviceId, ip: req.ip, userAgent: ua, result: 'blocked_device' });
    telegram.notifyAdmin(`⚠️ [${user.nickname}] 등록되지 않은 기기(${dev.count + 1}번째)에서 로그인 시도 차단 · IP ${req.ip}`);
    return res.status(403).render('login', { title: '로그인', error: `이 계정은 기기 ${dbm.MAX_DEVICES}대(예: 폰 1대 + 컴퓨터 1대)까지만 쓸 수 있어요. 기기를 새로 바꾸셨다면 ${dbm.getSetting('contact_label', CONTACT)}으로 알려주세요 — 확인 후 바로 풀어드립니다.` });
  }
  dbm.logLogin({ userId: user.id, deviceId, ip: req.ip, userAgent: ua, result: 'ok' });
  req.loginSucceeded();
  const to = req.session.returnTo && req.session.returnTo.startsWith('/') && !req.session.returnTo.startsWith('//') ? req.session.returnTo : '/';
  req.session.regenerate((err) => {
    if (err) return res.status(500).render('error', { title: '오류', message: '세션 오류가 발생했어요. 다시 시도해 주세요.' });
    req.session.userId = user.id;
    dbm.touchLogin(user.id);
    res.redirect(to);
  });
});

// 비밀번호 재설정(본인 확인 = 닉네임 + 그 계정을 만든 입장 코드). 기존 비밀번호는 암호화 저장이라 알려줄 수 없고, 새로 정한다.
app.get('/forgot', (req, res) => {
  if (req.user) return res.redirect('/');
  res.render('forgot', { title: '비밀번호 재설정', error: null, form: {} });
});
app.post('/forgot', loginLimiter, (req, res) => {
  const nickname = String(req.body.nickname || '').trim();
  const code = String(req.body.code || '').trim().toUpperCase();
  const password = String(req.body.password || '');
  const password2 = String(req.body.password2 || '');
  const form = { nickname, code };
  const fail = (msg) => { req.loginFailed(); return res.status(400).render('forgot', { title: '비밀번호 재설정', error: msg, form }); };
  const user = nickname && dbm.findUserByNickname(nickname);
  const c = code && dbm.findCode(code);
  if (!user || !c || c.used_by !== user.id) return fail('닉네임과 입장 코드가 서로 맞지 않아요. 구매할 때 받은 파일의 코드를 다시 확인해 주세요.');
  if (password.length < 6) return fail('새 비밀번호는 6자 이상으로 해 주세요.');
  if (password !== password2) return fail('새 비밀번호 두 칸이 서로 달라요.');
  dbm.setPassword(user.id, bcrypt.hashSync(password, 10));
  dbm.logLogin({ userId: user.id, ip: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 200), result: 'password_reset' });
  req.loginSucceeded();
  setFlash(req, 'ok', '비밀번호를 새로 만들었어요. 이제 로그인하세요.');
  res.redirect('/login');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

app.get('/signup', (req, res) => {
  if (req.user) return res.redirect('/');
  const code = String(req.query.code || '').trim().toUpperCase();
  res.render('signup', { title: '입장 코드로 가입', code, error: null, form: {} });
});

app.post('/signup', loginLimiter, (req, res) => {
  if (req.user) return res.redirect('/');
  const code = String(req.body.code || '').trim().toUpperCase();
  const company = String(req.body.company || '').trim().replace(/[\[\]\/]/g, '');
  const password = String(req.body.password || '');
  const password2 = String(req.body.password2 || '');
  const cheer = String(req.body.cheer || '').trim().slice(0, 100);
  const form = { code, company, cheer };
  const fail = (msg) => { req.loginFailed(); return res.status(400).render('signup', { title: '입장 코드로 가입', code, error: msg, form }); };

  if (!/^SJ\d-[A-Z0-9]{4}$/.test(code)) return fail('입장 코드 형식이 맞지 않아요. 예: SJ1-AB12');
  const c = dbm.findCode(code);
  if (!c) return fail('등록되지 않은 입장 코드예요. 구매 시 받은 파일의 코드를 다시 확인해 주세요.');
  if (c.used_by) return fail('이미 사용된 입장 코드예요. 코드 1개로는 계정 1개만 만들 수 있어요.');
  if (company.length < 1 || company.length > 20) return fail('업체명(또는 이름)은 1~20자로 적어 주세요.');
  if (password.length < 6) return fail('비밀번호는 6자 이상으로 해 주세요.');
  if (password !== password2) return fail('비밀번호 두 칸이 서로 달라요.');

  const nickname = `${company}/${COHORT}`;
  if (dbm.findUserByNickname(nickname)) return fail(`"${nickname}" 닉네임은 이미 있어요. 업체명을 조금 바꿔 주세요.`);

  let user;
  try {
    user = dbm.createUserWithCode({ nickname, passwordHash: bcrypt.hashSync(password, 10), cheerMessage: cheer, code });
  } catch (e) {
    return fail('가입 처리 중 문제가 생겼어요. 코드가 방금 사용됐을 수 있어요.');
  }
  req.loginSucceeded();
  const devId = deviceIdOf(req, res);
  dbm.registerDevice(user.id, devId, (req.get('user-agent') || '').slice(0, 200));
  dbm.logLogin({ userId: user.id, deviceId: devId, ip: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 200), result: 'ok' });
  req.session.regenerate(() => {
    req.session.userId = user.id;
    res.redirect('/consent');
  });
});

// ───────────────────────── 동의 화면 ─────────────────────────
app.get('/consent', requireUser, (req, res) => {
  if (req.user.consent_at) return res.redirect('/');
  res.render('consent', { title: '입장 전 동의', consent: consentText, error: null });
});

app.post('/consent', requireUser, (req, res) => {
  if (req.user.consent_at) return res.redirect('/');
  const refund = req.body.agree_refund === 'on';
  const copy = req.body.agree_copy === 'on';
  const privacy = req.body.agree_privacy === 'on';
  if (!refund || !copy || !privacy) {
    return res.status(400).render('consent', { title: '입장 전 동의', consent: consentText, error: '세 항목 모두 확인·동의해야 입장할 수 있어요.' });
  }
  dbm.recordConsent({ userId: req.user.id, version: consentText.VERSION, refund, copy, privacy, ip: req.ip, userAgent: req.get('user-agent') });
  setFlash(req, 'ok', '동의가 저장되었어요. 환영합니다!');
  res.redirect('/');
});

// ───────────────────────── 대시보드 ─────────────────────────
app.get('/', requireUser, requireConsent, (req, res) => {
  const p = dbm.progressOf(req.user);
  const missions = dbm.listMissions();
  const titles = new Map(missions.map((m) => [m.day, m.title]));
  const notifications = dbm.unreadNotifications(req.user.id);
  dbm.markNotificationsRead(req.user.id);
  const feedback = dbm.recentFeedbackForUser(req.user.id, 5);
  const pool = [...CHEERS];
  if (req.user.cheer_message) pool.push(req.user.cheer_message, req.user.cheer_message); // 본인 메시지 가중
  const cheer = pool[Math.floor(Math.random() * pool.length)];
  res.render('dashboard', {
    title: '대시보드', p, titles, notifications, feedback, cheer,
    cheerIsMine: cheer === req.user.cheer_message,
  });
});

// ───────────────────────── Day 페이지 ─────────────────────────
app.get('/day/:n', requireUser, requireConsent, parseDay, (req, res) => {
  const day = req.day;
  const p = dbm.progressOf(req.user);
  const info = p.days[day - 1];
  const mission = dbm.getMission(day);
  if (!info.unlocked) {
    return res.status(403).render('day_locked', { title: `Day ${day} 잠김`, day, mission, p });
  }
  dbm.logAccess(req.user.id, day);
  const history = dbm.submissionHistory(req.user.id, day);
  const latest = history[0] || null;
  const canSubmit = !latest || latest.status === 'revision';
  const html = md.render(mission.body_md);
  res.render('day', {
    title: `Day ${day} · ${mission.title}`, day, mission, html, history, latest, canSubmit, p,
    watermark: `[${req.user.nickname}] 전용 · 재배포 금지`,
    prevDay: day > 1 ? day - 1 : null,
    nextDay: day < dbm.TOTAL_DAYS ? day + 1 : null,
    nextUnlocked: day < dbm.TOTAL_DAYS ? p.days[day].unlocked : false,
  });
});

app.get('/day/:n/submit', requireUser, requireConsent, parseDay, (req, res) => {
  const day = req.day;
  const p = dbm.progressOf(req.user);
  if (!p.days[day - 1].unlocked) return res.redirect(`/day/${day}`);
  const latest = dbm.latestSubmission(req.user.id, day);
  if (latest && latest.status !== 'revision') {
    setFlash(req, 'info', latest.status === 'approved' ? '이미 승인된 미션이에요.' : '검토 대기 중이에요. 결과가 나오면 알려드릴게요.');
    return res.redirect(`/day/${day}`);
  }
  const mission = dbm.getMission(day);
  res.render('submit', { title: `Day ${day} 제출`, day, mission, latest, error: null });
});

app.post('/day/:n/submit', requireUser, requireConsent, parseDay, (req, res) => {
  const day = req.day;
  const p = dbm.progressOf(req.user);
  if (!p.days[day - 1].unlocked) return res.status(403).redirect(`/day/${day}`);
  const latest = dbm.latestSubmission(req.user.id, day);
  if (latest && latest.status !== 'revision') return res.redirect(`/day/${day}`);
  const mission = dbm.getMission(day);

  upload.array('images', 3)(req, res, (err) => {
    const files = req.files || [];
    const cleanup = () => files.forEach((f) => fs.unlink(f.path, () => {}));
    const fail = (msg, code = 400) => {
      cleanup();
      res.status(code).render('submit', { title: `Day ${day} 제출`, day, mission, latest, error: msg });
    };
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return fail('이미지 1장은 5MB 이하여야 해요. 폰 캡처는 보통 1~2MB입니다.');
      if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') return fail('이미지는 최대 3장까지예요.');
      return fail(err.message || '업로드 중 문제가 생겼어요.');
    }
    if (files.length < 1) return fail('캡처 이미지를 1장 이상 올려 주세요.');
    const memo = String(req.body.memo || '').trim().slice(0, 2000);
    // 교재 개선 피드백: 객관식 3 + 주관식 2 (전부 선택). 읽기용 문장 + 구조(JSON) 둘 다 저장
    const fb = {
      difficulty: Number(req.body.fb_difficulty) || null,           // 1 쉬움 ~ 4 혼자선 못 함
      time: Number(req.body.fb_time) || null,                       // 분
      stuck: String(req.body.fb_stuck || '').trim().slice(0, 60),
      unclear: String(req.body.fb_unclear || '').trim().slice(0, 1000),
      wish: String(req.body.fb_wish || '').trim().slice(0, 1000),
    };
    const DIFF = { 1: '쉬움', 2: '보통', 3: '어려움', 4: '혼자선 못 함' };
    const parts = [];
    if (fb.difficulty) parts.push(`난이도: ${DIFF[fb.difficulty]}`);
    if (fb.time) parts.push(`걸린 시간: ${fb.time >= 120 ? '1시간 넘게' : fb.time + '분'}`);
    if (fb.stuck) parts.push(`멈춘 곳: ${fb.stuck}`);
    if (fb.unclear) parts.push(`이해 안 됨/화면 다름: ${fb.unclear}`);
    if (fb.wish) parts.push(`바꾸면 좋겠다: ${fb.wish}`);
    const feedback = parts.join('\n');
    const id = dbm.createSubmission({ userId: req.user.id, day, memo, feedback, feedbackJson: parts.length ? JSON.stringify(fb) : null, images: files });
    const kind = latest ? '재제출' : '제출';
    telegram.notifyAdmin(`📥 [${req.user.nickname}] Day ${day} ${kind}\n${mission.title}\n메모: ${memo ? memo.slice(0, 200) : '(없음)'}${feedback ? '\n💬 교재 피드백: ' + feedback.slice(0, 200) : ''}\n제출 #${id} · 이미지 ${files.length}장`);
    setFlash(req, 'ok', `Day ${day} 미션을 ${kind}했어요. 피드백이 오면 대시보드에 표시됩니다.`);
    res.redirect(`/day/${day}`);
  });
});

// 업로드 이미지 — 본인 또는 관리자만
app.get('/uploads/:file', requireUser, (req, res) => {
  const file = String(req.params.file || '');
  if (!/^[\w.-]+$/.test(file)) return res.status(404).end();
  const img = dbm.findImage(file);
  if (!img) return res.status(404).end();
  if (img.user_id !== req.user.id && !req.session.isAdmin) return res.status(403).end();
  res.set('Cache-Control', 'private, max-age=600');
  res.sendFile(path.join(dbm.UPLOAD_DIR, file));
});
// 관리자 전용 이미지 경로 (수강생 로그인 없이도 관리자 세션이면 열람)
app.get('/admin/uploads/:file', requireAdmin, (req, res) => {
  const file = String(req.params.file || '');
  if (!/^[\w.-]+$/.test(file) || !dbm.findImage(file)) return res.status(404).end();
  res.set('Cache-Control', 'private, max-age=600');
  res.sendFile(path.join(dbm.UPLOAD_DIR, file));
});

// ───────────────────────── 관리자 ─────────────────────────
app.get('/admin/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin');
  res.render('admin/login', { title: '관리자 로그인', error: null });
});
app.post('/admin/login', adminLimiter, (req, res) => {
  const pw = String(req.body.password || '');
  if (!bcrypt.compareSync(pw, ADMIN_HASH)) {
    req.loginFailed();
    return res.status(401).render('admin/login', { title: '관리자 로그인', error: '비밀번호가 맞지 않아요.' });
  }
  req.loginSucceeded();
  const userId = req.session.userId; // 수강생으로도 로그인돼 있으면 유지
  const to = req.session.returnTo && req.session.returnTo.startsWith('/admin') ? req.session.returnTo : '/admin';
  req.session.regenerate(() => {
    req.session.isAdmin = true;
    if (userId) req.session.userId = userId;
    res.redirect(to);
  });
});
app.post('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

function userRows() {
  return dbm.listUsers().map((u) => ({ user: u, p: dbm.progressOf(u) }));
}

// 화면 패치 자동 적용: 관리자가 버튼 한 번 → 고정 주소의 tar.gz(views/public/content)를 받아 덮어씀.
// server.js·lib 변경은 포함하지 않음(재시작 필요) — Shell 없이 디자인·교재 갱신을 하기 위한 장치.
const PATCH_URL = process.env.PATCH_URL || 'https://siljeon-ai-media.github.io/media/platform_patch.tar.gz';
app.post('/admin/update', requireAdmin, async (req, res) => {
  const { execFileSync } = require('child_process');
  const os = require('os');
  const tmpName = `patch-${Date.now()}.tar.gz`;
  const tmp = path.join(os.tmpdir(), tmpName);
  const tarOpt = { cwd: os.tmpdir(), encoding: 'utf8' }; // 윈도우 tar가 'C:'를 원격 호스트로 오해하지 않게 상대 경로로
  try {
    const r = await fetch(PATCH_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error(`다운로드 실패 HTTP ${r.status}`);
    fs.writeFileSync(tmp, Buffer.from(await r.arrayBuffer()));
    const list = execFileSync('tar', ['-tzf', tmpName], tarOpt).split('\n').filter(Boolean);
    const bad = list.find((f) => !/^(views|public|content)\//.test(f) || f.includes('..'));
    if (bad) throw new Error(`허용되지 않은 경로: ${bad}`);
    execFileSync('tar', ['-xzf', tmpName, '-C', __dirname], tarOpt);
    app.set('view cache', false);
    if (list.some((f) => f.startsWith('content/')) && typeof dbm.seedMissions === 'function') dbm.seedMissions();
    req.session.flash = { type: 'ok', text: `화면 패치 적용 완료 (${list.length}개 파일). 새로고침(Ctrl+Shift+R)하면 반영됩니다.` };
  } catch (e) {
    req.session.flash = { type: 'err', text: `패치 실패: ${e.message}` };
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
  res.redirect('/admin');
});

app.get('/admin', requireAdmin, (req, res) => {
  const s = dbm.stats();
  const rows = userRows();
  const stalled = rows.filter((r) => r.p.stalled && r.user.consent_at);
  const queue = dbm.pendingQueue();
  res.render('admin/index', { title: '관리자', s, stalled, queue: queue.slice(0, 5), queueTotal: queue.length, telegramOn: telegram.enabled() });
});

app.get('/admin/queue', requireAdmin, (req, res) => {
  const queue = dbm.pendingQueue();
  const recent = dbm.recentReviewed(20);
  res.render('admin/queue', { title: '제출 대기열', queue, recent });
});

app.get('/admin/submission/:id', requireAdmin, (req, res) => {
  const s = dbm.getSubmission(Number(req.params.id));
  if (!s) return res.status(404).render('error', { title: '없음', message: '제출을 찾을 수 없어요.' });
  const mission = dbm.getMission(s.day);
  const history = dbm.submissionHistory(s.user_id, s.day);
  const user = dbm.findUserById(s.user_id);
  res.render('admin/submission', { title: `제출 #${s.id}`, s, mission, history, user, p: dbm.progressOf(user) });
});

function doReview(req, res, asJson) {
  const id = Number(req.params.id);
  const action = String(req.body.action || (req.body.approve !== undefined ? 'approve' : (req.body.revision !== undefined ? 'revision' : '')));
  const comment = String(req.body.comment || '').trim().slice(0, 4000);
  if (!['approve', 'revision'].includes(action)) {
    return asJson ? res.status(400).json({ ok: false, error: 'action must be approve|revision' }) : res.status(400).send('bad action');
  }
  if (action === 'revision' && !comment) {
    if (asJson) return res.status(400).json({ ok: false, error: 'comment required for revision' });
    setFlash(req, 'err', '보완 요청에는 코멘트(무엇을 고칠지)를 꼭 적어 주세요.');
    return res.redirect(`/admin/submission/${id}`);
  }
  let updated;
  try {
    updated = dbm.reviewSubmission({ id, status: action === 'approve' ? 'approved' : 'revision', comment });
  } catch (e) {
    return asJson ? res.status(404).json({ ok: false, error: 'not found' }) : res.status(404).send('not found');
  }
  if (asJson) return res.json({ ok: true, submission: updated });
  setFlash(req, 'ok', action === 'approve' ? `제출 #${id} 승인 완료. 수강생에게 다음 Day가 열렸어요.` : `제출 #${id} 보완 요청을 보냈어요.`);
  res.redirect('/admin/queue');
}
app.post('/admin/submission/:id/review', requireAdmin, (req, res) => doReview(req, res, false));

app.get('/admin/users', requireAdmin, (req, res) => {
  res.render('admin/users', { title: '수강생 목록', rows: userRows() });
});
// 비밀번호 잊은 수강생: 관리자가 임시 비밀번호 발급 → DM으로 전달 → 본인이 로그인 후 사용 (변경 기능은 추후)
app.post('/admin/users/:id/reset-password', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (!u) return res.redirect('/admin/users');
  const temp = 'sj' + crypto.randomBytes(3).toString('hex'); // 예: sj3f9a1c (8자)
  dbm.setPassword(u.id, bcrypt.hashSync(temp, 10));
  setFlash(req, 'ok', `${u.nickname} 임시 비밀번호: ${temp}  — 수강생에게 DM으로 전달하세요. (이 화면을 닫으면 다시 볼 수 없어요)`);
  res.redirect('/admin/users');
});
app.get('/admin/feedback', requireAdmin, (req, res) => {
  res.render('admin/feedback', { title: '교재 피드백 모음', rows: dbm.allCourseFeedback(), stats: dbm.feedbackStats(), missions: dbm.listMissions() });
});
app.get('/api/admin/feedback', requireAdminApi, (req, res) => res.json({ ok: true, stats: dbm.feedbackStats(), rows: dbm.allCourseFeedback() }));
app.get('/admin/settings', requireAdmin, (req, res) => {
  res.render('admin/settings', { title: '운영 설정', contactLabel: dbm.getSetting('contact_label', CONTACT), contactUrl: dbm.getSetting('contact_url', 'https://www.instagram.com/siljeon.ai/') });
});
app.post('/admin/settings', requireAdmin, (req, res) => {
  const label = String(req.body.contact_label || '').trim().slice(0, 60);
  const url = String(req.body.contact_url || '').trim().slice(0, 300);
  if (url && !/^https?:\/\//.test(url)) { setFlash(req, 'err', '문의 링크는 https:// 로 시작해야 해요.'); return res.redirect('/admin/settings'); }
  if (label) dbm.setSetting('contact_label', label);
  if (url) dbm.setSetting('contact_url', url);
  setFlash(req, 'ok', '저장했어요. 모든 화면의 문의 버튼·문구에 바로 반영됩니다.');
  res.redirect('/admin/settings');
});
app.post('/admin/users/:id/reset-devices', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (u) { dbm.resetDevices(u.id); setFlash(req, 'ok', `${u.nickname} 등록 기기를 비웠어요. 다음 로그인 기기부터 다시 등록됩니다.`); }
  res.redirect('/admin/users');
});
app.get('/admin/security', requireAdmin, (req, res) => {
  res.render('admin/security', { title: '보안 점검', rows: dbm.securityReport(7), maxDevices: dbm.MAX_DEVICES });
});
app.post('/admin/security/warn', requireAdmin, (req, res) => {
  const warned = dbm.autoWarnSuspicious();
  setFlash(req, 'ok', warned.length ? `경고 알림 보냄: ${warned.join(', ')}` : '경고 대상이 없어요.');
  res.redirect('/admin/security');
});
app.get('/api/admin/security', requireAdminApi, (req, res) => res.json({ ok: true, maxDevices: dbm.MAX_DEVICES, rows: dbm.securityReport(Number(req.query.days) || 7) }));
app.post('/admin/users/:id/graduate', requireAdmin, (req, res) => {
  const u = dbm.findUserById(Number(req.params.id));
  if (u) {
    dbm.setGraduate(u.id, !u.is_graduate);
    setFlash(req, 'ok', `${u.nickname} 졸업생 모드 ${u.is_graduate ? '해제' : '켬'}.`);
  }
  res.redirect('/admin/users');
});

function csv(rows, headers) {
  const esc = (v) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [headers.map((h) => esc(h.label)).join(',')];
  for (const r of rows) lines.push(headers.map((h) => esc(typeof h.get === 'function' ? h.get(r) : r[h.key])).join(','));
  return '﻿' + lines.join('\r\n');
}
app.get('/admin/users.csv', requireAdmin, (req, res) => {
  const rows = userRows();
  const body = csv(rows, [
    { label: '닉네임', get: (r) => r.user.nickname },
    { label: '가입일', get: (r) => fmt(r.user.created_at) },
    { label: '동의시각', get: (r) => fmt(r.user.consent_at) },
    { label: '승인 미션 수', get: (r) => r.p.approvedCount },
    { label: '진행률(%)', get: (r) => r.p.percent },
    { label: '마지막 제출', get: (r) => fmt(r.p.lastSubmittedAt) },
    { label: '마지막 승인', get: (r) => fmt(r.p.lastApprovedAt) },
    { label: '정체 일수', get: (r) => r.p.stallDays },
    { label: '대기 중 제출', get: (r) => r.p.pendingCount },
    { label: '졸업생 모드', get: (r) => (r.user.is_graduate ? 'Y' : 'N') },
    { label: '마지막 로그인', get: (r) => fmt(r.user.last_login_at) },
  ]);
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="users-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(body);
});
app.get('/admin/submissions.csv', requireAdmin, (req, res) => {
  const rows = dbm.allSubmissions();
  const body = csv(rows, [
    { label: '제출ID', key: 'id' },
    { label: '닉네임', key: 'nickname' },
    { label: 'Day', key: 'day' },
    { label: '상태', get: (r) => STATUS_LABEL[r.status] || r.status },
    { label: '제출시각', get: (r) => fmt(r.created_at) },
    { label: '검토시각', get: (r) => fmt(r.reviewed_at) },
    { label: '이미지 수', key: 'image_count' },
    { label: '메모', key: 'memo' },
    { label: '교재 피드백', key: 'feedback' },
    { label: '코멘트', key: 'comment' },
  ]);
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="submissions-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(body);
});

app.get('/admin/codes', requireAdmin, (req, res) => {
  const codes = dbm.listCodes();
  const made = req.session.madeCodes || null;
  delete req.session.madeCodes;
  res.render('admin/codes', { title: '입장 코드', codes, made, baseUrl: `${req.protocol}://${req.get('host')}` });
});
app.post('/admin/codes', requireAdmin, (req, res) => {
  const n = Math.min(100, Math.max(1, Number(req.body.count) || 1));
  req.session.madeCodes = dbm.createCodes(n);
  res.redirect('/admin/codes');
});

app.get('/admin/missions', requireAdmin, (req, res) => {
  res.render('admin/missions', { title: '미션 목록', missions: dbm.listMissions() });
});
app.get('/admin/day/:n/edit', requireAdmin, parseDay, (req, res) => {
  const mission = dbm.getMission(req.day);
  res.render('admin/day_edit', { title: `Day ${req.day} 편집`, day: req.day, mission, preview: md.render(mission.body_md) });
});
app.post('/admin/day/:n/edit', requireAdmin, parseDay, (req, res) => {
  const body = String(req.body.body_md || '');
  const title = String(req.body.title || '').trim().replace(/^Day\s*\d+\s*[—–:\-]\s*/i, '') || dbm.extractTitle(body, req.day);
  dbm.updateMission(req.day, title, body);
  setFlash(req, 'ok', `Day ${req.day} 미션을 저장했어요. (파일보다 이 내용이 우선 적용됩니다)`);
  res.redirect(`/admin/day/${req.day}/edit`);
});

// ───────────────────────── 관리자 API (로디의 AI 1차 피드백용) ─────────────────────────
// 헤더 X-Admin-Password: <ADMIN_PASSWORD>
app.get('/api/admin/queue', requireAdminApi, (req, res) => {
  res.json({ ok: true, queue: dbm.pendingQueue() });
});
app.get('/api/admin/submission/:id', requireAdminApi, (req, res) => {
  const s = dbm.getSubmission(Number(req.params.id));
  if (!s) return res.status(404).json({ ok: false, error: 'not found' });
  res.json({ ok: true, submission: s, history: dbm.submissionHistory(s.user_id, s.day) });
});
app.post('/api/admin/submission/:id/review', requireAdminApi, (req, res) => doReview(req, res, true));

app.get('/healthz', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ───────────────────────── 404 / 오류 ─────────────────────────
app.use((req, res) => res.status(404).render('error', { title: '페이지 없음', message: '요청하신 페이지를 찾을 수 없어요.' }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[server error]', err);
  if (res.headersSent) return;
  res.status(500).render('error', { title: '오류', message: '서버에 문제가 생겼어요. 잠시 후 다시 시도해 주세요.' });
});

// 6시간마다 자동: 최근 7일 차단 시도 2회 이상 계정에 대시보드 경고 + 관리자 텔레그램 알림
setInterval(() => {
  try {
    const warned = dbm.autoWarnSuspicious();
    if (warned.length) telegram.notifyAdmin(`🔒 계정 공유 의심 자동 경고 발송: ${warned.join(', ')}`);
  } catch (e) { console.error('[security scan]', e); }
}, 6 * 60 * 60 * 1000).unref();

const server = app.listen(PORT, () => {
  console.log(`✅ siljeon.ai 챌린지 플랫폼 실행 중: http://localhost:${PORT}`);
  console.log(`   관리자: http://localhost:${PORT}/admin  ·  텔레그램 알림: ${telegram.enabled() ? '켜짐' : '꺼짐(ENV 없음)'}`);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));

module.exports = app;
