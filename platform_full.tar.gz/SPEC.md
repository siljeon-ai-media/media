# siljeon.ai 1기 챌린지 플랫폼 — 사양 v1 (2026-09-11)

목적: "AI 직원 1명 출근" 4주 기수제의 **미션 승인제 학습 플랫폼**. 윤익 3기 플랫폼(대시보드·데일리 미션·제출·멘토 피드백·잠금)과 동급 기능을 최소 코드로. 호스팅 = Replit(대표 구독, Reserved VM 또는 Autoscale+외부 DB). 운영자 = 로디(AI 1차 피드백) + 대표(결재).

## 핵심 규칙
1. **입장 코드 로그인**: 리틀리 구매 후 받는 txt의 코드(예 `SJ1-XXXX`)로 첫 가입 → 닉네임 `[업체명/1기]` + 비밀번호. 코드 1개 = 계정 1개. 관리자가 코드 발급.
2. **미션 20개(Day 1~20)**: 마크다운 본문(제목·오늘 할 일·순서·복사 버튼 프롬프트/코드·미션 체크리스트·제출물 안내). Day N은 **Day N-1이 "승인"되어야 열림**. Day 1은 항상 열림. 졸업생 모드(플래그)면 전부 열람.
3. **제출**: 이미지 1~3장(캡처) + 메모(선택). 상태 = 제출됨 → AI 피드백 → 승인/보완요청. 보완요청이면 재제출 가능. 모든 이력 보관(환불 분쟁 증거).
4. **피드백**: 관리자 화면에서 텍스트 코멘트 + 승인/보완 버튼. (AI 1차 피드백은 관리자 API를 로디가 호출해 넣음 — 별도 자동화, 플랫폼은 코멘트 필드만 제공.)
5. **텔레그램 알림**(선택, 환경변수 있으면): 제출 시 관리자 채팅으로 "닉네임 Day N 제출" / 승인 시 수강생에게는 플랫폼 내 알림 표시(텔레그램 개인 알림은 2단계).
6. **대시보드**: 진행률(%), 주차별 %, 오늘 미션, 응원 메시지 1줄(가입 시 입력, 랜덤 표시), 최근 피드백.
7. **관리자**: 코드 발급·목록, 수강생 목록(진행률·마지막 제출·정체 일수), 제출 대기열(오래된 순), 미션 본문 편집(마크다운), 졸업생 모드 토글, CSV 내보내기.
8. **동의 화면**: 첫 로그인 시 환불 규정·복제 금지·개인정보 동의 체크(타임스탬프 저장) — `환불정책_조사` §5 문구.
9. **워터마크**: 미션 본문 상단·하단에 "[닉네임] 전용 · 재배포 금지" 표시(캡처 억제용, 서버 렌더).
10. **3일 정체 감지**: 마지막 승인 후 3일 지나면 대시보드에 "따라잡기 미션" 배너 + 관리자 목록에 표시.

## 기술
- Node 20, Express, 서버 렌더(EJS 또는 템플릿 문자열), 세션 쿠키(express-session, 메모리 X → 파일/DB). DB = SQLite(better-sqlite3) 파일 `data/app.db`, 업로드 `data/uploads/` — Reserved VM에서 영속. (Autoscale이면 ENV로 Postgres 전환 가능하게 DB 접근을 한 모듈로 격리.)
- 마크다운 렌더(marked), 이미지 업로드(multer, 5MB, jpg/png/webp), 비밀번호 bcrypt.
- 룩: 다크(#121212) + 그린(#34E27A), Pretendard 계열 시스템 폰트, 모바일 우선(수강생은 폰으로 캡처 제출).
- 미션 콘텐츠는 `content/day01.md ~ day20.md` 파일 → 서버 시작 시 DB에 시드(관리자 편집 시 DB 우선).
- ENV: `SESSION_SECRET`, `ADMIN_PASSWORD`, `TELEGRAM_BOT_TOKEN`(선택), `TELEGRAM_ADMIN_CHAT_ID`(선택), `PORT`.
- 실행: `npm start`. Replit: `.replit` + `replit.nix` 없이 Node 템플릿에서 `npm install && npm start`.

## 화면
`/login` `/signup?code=` `/consent` `/` (대시보드) `/day/:n` `/day/:n/submit` `/admin` `/admin/queue` `/admin/users` `/admin/codes` `/admin/day/:n/edit`

## 산출물
`platform/` 폴더: `package.json`, `server.js`, `db.js`, `views/*.ejs`, `public/style.css`, `content/day01.md`(샘플 3개: day01·day02·day05 진단), `README.md`(Replit 배포 순서, 비개발자용 한국어), `seed_codes.js`(코드 20개 생성).
