/* 클라이언트 스크립트: 코드블록 복사 버튼, 이미지 미리보기, 제출 버튼 중복 방지 */
(function () {
  'use strict';

  // 0) 한국어 줄바꿈 보정 — 폭이 아니라 "의미 단위"로 끊기게 (2026-09-11, 대표 지적: 폰에서 줄바꿈 어색)
  //    브라우저는 단어(공백)에서만 끊을 뿐 구(句)를 모른다. 붙어 있어야 자연스러운 조각을 붙임표(nbsp)로 묶는다.
  //    텍스트 노드만 건드리므로 아이콘·태그는 그대로. 대상: 제목·문단·미션 제목(.kb 또는 아래 선택자).
  (function koreanBreaks() {
    var NB = ' ';
    var SEL = '.hero .h, .hero .lede, .done-hero .lede, .day-head h1, h1, h2, .day-item .t, .q, .cheer, .lede, .meta-line, .day-head .m, .notif, .banner, .mission p, .mission li, .mission h3, .help, .card-hd .sub';
    var rules = [
      [/(\d+)\s(분|장|개|일|주차|주|명|시간|초|회|건|줄|가지|단계)(?=[^가-힣]|$)/g, '$1' + NB + '$2'],      // 10 분 → 10분(붙임)
      [/Day\s(\d+)/g, 'Day' + NB + '$1'],                                                         // Day 2
      [/(\d+)\s\/\s(\d+)/g, '$1' + NB + '/' + NB + '$2'],                                            // 1 / 20
      [/\s(→|←|—|·|\+)\s/g, NB + '$1 '],                                                              // 화살표·대시·가운뎃점은 줄 첫머리에 못 오게
      [/(^|\s)(첫|새|내|두|세|네|한|각|매|총|약|전|후|이번|다음|오늘|어제|내일|우리|모든|같은|다른|작은|큰)\s(?=[가-힣])/g, '$1$2' + NB], // 짧은 수식어는 뒤 명사에 붙임
      [/"([^"\n]{1,16})"/g, function (m, inner) { return '"' + inner.replace(/\s/g, NB) + '"'; }],      // 짧은 따옴표 구절은 한 덩어리
      [/(\s?)\(([^()\n]{1,10})\)/g, function (m, sp, inner) { return (sp ? NB : '') + '(' + inner.replace(/\s/g, NB) + ')'; }]   // 짧은 괄호 구절은 앞 단어에 붙임
    ];
    var targets = document.querySelectorAll(SEL);
    var walker, node, list;
    targets.forEach(function (el) {
      if (el.hasAttribute('data-kb-done')) return;
      el.setAttribute('data-kb-done', '1');
      list = [];
      walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      while ((node = walker.nextNode())) { if (node.nodeValue && /\S/.test(node.nodeValue) && !(node.parentNode && /^(CODE|PRE|SCRIPT|STYLE)$/.test(node.parentNode.nodeName))) list.push(node); }
      list.forEach(function (n) {
        var t = n.nodeValue;
        rules.forEach(function (r) { t = t.replace(r[0], r[1]); });
        if (t !== n.nodeValue) n.nodeValue = t;
      });
    });
  })();

  // 1) 코드블록마다 "복사하기" 버튼 부착
  function legacyCopy(text) {
    return new Promise(function (resolve, reject) {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.left = '-9999px';
      document.body.appendChild(ta); ta.focus(); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      ok ? resolve() : reject(new Error('copy failed'));
    });
  }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).catch(function () { return legacyCopy(text); });
    }
    return legacyCopy(text);
  }

  document.querySelectorAll('.codeblock').forEach(function (block) {
    if (block.querySelector('.copy-btn')) return;
    var code = block.querySelector('pre code') || block.querySelector('pre');
    var lang = block.getAttribute('data-lang');
    if (lang) { var l = document.createElement('span'); l.className = 'lang'; l.textContent = lang; block.appendChild(l); }
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'copy-btn'; btn.textContent = '복사하기';
    btn.addEventListener('click', function () {
      copyText(code.textContent).then(function () {
        btn.textContent = '복사됨 ✓'; btn.classList.add('done');
        setTimeout(function () { btn.textContent = '복사하기'; btn.classList.remove('done'); }, 1800);
      }).catch(function () { btn.textContent = '복사 실패'; });
    });
    block.appendChild(btn);
  });

  // 마크다운 코드블록이 래퍼 없이 렌더된 경우도 대비 (관리자 미리보기 등)
  document.querySelectorAll('.mission pre').forEach(function (pre) {
    if (pre.closest('.codeblock')) return;
    var wrap = document.createElement('div'); wrap.className = 'codeblock';
    pre.parentNode.insertBefore(wrap, pre); wrap.appendChild(pre);
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'copy-btn'; btn.textContent = '복사하기';
    btn.addEventListener('click', function () {
      copyText(pre.textContent).then(function () { btn.textContent = '복사됨 ✓'; setTimeout(function () { btn.textContent = '복사하기'; }, 1800); });
    });
    wrap.appendChild(btn);
  });

  // 2) 제출 폼: 이미지 미리보기 + 10MB/3장 사전 검사(문제 있으면 전송 차단) + 중복 제출 방지
  var fileInput = document.querySelector('input[type=file][name=images]');
  if (fileInput) {
    var grid = document.getElementById('preview');
    var msg = document.getElementById('file-msg');
    var lastProblems = [];
    fileInput.addEventListener('change', function () {
      if (grid) grid.innerHTML = '';
      var files = Array.prototype.slice.call(fileInput.files || []);
      var problems = [];
      if (files.length > 3) problems.push('이미지는 최대 3장까지예요.');
      files.forEach(function (f) {
        if (f.size > 10 * 1024 * 1024) problems.push(f.name + ' 은(는) 10MB를 넘어요. 사진 앱에서 자르기 후 저장하면 작아져요.');
        if (!/^image\/(jpeg|png|webp)$/.test(f.type)) problems.push(f.name + ' 은(는) jpg/png/webp가 아니에요.');
        if (grid && /^image\//.test(f.type)) {
          var img = document.createElement('img'); img.src = URL.createObjectURL(f); grid.appendChild(img);
        }
      });
      if (msg) { msg.textContent = problems.length ? problems.join(' ') : (files.length ? files.length + '장 선택됨' : ''); msg.style.color = problems.length ? '#ff6b6b' : ''; }
      lastProblems = problems;
    });
    // 문제가 있으면 서버로 보내지 않는다 — 보냈다가 거절되면 쓴 메모가 사라지므로 (2026-09-14)
    var submitForm = fileInput.closest('form');
    if (submitForm) submitForm.addEventListener('submit', function (e) {
      if (lastProblems.length) { e.preventDefault(); if (msg) msg.scrollIntoView({ block: 'center' }); alert(lastProblems.join('
')); }
    }, true);
  }

  document.querySelectorAll('form[data-once]').forEach(function (form) {
    form.addEventListener('submit', function () {
      setTimeout(function(){ form.querySelectorAll('button[type=submit]').forEach(function(btn){ btn.disabled = true; btn.textContent = '전송 중...'; }); }, 0);
    });
  });

  // 2-1) 진행 바: 그려진 뒤 목표 폭으로 (reduced-motion이면 CSS에서 transition 제거됨)
  var bars = document.querySelectorAll('.progress > span[data-w]');
  if (bars.length) {
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      bars.forEach(function (b) { b.style.width = (Number(b.getAttribute('data-w')) || 0) + '%'; });
    }); });
  }

  // 2-2) 미션 체크리스트 체크 상태를 이 브라우저에 기억 (Day별)
  var checks = document.querySelectorAll('.mission .task-check');
  if (checks.length) {
    var key = 'sj.task.' + location.pathname;
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem(key) || '{}'); } catch (e) { saved = {}; }
    checks.forEach(function (c, i) {
      c.disabled = false;
      if (saved[i]) c.checked = true;
      c.addEventListener('change', function () {
        saved[i] = c.checked;
        try { localStorage.setItem(key, JSON.stringify(saved)); } catch (e) {}
      });
    });
  }

  // 2-3) 동의 화면: 세 칸 다 체크해야 버튼이 켜짐 (폰에서 '확인란을 선택하세요' 브라우저 경고 대신 우리 말로 안내)
  var cbtn = document.getElementById('consent-btn');
  if (cbtn) {
    cbtn.disabled = true;   // JS가 안 뜨면 required 체크만으로 제출되게, 켜졌을 때만 잠근다 (2026-09-14)
    var boxes = Array.prototype.slice.call(document.querySelectorAll('form[action="/consent"] input[type=checkbox]'));
    var hint = document.getElementById('consent-hint');
    var sync = function () {
      var n = boxes.filter(function (b) { return b.checked; }).length;
      cbtn.disabled = n < boxes.length;
      if (hint) hint.textContent = n < boxes.length ? '세 칸을 모두 체크하면 버튼이 켜집니다 (' + n + '/' + boxes.length + ')' : '좋아요. 아래 버튼을 누르면 입장합니다.';
    };
    boxes.forEach(function (b) { b.addEventListener('change', sync); });
    sync();
  }

  // 3) 코드 목록 전체 복사 (관리자)
  var copyAll = document.getElementById('copy-codes');
  if (copyAll) {
    copyAll.addEventListener('click', function () {
      var src = document.getElementById('codes-out');
      copyText(src.textContent).then(function () { copyAll.textContent = '복사됨 ✓'; });
    });
  }
})();
