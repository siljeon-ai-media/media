/**
 * 입장 코드 20개 생성 → DB 저장 → 콘솔 출력
 * 실행: node seed_codes.js            (20개)
 *       node seed_codes.js 50         (개수 지정)
 */
'use strict';

const dbm = require('./db');

const count = Math.min(500, Math.max(1, Number(process.argv[2]) || 20));
const codes = dbm.createCodes(count);

console.log(`\n입장 코드 ${codes.length}개 발급 완료 (형식 SJ1-XXXX, DB: data/app.db)\n`);
for (const c of codes) console.log(c);
console.log(`\n가입 링크 예시: http://localhost:${process.env.PORT || 3000}/signup?code=${codes[0]}`);
console.log('구매자에게는 코드 1개씩 txt로 전달하세요. 코드 1개 = 계정 1개.\n');
