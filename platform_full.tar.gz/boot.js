// 실행 관리자(감시자): server.js 를 자식으로 띄우고, 꺼지면 다시 띄운다.
// 왜: 로디의 전체 배포(/api/admin/update?scope=full&restart=1)는 적용 뒤 서버를 스스로 끄는데,
//     호스팅(레플릿 Reserved VM 등)이 꺼진 프로세스를 다시 살려주는지에 기대지 않고 우리가 직접 살린다. (2026-09-12)
const { spawn } = require('child_process');
const path = require('path');

let child = null;
let recent = []; // 최근 시작 시각들 — 짧은 시간에 반복 죽으면 잠시 쉰다
function start() {
  const now = Date.now();
  recent = recent.filter((t) => now - t < 60 * 1000).concat(now);
  const delayNext = recent.length >= 5 ? 15000 : 1000;
  console.log(`[boot] server.js 시작 (${new Date().toISOString()})`);
  child = spawn(process.execPath, [path.join(__dirname, 'server.js')], { stdio: 'inherit', env: process.env });
  child.on('exit', (code, sig) => {
    console.log(`[boot] server.js 종료 code=${code} sig=${sig || ''} → ${delayNext / 1000}초 뒤 다시 시작`);
    child = null;
    setTimeout(start, delayNext);
  });
}
for (const s of ['SIGTERM', 'SIGINT']) {
  process.once(s, () => { try { if (child) child.kill(s); } catch {} process.exit(0); });
}
start();
