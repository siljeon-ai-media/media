# Day 6 — 사무실 프로그램 설치: 첫 아침 보고 받기

> **오늘 만드는 것**: 앞으로 20일 동안 모든 직원이 일하는 **"우리 회사 사무실 프로그램"**(v2 비서실장 모드) 1개 + 첫 **아침 보고**
> **걸리는 시간**: 약 20분
> **필요한 것**: 컴퓨터(크롬) + Day 2 메모(토큰·Gemini 키·시트 주소) + Day 4에서 만든 Apps Script

> 오늘 붙여넣는 코드가 **이 과정의 마지막 코드**입니다. Day 7부터 Day 20까지는 코드를 다시 붙이지 않습니다. 부서를 만들고, 부서방에 말을 걸고, 시트를 보는 것만 합니다. 이 프로그램은 **부서방 이름**(보고팀·고객응대팀·콘텐츠팀·인사팀·시장조사팀·광고팀·정산팀)을 보고 알아서 그 부서 일을 합니다.

> **이 프로그램의 원리 — "직원이 먼저 움직이고, 사장님은 결재만"**: 사장님이 시키기 전에 부서가 먼저 일을 시작합니다(월요일 아침에 콘텐츠팀이 소재 10개를 올리고, 수요일 아침에 시장조사팀이 경쟁사를 살펴보고, 매일 저녁에 비서실장이 안 끝난 일을 챙깁니다). 사장님 허락이 필요한 것은 **보고팀 김대리(비서실장)**가 `🗂 결재 #번호`로 올리고, 사장님은 그 글에 **답장 한 줄**(승인/보류/번호)만 합니다. 이 구조는 Day 8에서 자세히 봅니다.

## 오늘 할 일 3가지
1. Day 4의 Apps Script 코드를 **사무실 프로그램**으로 통째로 바꿉니다(값 3줄).
2. `아침보고`를 한 번 실행해 보고팀에 **오늘 할 일 보고**를 받습니다.
3. 시트에 **기록 탭**들이 자동으로 생긴 것을 확인합니다.

## 순서

### 1단계 · 코드 통째로 바꾸기 (8분)
Apps Script 프로젝트를 엽니다(`script.google.com` → 내 프로젝트 → 제목 없는 프로젝트). 코드 칸을 누르고 **Ctrl + A → Delete**로 전부 지운 뒤, 아래 상자를 **복사하기 → Ctrl + V**. 길어 보여도 붙여넣기만 하면 됩니다.

```javascript
// ===== 여기 3줄만 내 값으로 바꿉니다 (따옴표 안만) =====
const BOT_TOKEN  = "여기에_토큰_붙여넣기";      // Day 2 메모의 토큰
const GEMINI_KEY = "여기에_Gemini키_붙여넣기";  // Day 5 메모의 Gemini 키 (없으면 빈칸 "" 도 됩니다)
const SHEET_URL  = "여기에_시트주소_붙여넣기";   // Day 3 메모의 우리 회사 정보 시트 주소
// ======================================================
// ▼ 아래는 건드리지 않습니다. "우리 회사 사무실 프로그램" v2 — 비서실장 모드 (2026-09-13)
//   부서가 스스로 일을 시작하고, 비서실장(보고팀 김대리)이 결재를 올립니다. 사장님은 답장으로 승인/보류만.
//   부서: 보고팀(비서실장) / 고객응대팀 / 콘텐츠팀 / 인사팀 / 시장조사팀 / 광고팀 / 정산팀

const API = "https://api.telegram.org/bot" + BOT_TOKEN;
const 저장소 = PropertiesService.getScriptProperties();

// ---------- 처음 한 번: 설치 (Day 7) ----------
function 설치() {
  탭준비();
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));
  const 설정 = 설정읽기();
  ScriptApp.newTrigger("아침보고").timeBased().atHour(Number(설정["보고 시각"] || 8)).everyDays(1).inTimezone("Asia/Seoul").create();
  ScriptApp.newTrigger("직원업무").timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger("주간요약").timeBased().onWeekDay(ScriptApp.WeekDay.FRIDAY).atHour(17).inTimezone("Asia/Seoul").create();
  ScriptApp.newTrigger("월요소재").timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).inTimezone("Asia/Seoul").create();      // 콘텐츠팀이 먼저 소재를 올림
  ScriptApp.newTrigger("경쟁사정찰").timeBased().onWeekDay(ScriptApp.WeekDay.WEDNESDAY).atHour(7).inTimezone("Asia/Seoul").create(); // 시장조사팀이 먼저 정찰함
  ScriptApp.newTrigger("저녁정리").timeBased().atHour(18).everyDays(1).inTimezone("Asia/Seoul").create();                         // 비서실장이 미결재·할일을 챙김
  ScriptApp.newTrigger("월정산").timeBased().onMonthDay(1).atHour(9).inTimezone("Asia/Seoul").create();                          // 정산팀이 지난달을 정리함
  Logger.log("✅ 설치 완료: 매일 " + (설정["보고 시각"] || 8) + "시 아침 보고 · 5분마다 부서 업무 · 월 7시 소재 제안 · 수 7시 경쟁사 정찰 · 매일 18시 저녁 정리 · 금 17시 주간 요약 · 매월 1일 월 정산");
  Logger.log("→ 왼쪽 시계 모양(트리거)을 누르면 7줄이 보입니다.");
}

// ---------- 매일 아침: 보고 (Day 6) ----------
function 아침보고() {
  let 방 = 방찾기("보고팀");
  if (!방) { 직원업무(); 방 = 방찾기("보고팀"); }
  if (!방) { Logger.log("② 보고팀 방을 아직 몰라요. 텔레그램 보고팀에 /start@내직원아이디 를 보내고 30초 뒤 다시 실행하세요."); return; }
  const 정보 = 회사정보(); const 설정 = 설정읽기();
  const 오늘 = new Date(); const 날짜 = Utilities.formatDate(오늘, "Asia/Seoul", "M월 d일") + " (" + ["월", "화", "수", "목", "금", "토", "일"][Number(Utilities.formatDate(오늘, "Asia/Seoul", "u")) - 1] + ")";
  const 어제결재 = 최근행("결재", 5).map(r => "- " + r[2]).join("\n") || "- (없음)";
  const 할일 = (정보["매일 반복하는 일 3개"] || "문의 답장, 재고 확인, SNS 올리기").split(/[,，/·]/).map(s => s.trim()).filter(Boolean).slice(0, 3);
  let 글 = null, 두뇌문제 = "";
  try { 글 = 두뇌("너는 아래 가게의 AI 직원 '보고팀 김대리'다. 오늘 아침 보고를 써라. 형식: 첫 줄 '☀️ " + 날짜 + " 아침 보고', 둘째 줄 " + (설정["호칭"] || 정보["사장님을 부르는 호칭"] || "사장님") + "께 한 줄 인사, 그 다음 '오늘 할 일' 번호 1~3 (아래 반복 업무 기준, 각 줄 끝에 짧은 팁 한 마디), 마지막 줄 '답장으로 결재해 주세요: 1 완료 / 2 보류 처럼'. 말투: " + (설정["말투"] || 정보["AI 직원에게 바라는 말투"] || "짧고 공손하게") + ". 10줄 이내.\n[가게 정보]\n" + 정보문장(정보) + "\n[반복 업무]\n" + 할일.join("\n") + "\n[어제 결재 기록]\n" + 어제결재); } catch (e) { 두뇌문제 = e.message; Logger.log("두뇌 문제(기본 형식으로 보냄): " + e.message); }
  if (!글) 글 = "☀️ " + 날짜 + " 아침 보고\n" + (설정["호칭"] || "사장님") + ", 좋은 아침입니다. 오늘 할 일입니다.\n" + 할일.map((h, i) => (i + 1) + ". " + h).join("\n") + "\n답장으로 결재해 주세요: 1 완료 / 2 보류 처럼" + (두뇌문제 ? "\n(두뇌 연결 문제로 기본 보고입니다: " + 두뇌문제.slice(0, 60) + ")" : "");
  const 대기 = 결재대기목록(); if (대기.length) 글 += "\n\n🗂 결재 기다리는 것 " + 대기.length + "건: " + 대기.map(r => "#" + r[0] + " " + r[3]).join(", ") + "\n(각 결재 글에 답장으로 승인/보류)";
  const 보낸것 = 보내기(방.chat, 방.thread, 글);
  기록("보고기록", [지금(), "아침보고", 글, 보낸것 && 보낸것.message_id]);
  Logger.log("✅ 아침 보고를 보고팀에 올렸습니다.");
}

// ---------- 5분마다: 부서방 새 글 처리 (Day 8~19) ----------
function 직원업무() {
  const 잠금 = LockService.getScriptLock(); if (!잠금.tryLock(5000)) return;   // 5분 트리거와 수동 실행이 겹쳐도 두 번 처리하지 않게
  try { 직원업무_실행(); } finally { 잠금.releaseLock(); }
}
function 직원업무_실행() {
  const offset = Number(저장소.getProperty("offset") || 0);
  const upd = JSON.parse(UrlFetchApp.fetch(API + "/getUpdates?timeout=0&limit=100&offset=" + offset, { muteHttpExceptions: true }).getContentText());
  let last = offset - 1;
  for (const u of (upd.result || [])) {
    last = u.update_id;
    const m = u.message; if (!m || !m.chat || m.chat.type === "private" || !m.text) continue;
    if (m.from && m.from.is_bot) continue;
    const 부서 = 부서이름(m);
    방저장(부서, m.chat.id, m.message_thread_id || null);
    try { 처리(부서, m); } catch (e) { 보내기(m.chat.id, m.message_thread_id, "⚠️ 처리 중 문제: " + e.message.slice(0, 120)); }
  }
  저장소.setProperty("offset", String(last + 1));
}

function 처리(부서, m) {
  const t = m.text.trim();
  if (t.indexOf("/start") === 0) { 보내기(m.chat.id, m.message_thread_id, "✅ " + 부서 + " 방을 기억했습니다."); return; }
  const 답 = (글) => 보내기(m.chat.id, m.message_thread_id, 글);
  const 답장인가 = !!(m.reply_to_message && m.reply_to_message.from && m.reply_to_message.from.is_bot);
  const 결재번호 = 답장인가 ? ((m.reply_to_message.text || "").match(/^🗂 결재 #(\d+)/) || [])[1] : null;
  if (결재번호) { if (결재답장(Number(결재번호), t, m)) return; }                  // 비서실장이 올린 결재에 답장 = 승인/보류/번호 (끝난 결재에 "올렸어요" 같은 말은 일반 처리로)
  if (부서 === "시장조사팀" && /경쟁사\s*등록/.test(t)) {                            // Day 17: 경쟁사 등록 → 매주 수요일 자동 정찰
    const 링크 = t.match(/https?:\/\/\S+/g) || []; if (!링크.length) { 답("이렇게 보내 주세요: 경쟁사 등록 https://주소1 https://주소2"); return; }
    링크.forEach(u => 기록("경쟁사", [u, "", 지금()])); 답("📌 경쟁사 " + 링크.length + "곳을 등록했습니다. 매주 수요일 아침에 제가 먼저 살펴보고 바뀐 점을 보고드리겠습니다."); return;
  }
  if (!결재번호 && 답장인가 && /^(🗓|🗂)/.test(m.reply_to_message.text || "")) {                  // 직원이 올린 소재 목록·결재 글에 단 답장 = 무조건 결재 답으로 (번호/승인/보류)
    const 대기 = 결재대기목록().filter(r => r[2] === 부서 || 부서 === "보고팀");
    if (대기.length) { 결재답장(Number(대기[대기.length - 1][0]), t, m); return; }
  }
  const 업무말 = /카드뉴스|문구|올렸|게시 완료|업로드|https?:\/\/|매출|지출/.test(t);
  if (답장인가 && !업무말) {                                  // Day 8·11·15: 직원 말풍선에 단 답장 = 결재·선택 기록
    기록("결재", [지금(), (m.reply_to_message.text || "").split("\n")[0].slice(0, 40), t, 부서]);
    답("📝 결재 기록했습니다: " + t); return;
  }
  const 정보 = 회사정보(); const 설정 = 설정읽기();
  const 말투 = "말투: " + (설정["말투"] || 정보["AI 직원에게 바라는 말투"] || "짧고 공손하게, 존댓말") + ". 호칭: " + (설정["호칭"] || 정보["사장님을 부르는 호칭"] || "사장님") + ".";

  if (부서 === "보고팀") {                                   // 보고팀은 답장(결재)만 받고, 그 외 글은 무시
    return;
  } else if (부서 === "고객응대팀") {                        // Day 9
    const r = 두뇌("손님 문의에 대한 답변 초안을 3개 써라(①짧게 ②친절하게 ③단골 만들기). 각 3줄 이내. 가게 정보에 없는 것은 지어내지 말고 '확인 후 안내'라고 써라. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[손님 문의]\n" + t) || "(Gemini 키가 없어 초안을 못 씁니다. Day 5를 확인하세요)";
    기록("문의", [지금(), t, r]); 답(r);
  } else if (부서 === "콘텐츠팀") {                          // Day 11~13
    if (/올렸|게시 완료|업로드/.test(t)) { 기록("게시", [지금(), t]); 답("📌 게시 완료로 기록했습니다. 수고하셨습니다!"); return; }
    if (/카드뉴스|문구/.test(t)) {
      const r = 두뇌("아래 소재로 인스타 카드뉴스 문구를 써라: 표지 제목(10자 내) 1개, 본문 슬라이드 4장(각 2줄), 마지막 슬라이드 행동 유도 1줄. 해시태그 5개. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[소재]\n" + t) || "(Gemini 키 필요)";
      기록("소재", [지금(), "카드뉴스", t, r]); 답(r); return;
    }
    const r = 두뇌("이 가게의 이번 주 SNS 소재 10개를 한 줄에 하나씩 써라. 각 줄: 번호. 제목(15자 내) — 왜 손님이 반응할지 한 마디. 손님이 자주 묻는 질문·요즘 고민·계절을 섞어라. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[사장님 요청]\n" + t) || "(Gemini 키 필요)";
    기록("소재", [지금(), "소재10", t, r]); 답(r);
  } else if (부서 === "인사팀") {                            // Day 14
    const r = 두뇌("사장님이 남긴 메모를 한 줄로 정리하고(핵심만), 분류를 하나 붙여라: 아이디어/불만/칭찬/할일/기타. 형식: '분류 | 한 줄'. " + 말투 + "\n[메모]\n" + t) || "기타 | " + t;
    기록("메모", [지금(), t, r]); 답("🗂 기록했습니다 → " + r);
  } else if (부서 === "시장조사팀") {                        // Day 17
    const 링크 = t.match(/https?:\/\/\S+/g) || [];
    if (!링크.length) { 답("경쟁 가게의 블로그·홈페이지·플레이스 주소를 붙여 주세요 (1~3개). 인스타그램은 로그인 벽 때문에 못 읽습니다."); return; }
    const 본문 = 링크.slice(0, 3).map(u => { try { return u + "\n" + 본문추출(UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true }).getContentText()).slice(0, 3000); } catch (e) { return u + "\n(못 읽음: " + e.message + ")"; } }).join("\n\n");
    const r = 두뇌("아래는 경쟁 가게 페이지 내용이다. 가게별로 제목 한 줄 뒤에 항목을 한 줄씩 정리하라: ①요즘 미는 상품/이벤트 ②가격 신호 ③우리가 바로 따라 할 것 1개 ④우리가 다르게 갈 것 1개. 페이지에 없는 건 '없음'. " + 말투 + "\n[우리 가게]\n" + 정보문장(정보) + "\n[경쟁 페이지]\n" + 본문) || "(Gemini 키 필요)";
    기록("조사", [지금(), 링크.join(" "), r]); 답(r);
  } else if (부서 === "광고팀") {                            // Day 18
    const r = 두뇌("사장님이 붙여넣은 광고 숫자(어제/오늘)를 해석하라. 형식: '한 줄 해석' 1줄, '좋은 신호' 1줄, '걱정 신호' 1줄, '오늘 할 것 1개' 1줄. 숫자에 없는 건 추측하지 마라. 용어는 쉬운 말로. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[광고 숫자]\n" + t) || "(Gemini 키 필요)";
    기록("광고", [지금(), t, r]); 답(r);
  } else if (부서 === "정산팀") {                            // Day 19 (AI 없이 동작)
    const 매출 = 숫자(t, /매출[:\s]*([\d,.]+)\s*(만)?/); const 지출 = 숫자(t, /지출[:\s]*([\d,.]+)\s*(만)?/);
    if (매출 === null && 지출 === null) { 답("이렇게 보내 주세요: 매출 32만 지출 8만 (메모는 뒤에 자유롭게)"); return; }
    기록("정산", [지금(), 매출 || 0, 지출 || 0, (매출 || 0) - (지출 || 0), t]);
    const 달 = 이번달합계();
    답("💰 기록했습니다. 오늘 매출 " + 원(매출) + " · 지출 " + 원(지출) + " · 남는 돈 " + 원((매출 || 0) - (지출 || 0)) + "\n이번 달 누적: 매출 " + 원(달.매출) + " · 지출 " + 원(달.지출) + " · 남는 돈 " + 원(달.매출 - 달.지출));
  }
}

// ---------- 금요일: 주간 요약 (Day 15) ----------
function 주간요약() {
  const 방 = 방찾기("보고팀"); if (!방) return;
  const 모음 = ["결재", "문의", "게시", "메모", "정산"].map(탭 => "[" + 탭 + " 최근]\n" + 최근행(탭, 15).map(r => r.slice(0, 4).join(" | ")).join("\n")).join("\n\n");
  const 글 = 두뇌("이번 주 우리 회사 기록을 보고 사장님께 주간 요약을 써라: ①이번 주 숫자(결재 몇 건, 문의 몇 건, 게시 몇 건, 매출·지출 합계) ②잘한 것 2개 ③다음 주 제안 2개. 8줄 이내. " + "\n" + 모음) || ("📊 주간 기록\n" + 모음.slice(0, 1500));
  보내기(방.chat, 방.thread, "📊 주간 요약\n" + 글); 기록("보고기록", [지금(), "주간요약", 글]);
}

// ---------- 비서실장 결재함 (v2) ----------
function 결재요청(부서, 제목, 본문, 종류, 참고) {
  const 방 = 방찾기("보고팀"); if (!방) { Logger.log("보고팀 방을 몰라 결재를 못 올렸습니다: " + 제목); return null; }
  let s = 시트().getSheetByName("결재함"); if (!s) { 탭준비(); s = 시트().getSheetByName("결재함"); }
  const id = s.getLastRow(); // 헤더가 1행이므로 첫 결재는 #1
  const 안내 = 종류 === "번호선택" ? "→ 이 글에 답장으로 마음에 드는 번호를 적어 주세요 (예: 3, 7). 보류면 '보류'" : "→ 이 글에 답장으로 '승인' 또는 '보류'";
  const 글 = "🗂 결재 #" + id + " [" + 부서 + "] " + 제목 + "\n" + 본문 + "\n" + 안내;
  보내기(방.chat, 방.thread, 글);
  s.appendRow([id, 지금(), 부서, 제목, 종류, "대기", "", "", String(참고 || "")]);
  return id;
}
function 결재대기목록() { return 최근행("결재함", 30).filter(r => r[5] === "대기"); }
function 결재답장(id, 답, m) {
  const s = 시트().getSheetByName("결재함"); if (!s) return true;
  const rows = s.getRange(2, 1, Math.max(1, s.getLastRow() - 1), 9).getValues();
  const i = rows.findIndex(r => Number(r[0]) === id); if (i < 0) { 보내기(m.chat.id, m.message_thread_id, "그 결재 번호를 못 찾았습니다."); return true; }
  const r = rows[i]; const 보류 = /보류|나중|아니/.test(답); let 번호들 = Array.from(new Set((답.match(/\d+/g) || []).map(Number)));
  const 이미끝남 = r[5] === "승인"; let 추가 = false;
  if (이미끝남 && !보류 && !번호들.length) return false;                              // 끝난 결재에 번호도 보류도 없는 말("올렸어요" 등) = 결재 답이 아님 → 일반 처리
  if (이미끝남 && r[4] === "번호선택" && 번호들.length) {                            // 이미 승인된 소재 결재에 번호를 더 적음 = 추가 요청 (만든 번호는 건너뜀)
    const 이미 = Array.from(new Set((String(r[6]).match(/\d+/g) || []).map(Number))); const 새것 = 번호들.filter(n => 이미.indexOf(n) < 0);
    if (!새것.length) { 보내기(m.chat.id, m.message_thread_id, "이미 만들어 드린 번호(" + 이미.join(", ") + ")입니다. 다른 번호를 적어 주세요."); return true; }
    번호들 = 새것; 추가 = true;
  }
  const 상태 = 보류 ? "보류" : "승인";
  s.getRange(i + 2, 6, 1, 2).setValues([[상태, 추가 ? String(r[6]) + " + " + 번호들.join(",") : 답]]);
  기록("결재", [지금(), "결재 #" + id + " " + r[3], 답, r[2]]);
  let 후속 = 보류 ? "보류로 기록했습니다." : "승인 처리했습니다.";
  if (!보류 && r[4] === "번호선택" && 번호들.length) 후속 = (추가 ? "추가 " : "") + 소재후속(r, 번호들);
  else if (!보류 && r[4] === "조사") { 기록("메모", [지금(), "결재 #" + id + " 승인", "할일 | " + String(r[8]).slice(0, 80)]); 후속 = "승인 처리했습니다. '따라 할 것'을 인사팀 할일로 넣어 두었습니다."; }
  s.getRange(i + 2, 8, 1, 1).setValues([[후속.split("\n")[0].slice(0, 60)]]);
  보내기(m.chat.id, m.message_thread_id, "✅ 결재 #" + id + " " + 후속); return true;
}
function 소재후속(r, 번호들) {                                   // 승인된 소재 번호 → 카드뉴스 문구를 바로 만들어 콘텐츠팀에 올림
  const 목록 = String(r[8]).split("\n"); const 고른것 = 번호들.map(n => 목록.find(l => l.indexOf(n + ".") === 0)).filter(Boolean);
  if (!고른것.length) return "승인 처리했습니다(번호를 못 찾아 문구는 안 만들었습니다).";
  const 정보 = 회사정보(); const 방 = 방찾기("콘텐츠팀");
  고른것.forEach(소재 => {
    const 문구 = 두뇌("아래 소재로 인스타 카드뉴스 문구를 써라: 표지 제목(10자 내) 1개, 본문 슬라이드 4장(각 2줄), 마지막 슬라이드 행동 유도 1줄. 해시태그 5개.\n[가게 정보]\n" + 정보문장(정보) + "\n[소재]\n" + 소재) || "(Gemini 키 필요)";
    기록("소재", [지금(), "카드뉴스(결재)", 소재, 문구]); if (방) 보내기(방.chat, 방.thread, "🗂 결재 #" + r[0] + " 승인 → 카드뉴스 문구\n[" + 소재 + "]\n" + 문구);
  });
  return "승인 " + 고른것.length + "개 → 카드뉴스 문구를 콘텐츠팀에 올렸습니다. 올리신 뒤 '올렸어요'라고만 해 주세요.";
}

// ---------- 부서가 먼저 움직이는 일들 (v2) ----------
function 월요소재() {                                            // 월요일 07시: 콘텐츠팀이 소재 10개를 먼저 제안 → 결재
  const 정보 = 회사정보();
  const r = 두뇌("이 가게의 이번 주 SNS 소재 10개를 한 줄에 하나씩 써라. 각 줄: 번호. 제목(15자 내) — 왜 손님이 반응할지 한 마디. 손님이 자주 묻는 질문·요즘 고민·계절을 섞어라.\n[가게 정보]\n" + 정보문장(정보));
  if (!r) { Logger.log("Gemini 키가 없어 월요 소재를 건너뜁니다."); return; }
  기록("소재", [지금(), "소재10(자동)", "월요 자동", r]);
  const 방 = 방찾기("콘텐츠팀"); if (방) 보내기(방.chat, 방.thread, "🗓 이번 주 소재 10개 (제가 먼저 준비했습니다)\n" + r + "\n→ 이 글에 답장으로 만들 번호를 적어 주세요 (예: 3, 7)");
  결재요청("콘텐츠팀", "이번 주 소재 10개 중 만들 것 고르기", r, "번호선택", r);
}
function 경쟁사정찰() {                                          // 수요일 07시: 등록된 경쟁사 페이지를 다시 보고 바뀐 점만 보고 → 결재
  const s = 시트().getSheetByName("경쟁사"); if (!s || s.getLastRow() < 2) return;
  const rows = s.getRange(2, 1, s.getLastRow() - 1, 3).getValues(); const 정보 = 회사정보(); const 결과 = [];
  rows.forEach((row, i) => {
    const u = String(row[0]); if (!/^https?:/.test(u)) return;
    let 본문 = ""; try { 본문 = 본문추출(UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true }).getContentText()).slice(0, 3000); } catch (e) { 본문 = "(못 읽음: " + e.message + ")"; }
    const r = 두뇌("경쟁 가게 페이지를 지난주 요약과 비교해 정리하라. 형식: 첫 줄 '가게: 주소 끝부분', 그 다음 ①이번 주 새로 보이는 것(없으면 '변화 없음') ②가격 신호 ③우리가 바로 따라 할 것 1개 ④다르게 갈 것 1개. 페이지에 없는 건 '없음'.\n[우리 가게]\n" + 정보문장(정보) + "\n[지난주 요약]\n" + (row[1] || "(처음)") + "\n[이번 주 페이지]\n" + u + "\n" + 본문);
    if (!r) return;
    s.getRange(i + 2, 2, 1, 2).setValues([[r.slice(0, 1500), 지금()]]); 기록("조사", [지금(), u, r]); 결과.push(r);
  });
  if (!결과.length) return;
  const 방 = 방찾기("시장조사팀"); if (방) 보내기(방.chat, 방.thread, "🔎 수요일 경쟁사 정찰\n\n" + 결과.join("\n\n"));
  const 따라할것 = 결과.map(r => { const ls = r.split("\n"); const k = ls.findIndex(l => l.indexOf("③") === 0); if (k < 0) return ""; let t = ls[k].trim(); if (!t.replace(/^③\s*우리가\s*바로\s*따라\s*할\s*것\s*1개\s*[:：]?/, "").trim() && ls[k + 1]) t += " " + ls[k + 1].trim(); return t; }).filter(Boolean).join(" / ");   // "③ 따라 할 것 1개" 줄 다음 줄에 내용이 오는 경우까지
  결재요청("시장조사팀", "경쟁사 정찰 — 따라 할 것 승인", 따라할것 || 결과[0].split("\n").slice(0, 4).join("\n"), "조사", 따라할것);
}
function 저녁정리() {                                            // 매일 18시: 비서실장이 미결재·할일을 한 번 더 챙김
  const 방 = 방찾기("보고팀"); if (!방) return;
  const 대기 = 결재대기목록(); const 할일 = 최근행("메모", 30).filter(r => /^할일/.test(String(r[2]))).slice(-5);
  if (!대기.length && !할일.length) return;
  let 글 = "🌙 저녁 정리";
  if (대기.length) 글 += "\n아직 결재 안 된 것 " + 대기.length + "건: " + 대기.map(r => "#" + r[0] + " " + r[3]).join(", ") + "\n→ 위로 올라가 그 결재 글에 답장해 주세요.";
  if (할일.length) 글 += "\n인사팀에 남은 할일: " + 할일.map(r => String(r[2]).replace(/^할일\s*\|\s*/, "")).join(" / ");
  보내기(방.chat, 방.thread, 글);
}
function 월정산() {                                              // 매월 1일: 지난달 정산 요약
  const 방 = 방찾기("정산팀") || 방찾기("보고팀"); if (!방) return;
  const d = new Date(); d.setDate(0); const 달 = Utilities.formatDate(d, "Asia/Seoul", "yyyy-MM");
  let 매출 = 0, 지출 = 0, 건 = 0; 최근행("정산", 400).forEach(r => { if (String(r[0]).indexOf(달) === 0) { 매출 += Number(r[1]) || 0; 지출 += Number(r[2]) || 0; 건++; } });
  보내기(방.chat, 방.thread, "📅 " + 달 + " 월 정산\n기록 " + 건 + "일 · 매출 " + 원(매출) + " · 지출 " + 원(지출) + " · 남는 돈 " + 원(매출 - 지출));
}

// ---------- 도구들 ----------
function 두뇌(질문) {
  if (!GEMINI_KEY || GEMINI_KEY.indexOf("여기에") === 0) return null;
  const 규칙 = "텔레그램 메시지로 보낼 순수 텍스트로만 답해라. 표 기호(|, ---), 굵게(**), 제목(#), <br> 같은 마크다운은 절대 쓰지 말고, 번호와 줄바꿈만 써라.\n\n";
  const res = UrlFetchApp.fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=" + GEMINI_KEY,
    { method: "post", contentType: "application/json", payload: JSON.stringify({ contents: [{ parts: [{ text: 규칙 + 질문 }] }] }), muteHttpExceptions: true });
  const json = JSON.parse(res.getContentText());
  if (!json.candidates) throw new Error("Gemini 키 문제: " + ((json.error && json.error.message) || "").slice(0, 100));
  return 정리(json.candidates[0].content.parts.map(p => p.text).join(""));
}
function 정리(글) {                                          // 혹시 남은 마크다운 기호를 지웁니다 (텔레그램은 표를 못 그립니다)
  return String(글).replace(/<br\s*\/?>/gi, "\n").replace(/\*\*/g, "").replace(/^#+\s*/gm, "").split("\n")
    .filter(l => !/^\s*\|?\s*(:?-{2,}:?\s*\|\s*)+:?-*:?\s*\|?\s*$/.test(l)).map(l => l.replace(/^\s*\|\s*/, "").replace(/\s*\|\s*$/, "").replace(/\s*\|\s*/g, " · ")).join("\n").trim();
}
function 보내기(chat, thread, 글) {
  const body = { chat_id: chat, text: String(글).slice(0, 4000) }; if (thread) body.message_thread_id = thread;
  const r = JSON.parse(UrlFetchApp.fetch(API + "/sendMessage", { method: "post", contentType: "application/json", payload: JSON.stringify(body), muteHttpExceptions: true }).getContentText());
  return r.ok ? r.result : null;
}
const 부서목록 = ["보고팀", "고객응대팀", "콘텐츠팀", "인사팀", "시장조사팀", "광고팀", "정산팀"];
function 부서정리(이름) { const n = String(이름 || "").replace(/\s/g, ""); return 부서목록.find(b => n.indexOf(b) >= 0) || n; }
function 부서이름(m) {
  const r = m.reply_to_message; if (r && r.forum_topic_created) return 부서정리(r.forum_topic_created.name);
  if (m.forum_topic_created) return 부서정리(m.forum_topic_created.name);
  return m.message_thread_id ? (저장소.getProperty("이름:" + m.message_thread_id) || "General") : "General";
}
function 방저장(부서, chat, thread) { 저장소.setProperty("방:" + 부서, JSON.stringify({ chat: chat, thread: thread })); if (thread) 저장소.setProperty("이름:" + thread, 부서); }
function 방찾기(부서) { const s = 저장소.getProperty("방:" + 부서); return s ? JSON.parse(s) : null; }
function 시트() { return SpreadsheetApp.openByUrl(SHEET_URL); }
function 회사정보() { const o = {}; 시트().getSheets()[0].getRange("A2:B12").getValues().forEach(r => { if (r[0]) o[String(r[0]).trim()] = String(r[1] || "").trim(); }); return o; }
function 정보문장(정보) { return Object.keys(정보).map(k => k + ": " + (정보[k] || "(비어 있음)")).join("\n"); }
function 설정읽기() { const o = {}; const s = 시트().getSheetByName("설정"); if (s) s.getRange("A2:B10").getValues().forEach(r => { if (r[0]) o[String(r[0]).trim()] = String(r[1] || "").trim(); }); return o; }
function 탭준비() {
  const ss = 시트();
  const 틀 = { "설정": ["항목", "값"], "보고기록": ["시각", "종류", "내용", "메시지번호"], "결재": ["시각", "원문 첫 줄", "사장님 답장", "부서"], "문의": ["시각", "손님 문의", "답변 초안"], "소재": ["시각", "종류", "요청", "결과"], "게시": ["시각", "내용"], "메모": ["시각", "원문", "정리"], "조사": ["시각", "링크", "결과"], "광고": ["시각", "숫자", "해석"], "정산": ["시각", "매출", "지출", "남는 돈", "원문"], "결재함": ["번호", "시각", "부서", "제목", "종류", "상태", "답장", "후속", "참고"], "경쟁사": ["주소", "지난 요약", "마지막 확인"] };
  Object.keys(틀).forEach(이름 => { let s = ss.getSheetByName(이름); if (!s) { s = ss.insertSheet(이름); s.appendRow(틀[이름]); s.getRange(1, 1, 1, 틀[이름].length).setFontWeight("bold"); } });
  const 설 = ss.getSheetByName("설정"); if (설.getLastRow() < 2) { 설.getRange("A2:B4").setValues([["보고 시각", "8"], ["말투", "짧고 공손하게, 존댓말"], ["호칭", "사장님"]]); }
}
function 기록(탭, 행) { let s = 시트().getSheetByName(탭); if (!s) { 탭준비(); s = 시트().getSheetByName(탭); } s.appendRow(행); }
function 최근행(탭, n) { const s = 시트().getSheetByName(탭); if (!s || s.getLastRow() < 2) return []; const from = Math.max(2, s.getLastRow() - n + 1); return s.getRange(from, 1, s.getLastRow() - from + 1, s.getLastColumn()).getValues(); }
function 지금() { return Utilities.formatDate(new Date(), "Asia/Seoul", "yyyy-MM-dd HH:mm"); }
function 숫자(t, re) { const m = t.match(re); if (!m) return null; let v = Number(m[1].replace(/,/g, "")); if (m[2]) v *= 10000; return v; }
function 원(v) { return (Number(v) || 0).toLocaleString("ko-KR") + "원"; }
function 이번달합계() { const 달 = Utilities.formatDate(new Date(), "Asia/Seoul", "yyyy-MM"); let 매출 = 0, 지출 = 0; 최근행("정산", 200).forEach(r => { if (String(r[0]).indexOf(달) === 0) { 매출 += Number(r[1]) || 0; 지출 += Number(r[2]) || 0; } }); return { 매출, 지출 }; }
function 본문추출(html) { return String(html).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim(); }
```

2·3·4번 줄 따옴표 안을 **토큰 / Gemini 키 / 시트 주소**로 바꿉니다(Day 5에서 이미 넣어 두었다면 그 값을 다시 넣습니다). Gemini 키를 아직 못 받았으면 3번 줄을 `""`(따옴표 두 개)로 두어도 오늘 미션은 됩니다. **Ctrl + S** 저장.

![함수 칸 ①을 누르면 이름 목록이 펼쳐집니다 — 맨 위가 설치 ②](/public/guide/d06p-03.jpg)

> 이렇게 보이면 성공: 도구 줄의 함수 칸을 누르면 이름이 여러 개 보이고, 그중에 **설치 · 아침보고 · 직원업무 · 주간요약 · 월요소재 · 경쟁사정찰 · 저녁정리 · 월정산**이 있습니다. (두뇌·보내기·기록 같은 다른 이름도 같이 보이는데, 그건 직원이 안에서 쓰는 부품이라 사장님이 고를 일이 없습니다.)

### 2단계 · 첫 아침 보고 실행 (5분)
먼저 텔레그램 **보고팀**에 `/start@내직원아이디`를 **한 번 더** 보냅니다(Day 4와 같은 한 줄 — 텔레그램은 하루가 지난 메시지를 직원에게 넘겨주지 않아서, 직원이 방을 다시 찾게 해 주는 것입니다). 30초 뒤, 함수 칸에서 **아침보고**를 고르고 **▶ 실행**. 이 프로그램은 "자동 실행"과 "시트 쓰기" 권한이 더 필요해서 **허락 창이 한 번 더** 뜹니다 — Day 4와 똑같이 **고급 → 이동 → 모두 선택 체크 → 계속** (항목이 3개로 늘어난 것만 다릅니다).

![보고팀에 도착한 첫 아침 보고 — Gemini 키가 있으면 할 일마다 한 줄 팁이 붙습니다](/public/guide/d06p-02.jpg)

![Gemini 키를 비워 두면 이렇게 팁 없이 옵니다 — 이것도 정상](/public/guide/d06p-01.jpg)

![Day 3 시트 아래에 탭이 저절로 생깁니다 — 설정·보고기록·결재·문의·소재·게시·메모·조사·광고·정산·결재함·경쟁사 (직원의 장부)](/public/guide/d06p-04.jpg)

> 이렇게 보이면 성공: 텔레그램 **보고팀**에 `☀️ 9월 12일 (토) 아침 보고 / 사장님, 좋은 아침입니다 / 1. … 2. … 3. … / 답장으로 결재해 주세요`가 옵니다. 할 일 3개는 **Day 3 시트의 "매일 반복하는 일 3개"**에서 가져온 것입니다. Gemini 키가 있으면 문장이 매일 조금씩 달라지고 팁이 붙습니다. **이 화면이 오늘 제출할 캡처입니다.**

실행 로그에 `② 보고팀 방을 아직 몰라요`가 나오면: 보고팀에 `/start@내직원아이디`를 보낸 지 30초가 안 지난 것입니다. 잠깐 기다렸다가 **아침보고**를 다시 실행.

### 3단계 · 시트에 생긴 탭 확인 (2분)
Day 3 시트를 엽니다. 아래쪽에 탭이 여러 개 생겼습니다: **설정 · 보고기록 · 결재 · 문의 · 소재 · 게시 · 메모 · 조사 · 광고 · 정산 · 결재함 · 경쟁사**. "결재함"은 비서실장이 올린 결재와 사장님 답이 쌓이는 곳(Day 8), "경쟁사"는 매주 살펴볼 경쟁 가게 주소를 두는 곳(Day 17)입니다. 앞으로 직원이 한 모든 일이 여기에 자동으로 쌓입니다. "보고기록" 탭에 방금 보고가 한 줄 들어 있으면 정상입니다.

> **설정** 탭의 값(보고 시각 8 / 말투 / 호칭)은 Day 16에 바꿔 봅니다. 지금은 그대로 둡니다.

## 미션 체크리스트
- [ ] 코드를 통째로 바꾸고 값 3줄을 넣었다 (Gemini 키는 없으면 빈칸)
- [ ] `아침보고` 실행 → 보고팀에 아침 보고가 도착했다
- [ ] 시트에 기록 탭들이 생겼다

## 제출할 캡처는 이 화면
**보고팀에 도착한 아침 보고** 1장.

## 안 보이면 / 안 되면
| 이런 상황 | 이렇게 |
|---|---|
| 함수 칸에 이름이 안 보여요 | Ctrl + S로 저장이 안 된 것. 저장 후 새로고침(F5). |
| 로그: `② 보고팀 방을 아직 몰라요` | 보고팀에 `/start@내직원아이디` 보내기 → `직원업무` 실행 → `아침보고` 실행. |
| 로그: `Gemini 키 문제` | 3번 줄 키를 다시 붙이거나, 오늘은 `""`로 비우고 진행(기본 형식 보고가 옵니다). |
| 로그: `openByUrl` / `권한` | 4번 줄 시트 주소 확인 + Day 3과 같은 구글 계정인지 확인. |
| 보고가 두 번 왔어요 | 실행 버튼을 두 번 누른 것. 문제없습니다. |
| 보고 내용이 이상해요 | Day 3 시트 "매일 반복하는 일 3개" 칸을 쉼표(,)로 구분해 3개 적었는지 확인. |

## 용어 한 줄
- **사무실 프로그램**: 오늘 붙여넣은 코드. 부서방 이름을 보고 어느 직원이 일할지 스스로 정합니다.
- **함수**: 코드 안의 업무 하나(설치·아침보고·직원업무·주간요약·월요소재·경쟁사정찰·저녁정리·월정산). 도구 줄에서 골라 실행합니다.
- **비서실장(보고팀 김대리)**: 부서들이 한 일을 모아 사장님께 결재를 올리는 직원. 사장님은 그 글에 답장만 합니다.
- **기록 탭**: 시트 아래쪽 이름표. 직원이 한 일이 탭별로 쌓입니다.
