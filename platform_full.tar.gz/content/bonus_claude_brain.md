# 보너스 — 직원의 두뇌를 Claude로 바꾸기 (선택 · 유료)

> **이건 안 해도 20일 완주에 지장 없습니다.** Gemini 무료 등급으로 끝까지 됩니다.
> 바꾸면 좋은 경우: 문의 답변·SNS 문구의 한국어 "글맛"이 아쉬울 때. 한국어 응대 문장은 Claude 쪽 평이 좋습니다(개인 차 있음).
> **주의**: 우리 프로그램이 쓰는 건 채팅 앱 구독(Claude Pro)이 아니라 **Claude 개발자 키(API)**입니다. 쓴 만큼 과금(선불 충전)이고, 1인 가게 하루 업무량이면 월 몇천 원~1만 원대로 예상됩니다 — **정확한 단가·최소 충전액은 개강 전 공식 페이지에서 확인해 안내합니다.**

## 걸리는 시간: 15분

## 1단계 · 키 받기 (5분)
1. 크롬에서 `console.anthropic.com` → 구글 계정으로 가입/로그인.
2. 결제 정보 등록 후 **선불 충전**(최소 금액은 화면에 표시 — 확인 필요).
3. 왼쪽 메뉴 **API Keys → Create Key** → 이름 아무거나(예: office) → 나오는 `sk-ant-…` 긴 문자열을 **복사**해 Day 2 메모에 붙입니다.

```text
Claude 키: [여기에 붙여넣기]
```

이 키도 토큰처럼 **비밀번호**입니다. 캡처·단톡방에 올리지 않습니다.
(이 단계 캡처는 준비 중입니다 — 화면 버튼 이름은 영어 그대로 찾으면 됩니다.)

## 2단계 · 프로그램의 "두뇌" 부품 바꾸기 (5분)
Apps Script(Day 6 사무실 프로그램)를 열고, 코드 칸에서 **Ctrl + F**로 `function 두뇌` 를 찾습니다. `function 두뇌(질문) {` 부터 그다음 `}` 까지(8줄)를 지우고 아래를 붙여넣습니다. 다른 줄은 건드리지 않습니다.

```javascript
const CLAUDE_KEY = "여기에_Claude키_붙여넣기";   // 보너스: Claude 개발자 키 (sk-ant-…)

function 두뇌(질문) {
  if (CLAUDE_KEY && CLAUDE_KEY.indexOf("sk-ant") === 0) {
    const res = UrlFetchApp.fetch("https://api.anthropic.com/v1/messages", {
      method: "post", contentType: "application/json",
      headers: { "x-api-key": CLAUDE_KEY, "anthropic-version": "2023-06-01" },
      payload: JSON.stringify({ model: "claude-sonnet-5", max_tokens: 1500, messages: [{ role: "user", content: 질문 }] }),
      muteHttpExceptions: true
    });
    const json = JSON.parse(res.getContentText());
    if (!json.content) throw new Error("Claude 키 문제: " + ((json.error && json.error.message) || "").slice(0, 100));
    return json.content.map(p => p.text || "").join("").trim();
  }
  if (!GEMINI_KEY || GEMINI_KEY.indexOf("여기에") === 0) return null;
  const res = UrlFetchApp.fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + GEMINI_KEY,
    { method: "post", contentType: "application/json", payload: JSON.stringify({ contents: [{ parts: [{ text: 질문 }] }] }), muteHttpExceptions: true });
  const json = JSON.parse(res.getContentText());
  if (!json.candidates) throw new Error("Gemini 키 문제: " + ((json.error && json.error.message) || "").slice(0, 100));
  return json.candidates[0].content.parts.map(p => p.text).join("").trim();
}
```

첫 줄 따옴표 안에 Claude 키를 넣고 **Ctrl + S**. 이제 Claude 키가 있으면 Claude를, 없으면 Gemini를 씁니다. 되돌리고 싶으면 첫 줄을 `""`로 비우면 됩니다.

## 3단계 · 확인 (2분)
함수 칸 **아침보고** → **▶ 실행**. 보고 문장이 달라져 있으면 성공. 오류 `Claude 키 문제: …`가 뜨면 키 앞뒤 공백·충전 잔액을 확인합니다.

## 비용을 아끼는 두 가지
- 정산팀·게시 기록·결재 기록은 원래 두뇌를 안 씁니다(무료). 두뇌를 쓰는 건 답변·소재·해석·요약뿐입니다.
- 모델 이름을 더 저렴한 것으로 바꿀 수 있습니다(개강 전 공식 모델 목록·단가를 확인해 표로 드립니다). 지금 넣어 둔 `claude-sonnet-5`는 "글맛과 가격의 중간"입니다.

## 안 되면
| 이런 상황 | 이렇게 |
|---|---|
| `Claude 키 문제: authentication` | 키를 다시 복사(sk-ant로 시작, 공백 없이). |
| `Claude 키 문제: credit` / `billing` | 충전 잔액 0. console.anthropic.com에서 충전. |
| `Claude 키 문제: model` | 모델 이름이 바뀐 것. 문의해 주시면 최신 이름을 알려드립니다. |
| 둘 다 쓰기 싫어요 | 첫 줄을 `""`로, Day 6의 3번 줄(GEMINI_KEY)도 `""`로 두면 기본 형식 보고만 옵니다(문의 답변 등 두뇌 업무는 멈춤). |
