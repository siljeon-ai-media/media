# 보너스 — 직원의 두뇌를 Claude로 바꾸기 (선택 · 유료)

> **이건 안 해도 20일 완주에 지장 없습니다.** Gemini 무료 등급으로 끝까지 됩니다.
> 바꾸면 좋은 경우: 문의 답변·SNS 문구의 한국어 "글맛"이 아쉬울 때. 한국어 응대 문장은 Claude 쪽 평이 좋습니다(개인 차 있음).
> **주의**: 우리 프로그램이 쓰는 건 채팅 앱 구독(Claude Pro)이 아니라 **Claude 개발자 키(API)**입니다. 쓴 만큼 과금(선불 충전)입니다. 공식 요금표(2026년 9월, platform.claude.com/docs/en/about-claude/pricing) 기준 Sonnet 5는 입력 100만 토큰당 $2·출력 $10 — 우리 직원의 한 번 업무(입력 약 1,500토큰 + 출력 약 500토큰)는 약 $0.008이라 **하루 20회면 월 약 $5(7천 원 안팎)**입니다. 문의가 많은 가게(하루 50회)라도 월 $12 정도입니다.

## 걸리는 시간: 15분

## 1단계 · 키 받기 (5분)
1. 크롬에서 `platform.claude.com` 에 들어가 구글 계정으로 가입/로그인합니다. (채팅 앱 claude.ai 와는 다른 "개발자 콘솔"입니다.)
2. 왼쪽 메뉴 **결제** → 카드 등록 후 **크레딧 충전**(선불). 최소 금액은 충전 화면에 표시됩니다 — 한 달치 $5~10 정도면 충분합니다.
3. 왼쪽 메뉴 **API 키** → 오른쪽 위 **+ 키 생성** ①.

![Claude Console 왼쪽 메뉴 "API 키" 화면 — 오른쪽 위 "+ 키 생성" (마스터 화면, 목록은 비어 있는 상태)](/public/guide/bonus-01.jpg)

4. "ID 페더레이션…" 안내 창이 먼저 뜨면 아래쪽 **API 키로 계속하기**를 누릅니다(위 검은 버튼은 개발자용이라 안 씁니다).
5. **API 키 생성** 창에서: 이름 ② `office` → 만료 ③ **안 함**(기본값 30일 그대로 두면 한 달 뒤 직원이 멈춥니다) → 범위 ④ **기본 워크스페이스** → **키 생성**.

![키 생성 창 — 만료 "안 함", 범위 "기본 워크스페이스" 고르는 화면 (마스터 화면)](/public/guide/bonus-02.jpg)

6. `sk-ant-…` 로 시작하는 긴 문자열이 **딱 한 번** 보입니다. **복사**해 Day 2 메모에 붙입니다. (창을 닫으면 다시 못 봅니다 — 놓쳤으면 키를 하나 더 만들면 됩니다.)

```text
Claude 키: [여기에 붙여넣기]
```

이 키도 토큰처럼 **비밀번호**입니다. 캡처·단톡방에 올리지 않습니다.

## 2단계 · 프로그램의 "두뇌" 부품 바꾸기 (5분)
Apps Script(Day 4 사무실 프로그램)를 열고, 코드 칸을 한 번 누른 뒤 **Ctrl + F**로 `두뇌모델` 을 찾습니다. 아래 그림처럼 `const 두뇌모델 = [` 줄이 노랗게 표시됩니다.

![Apps Script에서 Ctrl+F로 "두뇌모델"을 찾은 화면 (마스터 화면)](/public/guide/bonus-03.jpg)

그 줄부터 `function 정리(` **바로 윗줄의 `}`까지**(모두 15줄)를 마우스로 긁어 지우고, 아래를 그대로 붙여넣습니다. 다른 줄은 건드리지 않습니다.

```javascript
const CLAUDE_KEY = "여기에_Claude키_붙여넣기";   // 보너스: Claude 개발자 키 (sk-ant-…). 비우면("") Gemini만 씁니다
const 두뇌모델 = ["gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]; // Gemini 무료 한도: 앞 모델 20회 → 넘기면 다음 모델(각 500회)로 자동 전환
function 두뇌(질문) {
  const 규칙 = "텔레그램 메시지로 보낼 순수 텍스트로만 답해라. 표 기호(|, ---), 굵게(**), 제목(#), <br> 같은 마크다운은 절대 쓰지 말고, 번호와 줄바꿈만 써라.\n\n";
  if (CLAUDE_KEY && CLAUDE_KEY.indexOf("sk-ant") === 0) {                       // Claude 키가 있으면 Claude를 두뇌로
    const res = UrlFetchApp.fetch("https://api.anthropic.com/v1/messages", {
      method: "post", contentType: "application/json",
      headers: { "x-api-key": CLAUDE_KEY, "anthropic-version": "2023-06-01" },
      payload: JSON.stringify({ model: "claude-sonnet-5", max_tokens: 1500, messages: [{ role: "user", content: 규칙 + 질문 }] }),
      muteHttpExceptions: true
    });
    const json = JSON.parse(res.getContentText());
    if (!json.content) throw new Error("Claude 키 문제: " + ((json.error && json.error.message) || "").slice(0, 100));
    return 정리(json.content.map(p => p.text || "").join(""));
  }
  if (!GEMINI_KEY || GEMINI_KEY.indexOf("여기에") === 0) return null;
  let 오류 = "";
  for (let i = 0; i < 두뇌모델.length; i++) {
    const res = UrlFetchApp.fetch("https://generativelanguage.googleapis.com/v1beta/models/" + 두뇌모델[i] + ":generateContent?key=" + GEMINI_KEY,
      { method: "post", contentType: "application/json", payload: JSON.stringify({ contents: [{ parts: [{ text: 규칙 + 질문 }] }] }), muteHttpExceptions: true });
    const json = JSON.parse(res.getContentText());
    if (json.candidates) return 정리(json.candidates[0].content.parts.map(p => p.text).join(""));
    오류 = (json.error && json.error.message) || "";
    if (res.getResponseCode() !== 429) break;
  }
  throw new Error("Gemini 키 문제: " + 오류.slice(0, 100));
}
```

첫 줄 따옴표 안에 1단계에서 복사한 Claude 키를 넣고 **Ctrl + S**(저장). 이제 Claude 키가 있으면 Claude를, 없으면 Gemini를 씁니다. 되돌리고 싶으면 첫 줄을 `""`로 비우면 됩니다.

![붙여넣고 저장한 뒤 — 첫 줄에 Claude 키, 그 아래 두뇌모델·두뇌 함수 (마스터 화면)](/public/guide/bonus-04.jpg)

## 3단계 · 확인 (2분)
함수 칸 **아침보고** → **▶ 실행**. 아래처럼 실행 로그에 `✅ 아침 보고를 보고팀에 올렸습니다`가 뜨고, 텔레그램 보고팀에 온 보고 문장이 달라져 있으면 성공. 오류 `Claude 키 문제: …`가 뜨면 키 앞뒤 공백·충전 잔액을 확인합니다.

![아침보고 실행 → 실행 로그에 ✅ (마스터 화면)](/public/guide/bonus-05.jpg)

## 비용을 아끼는 두 가지
- 정산팀·게시 기록·결재 기록은 원래 두뇌를 안 씁니다(무료). 두뇌를 쓰는 건 답변·소재·해석·요약뿐입니다.
- 코드 속 `claude-sonnet-5`를 `claude-haiku-4-5-20251001`로 바꾸면 비용이 절반 이하(입력 $1·출력 $5, 2026년 9월 공식 요금표)로 줄고, 글맛은 조금 덜합니다. 지금 넣어 둔 Sonnet 5가 "글맛과 가격의 중간"입니다.

## 안 되면
| 이런 상황 | 이렇게 |
|---|---|
| `Claude 키 문제: authentication` | 키를 다시 복사(sk-ant로 시작, 공백 없이). |
| `Claude 키 문제: credit` / `billing` | 충전 잔액 0. platform.claude.com 왼쪽 메뉴 "결제"에서 충전. |
| `Claude 키 문제: model` | 모델 이름이 바뀐 것. 문의해 주시면 최신 이름을 알려드립니다. |
| 둘 다 쓰기 싫어요 | 첫 줄을 `""`로, Day 4의 3번 줄(GEMINI_KEY)도 `""`로 두면 기본 형식 보고만 옵니다(문의 답변 등 두뇌 업무는 멈춤). |
