# 실전 AI 챌린지 플랫폼 — 운영 안내 (대표님용)

"AI 직원 1명 출근" 4주 과정의 **미션 승인제 학습 플랫폼**입니다.
수강생은 입장 코드로 가입 → 동의 → Day 1부터 미션을 보고 캡처를 제출 → 운영자가 승인하면 다음 Day가 열립니다.

---

## 1. 이 폴더에 뭐가 들어있나

| 파일/폴더 | 역할 |
|---|---|
| `server.js` | 서버 본체 (화면·로그인·제출·관리자 전부) |
| `db.js` | 데이터베이스(SQLite = 파일 하나짜리 DB) 접근 |
| `views/` | 화면 템플릿 (수강생 화면 + `admin/` 관리자 화면) |
| `public/` | 디자인(css)·복사 버튼 등 브라우저용 스크립트 |
| `content/day01.md ~ day20.md` | 미션 본문 (마크다운 = 텍스트 문서). Day 1·2·5는 완성본, 나머지는 제목만 |
| `lib/consent.js` | 동의 화면 문구 (환불 규정 표·복제 금지·개인정보) |
| `seed_codes.js` | 입장 코드 20개를 한 번에 만드는 도구 |
| `data/` | **자동 생성**. `app.db`(모든 기록) + `uploads/`(수강생 캡처). 이 폴더가 사라지면 기록이 다 사라지므로 백업 대상 |
| `.env.example` | 환경변수(비밀 설정값) 목록 예시 |

---

## 2. Replit에 올리는 순서 (스크린샷 없이 번호로)

> Replit = 코드를 올려두면 24시간 돌아가는 서버를 빌려주는 서비스. 대표님 계정으로 로그인한 상태에서 진행합니다.

### 2-1. GitHub 저장소 준비 (한 번만)
1. 이 `platform` 폴더의 내용을 GitHub 저장소(비공개, private)에 올립니다. (로디가 세션에서 도와드릴 수 있는 부분 — `data/`, `node_modules/`는 `.gitignore`로 자동 제외됩니다.)

### 2-2. Replit에 가져오기
1. Replit 홈 → 오른쪽 위 **+ Create Repl**(또는 **Create**) 클릭.
2. **Import from GitHub** 탭 선택 → 저장소 주소 붙여넣기 → **Import**.
   (처음이면 "GitHub 연결 허용" 창이 뜹니다. 허용 후 다시 시도.)
3. 언어를 물으면 **Node.js** 선택. 가져오기가 끝나면 왼쪽에 파일 목록이 보입니다.

### 2-3. Secrets(비밀값) 3개 넣기
1. 왼쪽 도구 목록에서 **Secrets**(자물쇠 아이콘)를 엽니다. (안 보이면 "Tools" → "Secrets")
2. **+ New Secret**을 눌러 아래 3개를 하나씩 추가합니다. (Key = 왼쪽 이름 그대로, Value = 값)

| Key | Value | 설명 |
|---|---|---|
| `SESSION_SECRET` | 아무 긴 문자열 (32자 이상, 예: 비밀번호 생성기로 만든 값) | 로그인 쿠키 암호화 키. 한 번 정하면 바꾸지 않기 (바꾸면 전원 로그아웃) |
| `ADMIN_PASSWORD` | 관리자 비밀번호 | `/admin` 로그인용. **꼭 설정** (없으면 기본값 `admin1234`라 위험) |
| `TELEGRAM_BOT_TOKEN` | 봇 토큰 (선택) | 제출 알림을 받을 봇. 없으면 알림만 꺼지고 나머지는 정상 |

   선택 사항: `TELEGRAM_ADMIN_CHAT_ID`(알림 받을 채팅 ID — 텔레그램 알림을 쓰려면 토큰과 함께 필수), `TELEGRAM_ADMIN_THREAD_ID`(포럼 그룹의 토픽 ID), `CONTACT_INFO`(화면 하단 문의처 문구), `COHORT`(기수 표시, 기본 `1기`).

### 2-4. 실행 확인
1. 위쪽 **Run** 버튼을 누릅니다. Replit이 자동으로 `npm install`(부품 설치) 후 `npm start`를 실행합니다.
   - 처음엔 1~2분 걸립니다. 콘솔에 `✅ siljeon.ai 챌린지 플랫폼 실행 중`이 뜨면 성공.
   - 만약 Run 설정을 물으면: Run command = `npm start`.
2. 오른쪽 **Webview** 창에 로그인 화면이 뜹니다. 주소 끝에 `/admin`을 붙여 관리자 비밀번호로 들어가지는지 확인.

### 2-5. Deploy(정식 배포) — **Reserved VM** 권장
1. 오른쪽 위 **Deploy** 버튼 → 배포 방식 선택 화면.
2. **Reserved VM**을 고릅니다. (Autoscale은 안 됩니다 — 이유는 아래)
3. 설정: Run command `npm start`, 포트는 자동 감지(우리 서버는 `PORT` 환경변수를 그대로 씁니다). Secrets는 자동으로 배포에도 적용됩니다.
4. **Deploy** 클릭 → 몇 분 뒤 `https://xxxx.replit.app` 주소가 나옵니다. 이 주소가 수강생에게 주는 주소입니다.
5. 배포 후 `https://xxxx.replit.app/admin`으로 관리자 로그인 → **코드** 메뉴에서 입장 코드 발급 → 코드 목록에 뜨는 가입 링크(`/signup?code=SJ1-XXXX`)를 구매자에게 txt로 전달.

> **왜 Reserved VM인가요?**
> 이 플랫폼은 모든 기록(가입·제출·승인·동의 시각)과 수강생 캡처 파일을 서버 안의 `data/` 폴더에 저장합니다. **Autoscale**은 서버가 수시로 새로 켜지고 꺼지면서 폴더 내용이 사라지기 때문에, 제출 기록과 이미지가 통째로 날아갈 수 있습니다(환불 분쟁 증거 소실). Reserved VM은 한 대가 계속 켜져 있어 폴더가 유지됩니다. 비용은 Reserved VM이 조금 더 들지만(월 정액), 1기 규모에서는 가장 작은 사양이면 충분합니다.
>
> Autoscale을 꼭 써야 한다면 DB를 외부(Postgres)로, 업로드를 외부 저장소로 옮기는 개조가 필요합니다. `db.js` 한 파일에 DB 접근을 모아뒀으므로 그때 로디가 그 파일만 바꾸면 됩니다.

### 2-6. 배포 후 매번 할 일
- 코드(미션 본문 등)를 GitHub에서 고쳤으면 Replit에서 **Git pull**(왼쪽 Git 도구 → Pull) → **Redeploy**.
- 미션 본문은 배포 없이 **관리자 화면 → 미션 → 편집**에서 바로 고칠 수 있습니다(파일보다 우선 적용).
- 가끔 `data/app.db`와 `data/uploads/`를 내려받아 백업. (관리자 화면의 CSV 내보내기는 표만 백업되고 이미지는 포함 안 됨)

---

## 3. 관리자 화면 사용법 (`/admin`)

| 메뉴 | 하는 일 |
|---|---|
| 홈 | 수강생 수·대기 건수·정체(3일 이상 멈춤) 수강생 |
| 대기열 | 제출된 순서(오래된 것부터). 캡처 보고 **승인** 또는 **보완 요청**(코멘트 필수). 승인하면 그 수강생의 다음 Day가 열림 |
| 수강생 | 진행률·마지막 제출·정체 일수·동의 여부. **졸업생 모드** 버튼 = 전체 미션 열람 허용. **CSV 내보내기** |
| 코드 | 입장 코드 발급(개수 지정)·목록·사용 여부. 발급 직후 "전체 복사"로 txt에 붙여넣기 |
| 미션 | Day 1~20 본문 편집(마크다운). ```로 감싼 코드 블록은 수강생 화면에서 자동으로 "복사하기" 버튼이 붙음 |

**AI 1차 피드백(로디가 사용)**: 관리자 API가 있습니다.
- `GET /api/admin/queue` — 대기열 JSON
- `GET /api/admin/submission/:id` — 제출 상세 + 이력
- `POST /api/admin/submission/:id/review` — `{"action":"approve"|"revision","comment":"..."}`
- 인증: 요청 헤더 `X-Admin-Password: (ADMIN_PASSWORD 값)`

---

## 4. 수강생 흐름 요약
1. `/signup?code=SJ1-XXXX` → 업체명·비밀번호 입력 → 닉네임 `업체명/1기` 생성 (코드 1개 = 계정 1개)
2. `/consent` — 환불 규정·복제 금지·개인정보 3개 체크 (시각·IP 기록)
3. `/` 대시보드 — 진행률·주차별·오늘 미션·응원 한 줄·최근 피드백. 마지막 승인 후 3일 지나면 "따라잡기" 배너
4. `/day/N` — Day N-1이 승인돼야 열림 (Day 1은 항상). 본문 상단·하단 + 배경에 `[닉네임] 전용 · 재배포 금지` 워터마크
5. `/day/N/submit` — 캡처 1~3장(각 5MB 이하, jpg/png/webp) + 메모. 보완 요청이면 재제출 가능, 이력은 전부 보관
6. 승인/보완 결과는 대시보드 알림 + Day 페이지에 표시

---

## 5. 내 컴퓨터에서 실행해 보기 (로디가 대신 할 수 있음)
1. Node.js 20 이상 설치된 PC에서 이 폴더를 엽니다.
2. `npm install` (처음 한 번) → `npm start`
3. 브라우저에서 `http://localhost:3000` (관리자 비밀번호 기본값 `admin1234`)
4. 입장 코드가 필요하면 `node seed_codes.js` (20개 생성해 화면에 출력) 또는 관리자 화면 "코드"에서 발급
5. 환경변수를 지정하려면 실행 전에 설정합니다. 예(윈도우 PowerShell): `$env:ADMIN_PASSWORD="비밀번호"; npm start`
6. 3000번 포트가 이미 사용 중이면 `PORT=3001`처럼 바꿔 실행

---

## 6. 알아둘 것 / 주의
- **`data/` 폴더 = 전부.** 지우거나 잃어버리면 수강생 계정·제출·승인 기록이 모두 사라집니다. Replit Reserved VM에서는 유지되지만, 주기적으로 내려받아 백업하세요.
- **ADMIN_PASSWORD를 꼭 설정**하세요. 기본값(`admin1234`)으로 배포하면 누구나 관리자 화면에 들어갈 수 있습니다.
- 동의 문구(`lib/consent.js`)를 바꾸면 그 안의 `VERSION`도 함께 바꿔야 "어느 문구에 동의했는지"가 기록에 남습니다.
- 수강생 캡처 이미지는 본인과 관리자만 볼 수 있습니다(로그인 필요).
- 텔레그램 알림은 "제출 시 관리자에게"만 갑니다. 수강생에게 가는 개인 알림은 2단계.

## 업데이트 반영 (2026-09-11 v4부터 두 갈래)
### A. 화면·교재만 바뀐 경우 (디자인, views/public/content) — Shell 없이 버튼 1번
관리자 홈(`/admin`) → 바로 가기 → **"화면 패치 적용"** 클릭. 서버가 `https://siljeon-ai-media.github.io/media/platform_patch.tar.gz`를 받아 views/public/content만 덮어씁니다. 새로고침(Ctrl+Shift+R)하면 반영. 로디가 관리자로 로그인된 브라우저에서 직접 눌러도 됩니다.
- 로디 쪽 절차: `platform/` 수정 → 로컬 확인 → `tar.exe -czf output/hosting/platform_patch.tar.gz views public content` → GitHub `media` 업로드 → 버튼.

### B. 서버 코드(server.js·lib·package.json)가 바뀐 경우 — Replit Shell에 한 줄 + 재시작
```bash
curl -sL "https://siljeon-ai-media.github.io/media/platform_full.tar.gz?t=$(date +%s)" | tar xz && npm install --silent && echo 적용완료
```
그 다음 상단 ■(중지) → ▶ Run. `data/`(수강생 기록·업로드)와 `.replit`은 건드리지 않습니다.
- 로디 쪽 절차: `tar.exe -czf output/hosting/platform_full.tar.gz --exclude=node_modules --exclude=data --exclude=siljeon-cohort.zip .` → GitHub 업로드 → 위 명령 전달.
