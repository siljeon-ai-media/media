// 복사 칩 렌더 시험: 화면에 보이는 글자와 복사되는 글자(data-copy)가 같고, 특수문자도 그대로 복사된다.
"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { render } = require("../lib/markdown");

function chips(html) {
  const out = [];
  const re = /<button type="button" class="copy-chip" data-copy="([^"]*)"[^>]*><span class="copy-chip-text">([^<]*)<\/span>/g;
  let m; while ((m = re.exec(html))) out.push({ copy: m[1], shown: m[2] });
  return out;
}
const unesc = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&");

test("복사 칩: 보이는 글자 = 복사되는 글자, 문장·표·굵은 글씨 안에서도 동작", () => {
  const md = "검색창에 {{복사:siljeon_order_bot}} 을 쳐요.\n\n| 말 | 뜻 |\n|---|---|\n| {{복사:열쇠 다시}} | 새 열쇠 |\n\n링크는 {{복사:https://t.me/+AbC_123?x=1&y=2}} 예요. **{{복사:/start_check}}**";
  const got = chips(render(md));
  assert.deepEqual(got.map((c) => unesc(c.copy)), ["siljeon_order_bot", "열쇠 다시", "https://t.me/+AbC_123?x=1&y=2", "/start_check"]);
  for (const c of got) assert.equal(c.copy, c.shown);
});

test("복사 칩: 표기가 아닌 글은 그대로, 코드 상자 안의 표기는 칩이 되지 않음", () => {
  const html = render("그냥 {{복사 글}} 과 `{{복사:x}}`\n\n```bot\n{{복사:y}}\n```");
  assert.equal(chips(html).length, 0);
});
