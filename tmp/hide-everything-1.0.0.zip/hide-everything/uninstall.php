<?php
/**
 * Remove all plugin data when the plugin is deleted from the Plugins screen.
 *
 * @package HideEverything
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Delete the option and every per-post toggle on the current site.
 */
function hideev_uninstall_current_site() {
	delete_option( 'hideev_settings' );

	foreach ( array( 'title', 'featured_image', 'author', 'date', 'terms' ) as $hideev_element ) {
		delete_post_meta_by_key( '_hideev_hide_' . $hideev_element );
	}
}

if ( is_multisite() ) {
	$hideev_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $hideev_site_ids as $hideev_site_id ) {
		switch_to_blog( (int) $hideev_site_id );
		hideev_uninstall_current_site();
		restore_current_blog();
	}
} else {
	hideev_uninstall_current_site();
}
