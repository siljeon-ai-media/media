/**
 * Hide Everything: block editor sidebar panel.
 *
 * Plain ES5 + wp.element.createElement, so no build step is needed.
 * All labels come from PHP (window.hideevEditorData) and are translated there.
 */
( function ( wp, settings ) {
	'use strict';

	if ( ! wp || ! settings || ! wp.plugins || ! wp.element || ! wp.components || ! wp.data ) {
		return;
	}

	var el = wp.element.createElement;
	var Panel =
		( wp.editor && wp.editor.PluginDocumentSettingPanel ) ||
		( wp.editPost && wp.editPost.PluginDocumentSettingPanel );

	if ( ! Panel || ! wp.data.useSelect || ! wp.data.useDispatch ) {
		return;
	}

	var SelectControl = wp.components.SelectControl;
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;

	function HideEverythingPanel() {
		var meta = useSelect( function ( select ) {
			return select( 'core/editor' ).getEditedPostAttribute( 'meta' );
		}, [] );
		var editPost = useDispatch( 'core/editor' ).editPost;

		if ( ! meta || typeof meta !== 'object' ) {
			return null;
		}

		var controls = [];

		settings.elements.forEach( function ( item ) {
			var metaKey = item.metaKey;

			// The key is missing when this post type does not expose our meta via REST.
			if ( typeof meta[ metaKey ] === 'undefined' ) {
				return;
			}

			var value = meta[ metaKey ];
			if ( value !== '0' && value !== '1' ) {
				value = '';
			}

			controls.push(
				el( SelectControl, {
					key: metaKey,
					label: item.label,
					value: value,
					options: item.options,
					__nextHasNoMarginBottom: true,
					onChange: function ( next ) {
						var update = Object.assign( {}, meta );
						update[ metaKey ] = next === '0' || next === '1' ? next : '';
						editPost( { meta: update } );
					},
				} )
			);
		} );

		if ( ! controls.length ) {
			return null;
		}

		return el(
			Panel,
			{
				name: 'hide-everything-panel',
				title: settings.i18n.panelTitle,
				className: 'hideev-editor-panel',
			},
			el( 'p', { className: 'hideev-editor-panel__help' }, settings.i18n.help ),
			controls
		);
	}

	wp.plugins.registerPlugin( 'hide-everything', {
		render: HideEverythingPanel,
		icon: 'hidden',
	} );
} )( window.wp, window.hideevEditorData );
