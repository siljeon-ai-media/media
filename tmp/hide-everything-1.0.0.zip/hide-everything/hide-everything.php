<?php
/**
 * Plugin Name:       Hide Everything
 * Description:       Hide the title, featured image, author, date and categories/tags on individual posts and pages. Works with classic and block themes.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            siljeon.ai
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       hide-everything
 * Domain Path:       /languages
 *
 * @package HideEverything
 */

/*
 * Hide Everything is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * Hide Everything is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'HIDEEV_VERSION' ) ) {
	// Another copy of this plugin (or a conflicting plugin) is already loaded.
	return;
}

define( 'HIDEEV_VERSION', '1.0.0' );
define( 'HIDEEV_PLUGIN_FILE', __FILE__ );
define( 'HIDEEV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'HIDEEV_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once HIDEEV_PLUGIN_DIR . 'includes/he-core.php';
require_once HIDEEV_PLUGIN_DIR . 'includes/he-meta.php';
require_once HIDEEV_PLUGIN_DIR . 'includes/he-frontend.php';

if ( is_admin() ) {
	require_once HIDEEV_PLUGIN_DIR . 'includes/he-admin.php';
}
