<?php
/**
 * Settings > Hide Everything (Settings API).
 *
 * @package HideEverything
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'hideev_add_settings_page' );
add_action( 'admin_init', 'hideev_register_settings' );
add_filter( 'plugin_action_links_' . plugin_basename( HIDEEV_PLUGIN_FILE ), 'hideev_plugin_action_links' );

/**
 * Add the settings page under Settings.
 */
function hideev_add_settings_page() {
	add_options_page(
		__( 'Hide Everything', 'hide-everything' ),
		__( 'Hide Everything', 'hide-everything' ),
		'manage_options',
		'hide-everything',
		'hideev_render_settings_page'
	);
}

/**
 * Register the option, sections and fields.
 */
function hideev_register_settings() {
	register_setting(
		'hideev_settings_group',
		'hideev_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'hideev_sanitize_settings',
			'default'           => hideev_default_settings(),
			'show_in_rest'      => false,
		)
	);

	add_settings_section(
		'hideev_section_defaults',
		__( 'Default visibility', 'hide-everything' ),
		'hideev_render_section_defaults',
		'hide-everything'
	);

	add_settings_section(
		'hideev_section_behavior',
		__( 'Behavior', 'hide-everything' ),
		'hideev_render_section_behavior',
		'hide-everything'
	);

	add_settings_field(
		'hideev_field_scope',
		__( 'Where to hide', 'hide-everything' ),
		'hideev_render_field_scope',
		'hide-everything',
		'hideev_section_behavior'
	);

	add_settings_field(
		'hideev_field_compat',
		__( 'Theme compatibility', 'hide-everything' ),
		'hideev_render_field_compat',
		'hide-everything',
		'hideev_section_behavior'
	);
}

/**
 * Sanitize the whole settings array.
 *
 * @param mixed $input Raw input.
 * @return array
 */
function hideev_sanitize_settings( $input ) {
	$clean = hideev_default_settings();

	if ( ! is_array( $input ) ) {
		return $clean;
	}

	$clean['scope']              = ( isset( $input['scope'] ) && 'everywhere' === $input['scope'] ) ? 'everywhere' : 'singular';
	$clean['css_fallback']       = empty( $input['css_fallback'] ) ? 0 : 1;
	$clean['block_meta_cleanup'] = empty( $input['block_meta_cleanup'] ) ? 0 : 1;

	$global = ( isset( $input['global'] ) && is_array( $input['global'] ) ) ? $input['global'] : array();
	foreach ( hideev_get_element_keys() as $element ) {
		$clean['global'][ $element ] = empty( $global[ $element ] ) ? 0 : 1;
	}

	$types = ( isset( $input['post_types'] ) && is_array( $input['post_types'] ) ) ? $input['post_types'] : array();
	foreach ( hideev_get_supported_post_types() as $post_type ) {
		if ( ! isset( $types[ $post_type ] ) || ! is_array( $types[ $post_type ] ) ) {
			continue;
		}
		foreach ( hideev_get_element_keys() as $element ) {
			$value = isset( $types[ $post_type ][ $element ] ) ? hideev_sanitize_toggle( $types[ $post_type ][ $element ] ) : '';
			if ( '' !== $value ) {
				$clean['post_types'][ $post_type ][ $element ] = $value;
			}
		}
	}

	return $clean;
}

/**
 * Render the settings page.
 */
function hideev_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'hideev_settings_group' );
			do_settings_sections( 'hide-everything' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/**
 * Defaults section: one row for all post types, then one row per post type.
 */
function hideev_render_section_defaults() {
	$settings = hideev_get_settings();
	$labels   = hideev_get_element_labels();
	$types    = hideev_get_supported_post_types();

	echo '<p>' . esc_html__( 'Choose what is hidden when a post or page has no setting of its own. Each item can still override this in the editor.', 'hide-everything' ) . '</p>';
	?>
	<table class="widefat striped hideev-defaults-table" style="max-width: 960px;">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Applies to', 'hide-everything' ); ?></th>
				<?php foreach ( $labels as $label ) : ?>
					<th scope="col"><?php echo esc_html( $label ); ?></th>
				<?php endforeach; ?>
			</tr>
		</thead>
		<tbody>
			<tr>
				<th scope="row"><strong><?php esc_html_e( 'All content types', 'hide-everything' ); ?></strong></th>
				<?php foreach ( $labels as $element => $label ) : ?>
					<?php $field_id = 'hideev-global-' . str_replace( '_', '-', $element ); ?>
					<td>
						<input type="checkbox" id="<?php echo esc_attr( $field_id ); ?>" name="hideev_settings[global][<?php echo esc_attr( $element ); ?>]" value="1" <?php checked( ! empty( $settings['global'][ $element ] ) ); ?> />
						<label for="<?php echo esc_attr( $field_id ); ?>">
							<?php
							/* translators: %s: element name, for example "Title". */
							printf( esc_html__( 'Hide %s', 'hide-everything' ), esc_html( $label ) );
							?>
						</label>
					</td>
				<?php endforeach; ?>
			</tr>
			<?php foreach ( $types as $post_type ) : ?>
				<?php
				$type_object = get_post_type_object( $post_type );
				if ( ! $type_object ) {
					continue;
				}
				$type_values = ( isset( $settings['post_types'][ $post_type ] ) && is_array( $settings['post_types'][ $post_type ] ) ) ? $settings['post_types'][ $post_type ] : array();
				?>
				<tr>
					<th scope="row"><?php echo esc_html( $type_object->labels->name ); ?></th>
					<?php foreach ( $labels as $element => $label ) : ?>
						<?php
						$value    = isset( $type_values[ $element ] ) ? hideev_sanitize_toggle( $type_values[ $element ] ) : '';
						$field_id = 'hideev-type-' . sanitize_html_class( $post_type ) . '-' . str_replace( '_', '-', $element );
						?>
						<td>
							<label class="screen-reader-text" for="<?php echo esc_attr( $field_id ); ?>">
								<?php echo esc_html( $type_object->labels->name . ' / ' . $label ); ?>
							</label>
							<select id="<?php echo esc_attr( $field_id ); ?>" name="hideev_settings[post_types][<?php echo esc_attr( $post_type ); ?>][<?php echo esc_attr( $element ); ?>]">
								<option value="" <?php selected( $value, '' ); ?>><?php esc_html_e( 'Same as all', 'hide-everything' ); ?></option>
								<option value="1" <?php selected( $value, '1' ); ?>><?php esc_html_e( 'Hide', 'hide-everything' ); ?></option>
								<option value="0" <?php selected( $value, '0' ); ?>><?php esc_html_e( 'Show', 'hide-everything' ); ?></option>
							</select>
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * Behavior section description.
 */
function hideev_render_section_behavior() {
	echo '<p>' . esc_html__( 'Fine-tune where and how hidden elements are removed.', 'hide-everything' ) . '</p>';
}

/**
 * Scope field.
 */
function hideev_render_field_scope() {
	$settings = hideev_get_settings();
	?>
	<fieldset>
		<legend class="screen-reader-text"><?php esc_html_e( 'Where to hide', 'hide-everything' ); ?></legend>
		<label>
			<input type="radio" name="hideev_settings[scope]" value="singular" <?php checked( $settings['scope'], 'singular' ); ?> />
			<?php esc_html_e( 'Only on the single post or page view (recommended)', 'hide-everything' ); ?>
		</label>
		<br />
		<label>
			<input type="radio" name="hideev_settings[scope]" value="everywhere" <?php checked( $settings['scope'], 'everywhere' ); ?> />
			<?php esc_html_e( 'Everywhere the post appears, including blog lists, archives and search results', 'hide-everything' ); ?>
		</label>
		<p class="description"><?php esc_html_e( 'Hiding titles in lists can leave visitors without a link to the post, so the single view is the safer choice.', 'hide-everything' ); ?></p>
	</fieldset>
	<?php
}

/**
 * Theme compatibility field.
 */
function hideev_render_field_compat() {
	$settings = hideev_get_settings();
	?>
	<fieldset>
		<legend class="screen-reader-text"><?php esc_html_e( 'Theme compatibility', 'hide-everything' ); ?></legend>
		<label>
			<input type="checkbox" name="hideev_settings[block_meta_cleanup]" value="1" <?php checked( ! empty( $settings['block_meta_cleanup'] ) ); ?> />
			<?php esc_html_e( 'Block themes: also remove small groups left with only labels such as "by" or "in"', 'hide-everything' ); ?>
		</label>
		<br />
		<label>
			<input type="checkbox" name="hideev_settings[css_fallback]" value="1" <?php checked( ! empty( $settings['css_fallback'] ) ); ?> />
			<?php esc_html_e( 'Classic themes: load a small stylesheet that hides leftover wrappers such as "Posted on" or "by"', 'hide-everything' ); ?>
		</label>
		<p class="description"><?php esc_html_e( 'Hidden content is removed on the server first. These options only tidy up the text that some themes print around it.', 'hide-everything' ); ?></p>
	</fieldset>
	<?php
}

/**
 * Add a Settings link on the Plugins screen.
 *
 * @param string[] $links Action links.
 * @return string[]
 */
function hideev_plugin_action_links( $links ) {
	$url = admin_url( 'options-general.php?page=hide-everything' );
	array_unshift(
		$links,
		sprintf( '<a href="%1$s">%2$s</a>', esc_url( $url ), esc_html__( 'Settings', 'hide-everything' ) )
	);
	return $links;
}
