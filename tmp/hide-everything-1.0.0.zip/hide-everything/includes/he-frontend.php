<?php
/**
 * Front-end output filters.
 *
 * Elements are removed on the server wherever WordPress offers a filter, so the
 * hidden text never reaches the page (or screen readers). The optional CSS file
 * only cleans up leftover wrappers that classic themes print around the data.
 *
 * @package HideEverything
 */

defined( 'ABSPATH' ) || exit;

// Title (classic themes; block themes are handled in hideev_filter_render_block()).
// Late priority: some themes (e.g. Twenty Twenty-One) replace an empty title with "Untitled" at priority 10.
add_filter( 'the_title', 'hideev_filter_the_title', PHP_INT_MAX, 2 );

// Featured image.
add_filter( 'post_thumbnail_html', 'hideev_filter_post_thumbnail_html', 10, 2 );
add_filter( 'has_post_thumbnail', 'hideev_filter_has_post_thumbnail', 10, 2 );

// Author.
add_filter( 'the_author', 'hideev_filter_the_author' );
add_filter( 'the_author_posts_link', 'hideev_filter_the_author_posts_link' );

// Date.
add_filter( 'get_the_date', 'hideev_filter_date', 10, 3 );
add_filter( 'get_the_time', 'hideev_filter_date', 10, 3 );
add_filter( 'get_the_modified_date', 'hideev_filter_date', 10, 3 );
add_filter( 'get_the_modified_time', 'hideev_filter_date', 10, 3 );

// Categories, tags and other terms.
add_filter( 'the_category', 'hideev_filter_category_list' );
add_filter( 'the_tags', 'hideev_filter_tag_list', 10, 5 );
add_filter( 'the_terms', 'hideev_filter_term_list' );

// Blocks (block themes and Query Loop blocks anywhere).
add_filter( 'render_block', 'hideev_filter_render_block', 10, 3 );

// Classic theme helpers.
add_filter( 'post_class', 'hideev_filter_post_class', 10, 3 );
add_action( 'wp_enqueue_scripts', 'hideev_enqueue_frontend_assets' );

/**
 * Whether a classic (non-block) template tag filter may act right now.
 *
 * With the "everywhere" scope we only act inside The Loop, so archive headings
 * such as "Author: Jane" or date archive titles are left alone.
 *
 * @return bool
 */
function hideev_classic_context_ok() {
	$settings = hideev_get_settings();
	return in_the_loop() || 'everywhere' !== $settings['scope'];
}

/**
 * Hide the post title in classic themes.
 *
 * Only inside The Loop, so navigation menus and widgets that reuse the same
 * filter keep their titles.
 *
 * @param string $title   Post title.
 * @param int    $post_id Post ID.
 * @return string
 */
function hideev_filter_the_title( $title, $post_id = 0 ) {
	$post_id = (int) $post_id;
	if ( ! $post_id || wp_is_block_theme() || ! in_the_loop() ) {
		return $title;
	}
	return hideev_should_hide( 'title', $post_id ) ? '' : $title;
}

/**
 * Remove the featured image markup.
 *
 * @param string $html    Thumbnail HTML.
 * @param int    $post_id Post ID.
 * @return string
 */
function hideev_filter_post_thumbnail_html( $html, $post_id ) {
	return hideev_should_hide( 'featured_image', (int) $post_id ) ? '' : $html;
}

/**
 * Report "no thumbnail" so themes skip their thumbnail wrappers too.
 *
 * @param bool             $has_thumbnail Whether the post has a thumbnail.
 * @param int|WP_Post|null $post          Post ID or object.
 * @return bool
 */
function hideev_filter_has_post_thumbnail( $has_thumbnail, $post = null ) {
	if ( ! $has_thumbnail ) {
		return $has_thumbnail;
	}
	$post = get_post( $post );
	if ( $post && hideev_should_hide( 'featured_image', $post->ID ) ) {
		return false;
	}
	return $has_thumbnail;
}

/**
 * Current post ID for template tags that do not pass one.
 *
 * @return int
 */
function hideev_current_post_id() {
	$post = get_post();
	return $post ? (int) $post->ID : 0;
}

/**
 * Hide the author display name.
 *
 * @param string|null $display_name Author display name.
 * @return string|null
 */
function hideev_filter_the_author( $display_name ) {
	$post_id = hideev_current_post_id();
	if ( $post_id && hideev_classic_context_ok() && hideev_should_hide( 'author', $post_id ) ) {
		return '';
	}
	return $display_name;
}

/**
 * Hide the author posts link.
 *
 * @param string $link Author link HTML.
 * @return string
 */
function hideev_filter_the_author_posts_link( $link ) {
	$post_id = hideev_current_post_id();
	if ( $post_id && hideev_classic_context_ok() && hideev_should_hide( 'author', $post_id ) ) {
		return '';
	}
	return $link;
}

/**
 * Hide published/modified dates and times.
 *
 * Timestamp formats ('U', 'G') are left untouched because themes and plugins
 * use them for arithmetic, and an empty string would break that on PHP 8.
 *
 * @param string|int       $value  Formatted date or time.
 * @param string           $format Requested format.
 * @param WP_Post|int|null $post   Post object.
 * @return string|int
 */
function hideev_filter_date( $value, $format = '', $post = null ) {
	if ( in_array( $format, array( 'U', 'G' ), true ) ) {
		return $value;
	}
	$post = get_post( $post );
	if ( $post && hideev_classic_context_ok() && hideev_should_hide( 'date', $post->ID ) ) {
		return '';
	}
	return $value;
}

/**
 * Hide the category list.
 *
 * @param string $list Category list HTML.
 * @return string
 */
function hideev_filter_category_list( $list ) {
	$post_id = hideev_current_post_id();
	if ( $post_id && hideev_classic_context_ok() && hideev_should_hide( 'terms', $post_id ) ) {
		return '';
	}
	return $list;
}

/**
 * Hide the tag list.
 *
 * @param string $tag_list Tag list HTML.
 * @param string $before   Text before the list.
 * @param string $sep      Separator.
 * @param string $after    Text after the list.
 * @param int    $post_id  Post ID.
 * @return string
 */
function hideev_filter_tag_list( $tag_list, $before = '', $sep = '', $after = '', $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : hideev_current_post_id();
	if ( $post_id && hideev_classic_context_ok() && hideev_should_hide( 'terms', $post_id ) ) {
		return '';
	}
	return $tag_list;
}

/**
 * Hide term lists printed with the_terms().
 *
 * @param string $term_list Term list HTML.
 * @return string
 */
function hideev_filter_term_list( $term_list ) {
	$post_id = hideev_current_post_id();
	if ( $post_id && hideev_classic_context_ok() && hideev_should_hide( 'terms', $post_id ) ) {
		return '';
	}
	return $term_list;
}

/**
 * Map of core blocks to the element they display.
 *
 * @return array<string,string>
 */
function hideev_get_block_map() {
	$map = array(
		'core/post-title'            => 'title',
		'core/post-featured-image'   => 'featured_image',
		'core/post-author'           => 'author',
		'core/post-author-name'      => 'author',
		'core/post-author-biography' => 'author',
		'core/avatar'                => 'author',
		'core/post-date'             => 'date',
		'core/post-terms'            => 'terms',
	);

	/**
	 * Filters the block-name => element map used to hide blocks.
	 *
	 * @param array<string,string> $map Block name => element key.
	 */
	return (array) apply_filters( 'hideev_block_map', $map );
}

/**
 * Post ID a block renders for.
 *
 * @param WP_Block|null $instance Block instance.
 * @return int
 */
function hideev_block_post_id( $instance ) {
	if ( $instance instanceof WP_Block && isset( $instance->context['postId'] ) ) {
		return (int) $instance->context['postId'];
	}
	return hideev_current_post_id();
}

/**
 * Remove hidden blocks, and (optionally) the small meta groups left behind.
 *
 * @param string        $block_content Rendered block HTML.
 * @param array         $block         Parsed block.
 * @param WP_Block|null $instance      Block instance.
 * @return string
 */
function hideev_filter_render_block( $block_content, $block, $instance = null ) {
	if ( ! is_array( $block ) || empty( $block['blockName'] ) ) {
		return $block_content;
	}

	$name = $block['blockName'];
	$map  = hideev_get_block_map();

	if ( isset( $map[ $name ] ) ) {
		// The avatar block is only treated as "author" when it shows a post author, not a commenter.
		if ( 'core/avatar' === $name ) {
			if ( ! $instance instanceof WP_Block || ! isset( $instance->context['postId'] ) || isset( $instance->context['commentId'] ) ) {
				return $block_content;
			}
		}

		$post_id = hideev_block_post_id( $instance );
		if ( $post_id && hideev_should_hide( $map[ $name ], $post_id ) ) {
			return '';
		}
		return $block_content;
	}

	if ( 'core/group' === $name ) {
		$settings = hideev_get_settings();
		if ( ! empty( $settings['block_meta_cleanup'] ) ) {
			$post_id = hideev_current_post_id();
			if ( $post_id && hideev_post_has_hidden_elements( $post_id ) && hideev_is_leftover_meta_group( $block, $post_id ) ) {
				return '';
			}
		}
	}

	return $block_content;
}

/**
 * Whether a group block only holds hidden meta blocks plus short labels
 * (for example "by" or "in"), so removing it leaves no orphaned words.
 *
 * @param array $block   Parsed group block.
 * @param int   $post_id Post ID.
 * @return bool
 */
function hideev_is_leftover_meta_group( $block, $post_id ) {
	$found_hidden = false;
	$inner        = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? $block['innerBlocks'] : array();

	if ( empty( $inner ) ) {
		return false;
	}

	$only_meta = hideev_scan_meta_tree( $inner, $post_id, $found_hidden, 0 );
	return $only_meta && $found_hidden;
}

/**
 * Recursive helper for hideev_is_leftover_meta_group().
 *
 * @param array $blocks       Parsed inner blocks.
 * @param int   $post_id      Post ID.
 * @param bool  $found_hidden Set to true when a hidden meta block is found.
 * @param int   $depth        Current depth.
 * @return bool True when every block is a hidden meta block, a short label or a nested group of those.
 */
function hideev_scan_meta_tree( $blocks, $post_id, &$found_hidden, $depth ) {
	if ( $depth > 5 ) {
		return false;
	}

	$map = hideev_get_block_map();

	foreach ( $blocks as $inner ) {
		if ( ! is_array( $inner ) ) {
			continue;
		}

		$name = isset( $inner['blockName'] ) ? $inner['blockName'] : null;
		$html = isset( $inner['innerHTML'] ) ? (string) $inner['innerHTML'] : '';

		if ( null === $name ) {
			// Freeform content between blocks: whitespace is fine, real text is not.
			if ( '' !== trim( wp_strip_all_tags( $html ) ) ) {
				return false;
			}
			continue;
		}

		// Avatars may belong to a commenter; without block context we cannot tell, so keep the group.
		if ( 'core/avatar' === $name ) {
			return false;
		}

		if ( isset( $map[ $name ] ) ) {
			if ( ! hideev_should_hide( $map[ $name ], $post_id ) ) {
				return false;
			}
			$found_hidden = true;
			continue;
		}

		if ( 'core/paragraph' === $name ) {
			$text   = trim( wp_strip_all_tags( $html ) );
			$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
			if ( $length > 20 ) {
				return false;
			}
			continue;
		}

		if ( 'core/group' === $name ) {
			$children = isset( $inner['innerBlocks'] ) && is_array( $inner['innerBlocks'] ) ? $inner['innerBlocks'] : array();
			if ( ! hideev_scan_meta_tree( $children, $post_id, $found_hidden, $depth + 1 ) ) {
				return false;
			}
			continue;
		}

		return false;
	}

	return true;
}

/**
 * Add "hideev-hides-*" classes to the post wrapper (classic themes) so the
 * fallback CSS can hide leftover labels such as "Posted on" or "by".
 *
 * @param string[] $classes Post classes.
 * @param string[] $class   Extra classes passed to post_class().
 * @param int      $post_id Post ID.
 * @return string[]
 */
function hideev_filter_post_class( $classes, $class, $post_id ) {
	if ( wp_is_block_theme() || ! hideev_css_fallback_enabled() ) {
		return $classes;
	}

	foreach ( hideev_get_element_keys() as $element ) {
		if ( hideev_should_hide( $element, (int) $post_id ) ) {
			$classes[] = 'hideev-hides-' . str_replace( '_', '-', $element );
		}
	}

	return $classes;
}

/**
 * Whether the classic-theme CSS fallback is enabled.
 *
 * @return bool
 */
function hideev_css_fallback_enabled() {
	$settings = hideev_get_settings();
	return ! empty( $settings['css_fallback'] );
}

/**
 * Enqueue the classic-theme fallback stylesheet only when it can matter.
 */
function hideev_enqueue_frontend_assets() {
	if ( wp_is_block_theme() || ! hideev_css_fallback_enabled() ) {
		return;
	}

	$settings = hideev_get_settings();
	$needed   = 'everywhere' === $settings['scope'];

	if ( ! $needed && is_singular() ) {
		$needed = hideev_post_has_hidden_elements( (int) get_queried_object_id() );
	}

	if ( ! $needed ) {
		return;
	}

	wp_enqueue_style(
		'hideev-classic-fallback',
		HIDEEV_PLUGIN_URL . 'assets/css/classic-fallback.css',
		array(),
		HIDEEV_VERSION
	);
}
