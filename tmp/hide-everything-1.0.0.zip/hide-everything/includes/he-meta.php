<?php
/**
 * Per-post toggles: meta registration, block editor panel and classic meta box.
 *
 * @package HideEverything
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'hideev_register_post_meta', 20 );
add_action( 'add_meta_boxes', 'hideev_add_meta_box', 10, 2 );
add_action( 'save_post', 'hideev_save_meta_box', 10, 2 );
add_action( 'enqueue_block_editor_assets', 'hideev_enqueue_editor_assets' );

/**
 * Register the per-post meta keys so the block editor can edit them via REST.
 */
function hideev_register_post_meta() {
	foreach ( hideev_get_supported_post_types() as $post_type ) {
		foreach ( hideev_get_element_keys() as $element ) {
			register_post_meta(
				$post_type,
				hideev_meta_key( $element ),
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'hideev_sanitize_toggle',
					'auth_callback'     => 'hideev_meta_auth_callback',
				)
			);
		}
	}
}

/**
 * Only users who can edit the post may change its toggles.
 *
 * @param bool   $allowed   Whether the user can add the meta.
 * @param string $meta_key  Meta key.
 * @param int    $object_id Post ID.
 * @return bool
 */
function hideev_meta_auth_callback( $allowed, $meta_key, $object_id ) {
	return current_user_can( 'edit_post', (int) $object_id );
}

/**
 * Choices for a per-post toggle, with the current default spelled out.
 *
 * @param bool $default_hidden Whether the element is hidden by default.
 * @return array<string,string> Value => label.
 */
function hideev_get_toggle_choices( $default_hidden ) {
	return array(
		''  => $default_hidden
			? __( 'Default (hidden)', 'hide-everything' )
			: __( 'Default (shown)', 'hide-everything' ),
		'1' => __( 'Hide', 'hide-everything' ),
		'0' => __( 'Show', 'hide-everything' ),
	);
}

/**
 * Add the classic meta box.
 *
 * When the block editor can edit the meta via REST, the meta box is kept for
 * the classic editor only and the sidebar panel is used instead.
 *
 * @param string $post_type Post type of the current screen.
 * @param mixed  $post      Current object (WP_Post for posts).
 */
function hideev_add_meta_box( $post_type, $post ) {
	if ( ! $post instanceof WP_Post || ! in_array( $post_type, hideev_get_supported_post_types(), true ) ) {
		return;
	}

	$args = null;
	if ( hideev_post_type_has_rest_meta( $post_type ) ) {
		$args = array( '__back_compat_meta_box' => true );
	}

	add_meta_box(
		'hideev-visibility',
		__( 'Hide Everything', 'hide-everything' ),
		'hideev_render_meta_box',
		$post_type,
		'side',
		'default',
		$args
	);
}

/**
 * Render the classic meta box.
 *
 * @param WP_Post $post Current post.
 */
function hideev_render_meta_box( $post ) {
	wp_nonce_field( 'hideev_save_post_meta', 'hideev_meta_nonce' );

	$defaults = hideev_get_type_defaults( $post->post_type );

	echo '<p class="description">' . esc_html__( 'Choose what to hide on this item. "Default" follows Settings > Hide Everything.', 'hide-everything' ) . '</p>';

	foreach ( hideev_get_element_labels() as $element => $label ) {
		$value    = hideev_sanitize_toggle( get_post_meta( $post->ID, hideev_meta_key( $element ), true ) );
		$field_id = 'hideev-hide-' . str_replace( '_', '-', $element );

		printf(
			'<p><label for="%1$s">%2$s</label><br /><select id="%1$s" name="hideev_hide[%3$s]">',
			esc_attr( $field_id ),
			esc_html( $label ),
			esc_attr( $element )
		);

		foreach ( hideev_get_toggle_choices( $defaults[ $element ] ) as $choice_value => $choice_label ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( (string) $choice_value ),
				selected( $value, (string) $choice_value, false ),
				esc_html( $choice_label )
			);
		}

		echo '</select></p>';
	}
}

/**
 * Save the classic meta box.
 *
 * @param int     $post_id Post ID.
 * @param WP_Post $post    Post object.
 */
function hideev_save_meta_box( $post_id, $post ) {
	if ( ! isset( $_POST['hideev_meta_nonce'] ) ) {
		return;
	}

	$nonce = sanitize_text_field( wp_unslash( $_POST['hideev_meta_nonce'] ) );
	if ( ! wp_verify_nonce( $nonce, 'hideev_save_post_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, hideev_get_supported_post_types(), true ) ) {
		return;
	}

	$input = array();
	if ( isset( $_POST['hideev_hide'] ) && is_array( $_POST['hideev_hide'] ) ) {
		$input = map_deep( wp_unslash( $_POST['hideev_hide'] ), 'sanitize_text_field' );
	}

	foreach ( hideev_get_element_keys() as $element ) {
		$value = isset( $input[ $element ] ) ? hideev_sanitize_toggle( $input[ $element ] ) : '';
		$key   = hideev_meta_key( $element );

		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
	}
}

/**
 * Load the block editor sidebar panel.
 */
function hideev_enqueue_editor_assets() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'post' !== $screen->base ) {
		return;
	}

	$post_type = $screen->post_type;
	if ( ! in_array( $post_type, hideev_get_supported_post_types(), true ) || ! hideev_post_type_has_rest_meta( $post_type ) ) {
		return;
	}

	wp_enqueue_script(
		'hideev-editor-panel',
		HIDEEV_PLUGIN_URL . 'assets/js/editor-panel.js',
		array( 'wp-plugins', 'wp-edit-post', 'wp-editor', 'wp-element', 'wp-components', 'wp-data' ),
		HIDEEV_VERSION,
		true
	);

	$defaults = hideev_get_type_defaults( $post_type );
	$elements = array();
	foreach ( hideev_get_element_labels() as $element => $label ) {
		$elements[] = array(
			'key'     => $element,
			'metaKey' => hideev_meta_key( $element ),
			'label'   => $label,
			'options' => array(
				array(
					'value' => '',
					'label' => $defaults[ $element ]
						? __( 'Default (hidden)', 'hide-everything' )
						: __( 'Default (shown)', 'hide-everything' ),
				),
				array(
					'value' => '1',
					'label' => __( 'Hide', 'hide-everything' ),
				),
				array(
					'value' => '0',
					'label' => __( 'Show', 'hide-everything' ),
				),
			),
		);
	}

	$data = array(
		'elements' => $elements,
		'i18n'     => array(
			'panelTitle' => __( 'Hide Everything', 'hide-everything' ),
			'help'       => __( 'Choose what to hide on this item. "Default" follows Settings > Hide Everything.', 'hide-everything' ),
		),
	);

	wp_add_inline_script(
		'hideev-editor-panel',
		'window.hideevEditorData = ' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';',
		'before'
	);
}
