<?php
/**
 * Core helpers: element list, settings and per-post resolution.
 *
 * @package HideEverything
 */

defined( 'ABSPATH' ) || exit;

/**
 * Machine names of the elements this plugin can hide.
 *
 * Kept free of translation calls so it is safe to use before `init`.
 *
 * @return string[]
 */
function hideev_get_element_keys() {
	return array( 'title', 'featured_image', 'author', 'date', 'terms' );
}

/**
 * Translated labels for each element. Call only after `init`.
 *
 * @return array<string,string>
 */
function hideev_get_element_labels() {
	return array(
		'title'          => __( 'Title', 'hide-everything' ),
		'featured_image' => __( 'Featured image', 'hide-everything' ),
		'author'         => __( 'Author', 'hide-everything' ),
		'date'           => __( 'Date', 'hide-everything' ),
		'terms'          => __( 'Categories and tags', 'hide-everything' ),
	);
}

/**
 * Post meta key that stores the per-post toggle for an element.
 *
 * @param string $element Element key.
 * @return string
 */
function hideev_meta_key( $element ) {
	return '_hideev_hide_' . $element;
}

/**
 * Normalise a tri-state toggle value.
 *
 * ''  = inherit the default, '1' = hide, '0' = show.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function hideev_sanitize_toggle( $value ) {
	if ( is_bool( $value ) ) {
		return $value ? '1' : '0';
	}
	$value = is_scalar( $value ) ? trim( (string) $value ) : '';
	return in_array( $value, array( '0', '1' ), true ) ? $value : '';
}

/**
 * Post types that get the per-post toggles.
 *
 * @return string[]
 */
function hideev_get_supported_post_types() {
	$types = get_post_types(
		array(
			'public'  => true,
			'show_ui' => true,
		),
		'names'
	);
	unset( $types['attachment'] );

	/**
	 * Filters the post types that Hide Everything supports.
	 *
	 * @param string[] $types Post type names.
	 */
	$types = apply_filters( 'hideev_supported_post_types', array_values( $types ) );

	return array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $types ) ) ) );
}

/**
 * Whether the block editor can read and write our meta through the REST API
 * for a post type. When it cannot, the classic meta box is shown instead.
 *
 * @param string $post_type Post type name.
 * @return bool
 */
function hideev_post_type_has_rest_meta( $post_type ) {
	$object = get_post_type_object( $post_type );
	return $object && ! empty( $object->show_in_rest ) && post_type_supports( $post_type, 'custom-fields' );
}

/**
 * Default plugin settings.
 *
 * @return array
 */
function hideev_default_settings() {
	return array(
		'scope'              => 'singular',
		'css_fallback'       => 1,
		'block_meta_cleanup' => 1,
		'global'             => array_fill_keys( hideev_get_element_keys(), 0 ),
		'post_types'         => array(),
	);
}

/**
 * Saved settings merged with defaults.
 *
 * @return array
 */
function hideev_get_settings() {
	$defaults = hideev_default_settings();
	$saved    = get_option( 'hideev_settings', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}

	$settings = wp_parse_args( $saved, $defaults );

	$settings['global'] = wp_parse_args(
		is_array( $settings['global'] ) ? $settings['global'] : array(),
		$defaults['global']
	);

	if ( ! is_array( $settings['post_types'] ) ) {
		$settings['post_types'] = array();
	}

	return $settings;
}

/**
 * Effective default (before any per-post override) for each element of a post type.
 *
 * @param string $post_type Post type name.
 * @return array<string,bool> Element key => hidden by default.
 */
function hideev_get_type_defaults( $post_type ) {
	$settings      = hideev_get_settings();
	$type_settings = array();
	if ( isset( $settings['post_types'][ $post_type ] ) && is_array( $settings['post_types'][ $post_type ] ) ) {
		$type_settings = $settings['post_types'][ $post_type ];
	}

	$result = array();
	foreach ( hideev_get_element_keys() as $element ) {
		$value = isset( $type_settings[ $element ] ) ? hideev_sanitize_toggle( $type_settings[ $element ] ) : '';
		if ( '' === $value ) {
			$value = empty( $settings['global'][ $element ] ) ? '0' : '1';
		}
		$result[ $element ] = ( '1' === $value );
	}

	return $result;
}

/**
 * Resolve which elements are hidden for a post.
 *
 * Order of precedence: per-post toggle > post type default > global default.
 *
 * @param int $post_id Post ID.
 * @return array<string,bool> Element key => hidden.
 */
function hideev_get_hidden_elements( $post_id ) {
	static $cache = array();

	$post_id = (int) $post_id;
	if ( isset( $cache[ $post_id ] ) ) {
		return $cache[ $post_id ];
	}

	$result    = array_fill_keys( hideev_get_element_keys(), false );
	$post_type = $post_id > 0 ? get_post_type( $post_id ) : false;

	if ( $post_type && in_array( $post_type, hideev_get_supported_post_types(), true ) ) {
		$defaults = hideev_get_type_defaults( $post_type );
		foreach ( hideev_get_element_keys() as $element ) {
			$value = hideev_sanitize_toggle( get_post_meta( $post_id, hideev_meta_key( $element ), true ) );
			if ( '' === $value ) {
				$result[ $element ] = $defaults[ $element ];
			} else {
				$result[ $element ] = ( '1' === $value );
			}
		}
	}

	$cache[ $post_id ] = $result;
	return $result;
}

/**
 * Whether we are rendering a front-end request where hiding should apply
 * to the given post.
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function hideev_is_front_context( $post_id ) {
	if ( is_admin() || ! did_action( 'wp' ) ) {
		return false;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return false;
	}
	if ( is_feed() || is_embed() ) {
		return false;
	}

	$settings = hideev_get_settings();
	if ( 'everywhere' === $settings['scope'] ) {
		return true;
	}

	return is_singular() && (int) get_queried_object_id() === (int) $post_id;
}

/**
 * Whether an element of a post should be hidden in the current request.
 *
 * @param string $element Element key.
 * @param int    $post_id Post ID.
 * @return bool
 */
function hideev_should_hide( $element, $post_id ) {
	$post_id = (int) $post_id;
	$hide    = false;

	if ( $post_id > 0 && hideev_is_front_context( $post_id ) ) {
		$hidden = hideev_get_hidden_elements( $post_id );
		$hide   = ! empty( $hidden[ $element ] );
	}

	/**
	 * Filters whether an element is hidden for a post.
	 *
	 * @param bool   $hide    Whether to hide the element.
	 * @param string $element Element key (title, featured_image, author, date, terms).
	 * @param int    $post_id Post ID.
	 */
	return (bool) apply_filters( 'hideev_should_hide', $hide, $element, $post_id );
}

/**
 * Whether any element of a post is hidden in the current request.
 *
 * @param int $post_id Post ID.
 * @return bool
 */
function hideev_post_has_hidden_elements( $post_id ) {
	foreach ( hideev_get_element_keys() as $element ) {
		if ( hideev_should_hide( $element, $post_id ) ) {
			return true;
		}
	}
	return false;
}
