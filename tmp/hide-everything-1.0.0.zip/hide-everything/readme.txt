=== Hide Everything ===
Contributors: siljeonai
Tags: hide title, featured image, hide author, hide date, block theme
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Hide the title, featured image, author, date and categories/tags on any post or page. Works with classic and block themes.

== Description ==

Sometimes a page should not look like a blog post: a landing page without a big title, a "Contact" page without a date, a post without the author line. Hide Everything adds simple per-post switches for that.

**What you can hide, per post or page**

* Title
* Featured image
* Author
* Date (published and modified)
* Categories, tags and other terms

**How it works**

* Each element has three choices in the editor: *Default* (shown as "Default (shown)" or "Default (hidden)" depending on your site-wide setting), *Hide* or *Show*.
* *Default* follows Settings > Hide Everything, where you set what is hidden for all content types at once or for each content type (posts, pages, custom post types).
* Hidden elements are removed on the server, not just covered with CSS, so the text is not left in the page for screen readers or copy-and-paste.
* Block themes (Full Site Editing): the Post Title, Post Featured Image, Post Author, Post Author Name, Post Author Biography, Avatar (post author), Post Date and Post Terms blocks are removed for that post. Small groups left holding only words such as "by" or "in" are removed too (can be turned off).
* Classic themes: the standard template tags (the_title, the_post_thumbnail, the_author, get_the_date, the_category, the_tags and friends) return nothing for hidden elements. An optional tiny stylesheet hides leftover labels such as "Posted on" that some themes print around them.
* By default hiding applies only on the single post or page view, so blog lists and archives keep their links. You can switch this to "everywhere".

**Editor support**

* Block editor: a "Hide Everything" panel in the post sidebar.
* Classic editor: a "Hide Everything" box in the sidebar.

**Privacy**

Hide Everything does not call any external service, does not track anything and does not set cookies.

**For developers**

* `hideev_should_hide` filter: `( bool $hide, string $element, int $post_id )`.
* `hideev_supported_post_types` filter: change which post types get the switches.
* `hideev_block_map` filter: map extra block names to an element.
* Post meta keys: `_hideev_hide_title`, `_hideev_hide_featured_image`, `_hideev_hide_author`, `_hideev_hide_date`, `_hideev_hide_terms` with values `''` (default), `'1'` (hide) or `'0'` (show).

== Installation ==

1. Upload the `hide-everything` folder to `/wp-content/plugins/`, or install it from Plugins > Add New.
2. Activate the plugin.
3. Optional: set site-wide defaults in Settings > Hide Everything.
4. Open any post or page and use the "Hide Everything" panel in the sidebar.

== Frequently Asked Questions ==

= Does it work with my theme? =

It works with themes that use WordPress's own template tags (classic themes) or core blocks (block themes). Page builders and themes that print the title or date with their own code may ignore the setting. In that case please open a support topic with the theme name.

= Is the title removed from the browser tab and search results? =

No. Only the visible heading on the page is removed. The document title (browser tab), feeds and the REST API keep the real title, so SEO plugins and feed readers are not affected.

= Hidden elements still show up after I change a setting. =

If you use a page cache plugin or a CDN, clear the cache after changing site-wide defaults. Saving a single post usually clears that post's cache automatically.

= What happens when I delete the plugin? =

Deleting the plugin from the Plugins screen removes its settings and all per-post switches (on every site of a multisite network). Your posts themselves are not changed.

== Screenshots ==

1. The Hide Everything panel in the block editor sidebar.
2. Settings > Hide Everything with defaults per content type.

== Changelog ==

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.0.0 =
First release.
