// ===== 여기 1줄만 내 값으로 바꿉니다 (따옴표 안만) =====
const BOT_TOKEN = "여기에_토큰_붙여넣기";   // Day 2 메모의 토큰 (숫자:영문 긴 문자열)
// ======================================================

function 출근확인() {
  if (!/^\d{6,}:[A-Za-z0-9_-]{30,}$/.test(BOT_TOKEN)) { Logger.log("① 토큰 모양이 이상해요. Day 2 메모의 토큰(숫자:영문 긴 문자열)을 따옴표 안에 그대로 붙여넣으세요."); return; }

  const api = "https://api.telegram.org/bot" + BOT_TOKEN;
  const me = UrlFetchApp.fetch(api + "/getMe", { muteHttpExceptions: true });
  if (me.getResponseCode() !== 200) { Logger.log("① 토큰이 틀렸어요. BotFather → /mybots → API Token 에서 다시 복사하세요."); return; }

  // 사장님이 보고팀에 보낸 "/start@내직원아이디" 를 찾아서, 그 방(그룹 번호·부서 번호)을 알아냅니다
  const upd = JSON.parse(UrlFetchApp.fetch(api + "/getUpdates?limit=100", { muteHttpExceptions: true }).getContentText());
  const msgs = (upd.result || []).map(u => u.message).filter(m => m && m.chat && m.text && m.text.indexOf("/start") === 0 && m.chat.type !== "private");
  if (!msgs.length) { Logger.log("② 텔레그램 → 우리 회사 → 보고팀에 /start@내직원아이디 (예: /start@siljeonai_report_bot) 를 먼저 보내고, 30초 뒤 다시 실행하세요. /start 만 보내면 직원이 못 받습니다."); return; }

  const last = msgs[msgs.length - 1];
  const chatId = last.chat.id;
  const topicId = last.message_thread_id || null;

  const now = new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" });
  const body = { chat_id: chatId, text: "✅ 출근했습니다! 보고팀 김대리입니다. 앞으로 여기서 보고드리겠습니다. (" + now + ")" };
  if (topicId) body.message_thread_id = topicId;
  const res = JSON.parse(UrlFetchApp.fetch(api + "/sendMessage", { method: "post", contentType: "application/json", payload: JSON.stringify(body), muteHttpExceptions: true }).getContentText());
  if (!res.ok) { Logger.log("알 수 없는 오류: " + res.description + " — 이 줄을 그대로 복사해서 문의해 주세요."); return; }

  Logger.log("✅ 성공! 텔레그램 우리 회사 → 보고팀을 확인하세요.");
  Logger.log("📝 아래 두 줄을 Day 2 메모에 적어 두세요 (Day 6부터 씁니다)");
  Logger.log("그룹 번호: " + chatId);
  Logger.log("부서 번호(보고팀): " + (topicId || "없음"));
}
