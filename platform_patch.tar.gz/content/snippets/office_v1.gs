// ===== 여기 3줄만 내 값으로 바꿉니다 (따옴표 안만) =====
const BOT_TOKEN  = "여기에_토큰_붙여넣기";      // Day 2 메모의 토큰
const GEMINI_KEY = "여기에_Gemini키_붙여넣기";  // Day 5 메모의 Gemini 키 (없으면 빈칸 "" 도 됩니다)
const SHEET_URL  = "여기에_시트주소_붙여넣기";   // Day 3 메모의 우리 회사 정보 시트 주소
// ======================================================
// ▼ 아래는 건드리지 않습니다. "우리 회사 사무실 프로그램" v1 (2026-09-12)
//   부서방 이름으로 일을 나눕니다: 보고팀 / 고객응대팀 / 콘텐츠팀 / 인사팀 / 시장조사팀 / 광고팀 / 정산팀

const API = "https://api.telegram.org/bot" + BOT_TOKEN;
const 저장소 = PropertiesService.getScriptProperties();

// ---------- 처음 한 번: 설치 (Day 7) ----------
function 설치() {
  탭준비();
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));
  const 설정 = 설정읽기();
  ScriptApp.newTrigger("아침보고").timeBased().atHour(Number(설정["보고 시각"] || 8)).everyDays(1).inTimezone("Asia/Seoul").create();
  ScriptApp.newTrigger("직원업무").timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger("주간요약").timeBased().onWeekDay(ScriptApp.WeekDay.FRIDAY).atHour(17).inTimezone("Asia/Seoul").create();
  Logger.log("✅ 설치 완료: 매일 " + (설정["보고 시각"] || 8) + "시 아침 보고 · 5분마다 부서 업무 · 금요일 17시 주간 요약");
  Logger.log("→ 왼쪽 시계 모양(트리거)을 누르면 3줄이 보입니다.");
}

// ---------- 매일 아침: 보고 (Day 6) ----------
function 아침보고() {
  const 방 = 방찾기("보고팀");
  if (!방) { Logger.log("② 보고팀 방을 아직 몰라요. 텔레그램 보고팀에 /start@내직원아이디 를 보내고 다시 실행하세요."); return; }
  const 정보 = 회사정보(); const 설정 = 설정읽기();
  const 오늘 = new Date(); const 날짜 = Utilities.formatDate(오늘, "Asia/Seoul", "M월 d일 (E)");
  const 어제결재 = 최근행("결재", 5).map(r => "- " + r[2]).join("\n") || "- (없음)";
  const 할일 = (정보["매일 반복하는 일 3개"] || "문의 답장, 재고 확인, SNS 올리기").split(/[,，/·]/).map(s => s.trim()).filter(Boolean).slice(0, 3);
  let 글 = 두뇌("너는 아래 가게의 AI 직원 '보고팀 김대리'다. 오늘 아침 보고를 써라. 형식: 첫 줄 '☀️ " + 날짜 + " 아침 보고', 둘째 줄 " + (설정["호칭"] || 정보["사장님을 부르는 호칭"] || "사장님") + "께 한 줄 인사, 그 다음 '오늘 할 일' 번호 1~3 (아래 반복 업무 기준, 각 줄 끝에 짧은 팁 한 마디), 마지막 줄 '답장으로 결재해 주세요: 1 완료 / 2 보류 처럼'. 말투: " + (설정["말투"] || 정보["AI 직원에게 바라는 말투"] || "짧고 공손하게") + ". 10줄 이내.\n[가게 정보]\n" + 정보문장(정보) + "\n[반복 업무]\n" + 할일.join("\n") + "\n[어제 결재 기록]\n" + 어제결재);
  if (!글) 글 = "☀️ " + 날짜 + " 아침 보고\n" + (설정["호칭"] || "사장님") + ", 좋은 아침입니다. 오늘 할 일입니다.\n" + 할일.map((h, i) => (i + 1) + ". " + h).join("\n") + "\n답장으로 결재해 주세요: 1 완료 / 2 보류 처럼";
  const 보낸것 = 보내기(방.chat, 방.thread, 글);
  기록("보고기록", [지금(), "아침보고", 글, 보낸것 && 보낸것.message_id]);
  Logger.log("✅ 아침 보고를 보고팀에 올렸습니다.");
}

// ---------- 5분마다: 부서방 새 글 처리 (Day 8~19) ----------
function 직원업무() {
  const offset = Number(저장소.getProperty("offset") || 0);
  const upd = JSON.parse(UrlFetchApp.fetch(API + "/getUpdates?timeout=0&limit=100&offset=" + offset, { muteHttpExceptions: true }).getContentText());
  let last = offset - 1;
  for (const u of (upd.result || [])) {
    last = u.update_id;
    const m = u.message; if (!m || !m.chat || m.chat.type === "private" || !m.text) continue;
    if (m.from && m.from.is_bot) continue;
    const 부서 = 부서이름(m);
    방저장(부서, m.chat.id, m.message_thread_id || null);
    try { 처리(부서, m); } catch (e) { 보내기(m.chat.id, m.message_thread_id, "⚠️ 처리 중 문제: " + e.message.slice(0, 120)); }
  }
  저장소.setProperty("offset", String(last + 1));
}

function 처리(부서, m) {
  const t = m.text.trim();
  if (t.indexOf("/start") === 0) { 보내기(m.chat.id, m.message_thread_id, "✅ " + 부서 + " 방을 기억했습니다."); return; }
  const 답 = (글) => 보내기(m.chat.id, m.message_thread_id, 글);
  const 정보 = 회사정보(); const 설정 = 설정읽기();
  const 말투 = "말투: " + (설정["말투"] || 정보["AI 직원에게 바라는 말투"] || "짧고 공손하게, 존댓말") + ". 호칭: " + (설정["호칭"] || 정보["사장님을 부르는 호칭"] || "사장님") + ".";

  if (부서 === "보고팀") {                                   // Day 8: 답장 = 결재
    if (!(m.reply_to_message && m.reply_to_message.from && m.reply_to_message.from.is_bot)) return;
    기록("결재", [지금(), (m.reply_to_message.text || "").split("\n")[0], t]);
    답("📝 결재 기록했습니다: " + t);
  } else if (부서 === "고객응대팀") {                        // Day 9
    const r = 두뇌("손님 문의에 대한 답변 초안을 3개 써라(①짧게 ②친절하게 ③단골 만들기). 각 3줄 이내. 가게 정보에 없는 것은 지어내지 말고 '확인 후 안내'라고 써라. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[손님 문의]\n" + t) || "(Gemini 키가 없어 초안을 못 씁니다. Day 5를 확인하세요)";
    기록("문의", [지금(), t, r]); 답(r);
  } else if (부서 === "콘텐츠팀") {                          // Day 11~13
    if (/올렸|게시 완료|업로드/.test(t)) { 기록("게시", [지금(), t]); 답("📌 게시 완료로 기록했습니다. 수고하셨습니다!"); return; }
    if (/카드뉴스|문구/.test(t)) {
      const r = 두뇌("아래 소재로 인스타 카드뉴스 문구를 써라: 표지 제목(10자 내) 1개, 본문 슬라이드 4장(각 2줄), 마지막 슬라이드 행동 유도 1줄. 해시태그 5개. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[소재]\n" + t) || "(Gemini 키 필요)";
      기록("소재", [지금(), "카드뉴스", t, r]); 답(r); return;
    }
    const r = 두뇌("이 가게의 이번 주 SNS 소재 10개를 표처럼 써라. 각 줄: 번호. 제목(15자 내) — 왜 손님이 반응할지 한 마디. 손님이 자주 묻는 질문·요즘 고민·계절을 섞어라. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[사장님 요청]\n" + t) || "(Gemini 키 필요)";
    기록("소재", [지금(), "소재10", t, r]); 답(r);
  } else if (부서 === "인사팀") {                            // Day 14
    const r = 두뇌("사장님이 남긴 메모를 한 줄로 정리하고(핵심만), 분류를 하나 붙여라: 아이디어/불만/칭찬/할일/기타. 형식: '분류 | 한 줄'. " + 말투 + "\n[메모]\n" + t) || "기타 | " + t;
    기록("메모", [지금(), t, r]); 답("🗂 기록했습니다 → " + r);
  } else if (부서 === "시장조사팀") {                        // Day 17
    const 링크 = t.match(/https?:\/\/\S+/g) || [];
    if (!링크.length) { 답("경쟁 가게의 블로그·홈페이지·플레이스 주소를 붙여 주세요 (1~3개). 인스타그램은 로그인 벽 때문에 못 읽습니다."); return; }
    const 본문 = 링크.slice(0, 3).map(u => { try { return u + "\n" + 본문추출(UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true }).getContentText()).slice(0, 3000); } catch (e) { return u + "\n(못 읽음: " + e.message + ")"; } }).join("\n\n");
    const r = 두뇌("아래는 경쟁 가게 페이지 내용이다. 표처럼 정리하라: 가게별로 ①요즘 미는 상품/이벤트 ②가격 신호 ③우리가 바로 따라 할 것 1개 ④우리가 다르게 갈 것 1개. 페이지에 없는 건 '없음'. " + 말투 + "\n[우리 가게]\n" + 정보문장(정보) + "\n[경쟁 페이지]\n" + 본문) || "(Gemini 키 필요)";
    기록("조사", [지금(), 링크.join(" "), r]); 답(r);
  } else if (부서 === "광고팀") {                            // Day 18
    const r = 두뇌("사장님이 붙여넣은 광고 숫자(어제/오늘)를 해석하라. 형식: '한 줄 해석' 1줄, '좋은 신호' 1줄, '걱정 신호' 1줄, '오늘 할 것 1개' 1줄. 숫자에 없는 건 추측하지 마라. 용어는 쉬운 말로. " + 말투 + "\n[가게 정보]\n" + 정보문장(정보) + "\n[광고 숫자]\n" + t) || "(Gemini 키 필요)";
    기록("광고", [지금(), t, r]); 답(r);
  } else if (부서 === "정산팀") {                            // Day 19 (AI 없이 동작)
    const 매출 = 숫자(t, /매출\s*([\d,.]+)\s*(만)?/); const 지출 = 숫자(t, /지출\s*([\d,.]+)\s*(만)?/);
    if (매출 === null && 지출 === null) { 답("이렇게 보내 주세요: 매출 32만 지출 8만 (메모는 뒤에 자유롭게)"); return; }
    기록("정산", [지금(), 매출 || 0, 지출 || 0, (매출 || 0) - (지출 || 0), t]);
    const 달 = 이번달합계();
    답("💰 기록했습니다. 오늘 매출 " + 원(매출) + " · 지출 " + 원(지출) + " · 남는 돈 " + 원((매출 || 0) - (지출 || 0)) + "\n이번 달 누적: 매출 " + 원(달.매출) + " · 지출 " + 원(달.지출) + " · 남는 돈 " + 원(달.매출 - 달.지출));
  }
}

// ---------- 금요일: 주간 요약 (Day 15) ----------
function 주간요약() {
  const 방 = 방찾기("보고팀"); if (!방) return;
  const 모음 = ["결재", "문의", "게시", "메모", "정산"].map(탭 => "[" + 탭 + " 최근]\n" + 최근행(탭, 15).map(r => r.slice(0, 4).join(" | ")).join("\n")).join("\n\n");
  const 글 = 두뇌("이번 주 우리 회사 기록을 보고 사장님께 주간 요약을 써라: ①이번 주 숫자(결재 몇 건, 문의 몇 건, 게시 몇 건, 매출·지출 합계) ②잘한 것 2개 ③다음 주 제안 2개. 8줄 이내. " + "\n" + 모음) || ("📊 주간 기록\n" + 모음.slice(0, 1500));
  보내기(방.chat, 방.thread, "📊 주간 요약\n" + 글); 기록("보고기록", [지금(), "주간요약", 글]);
}

// ---------- 도구들 ----------
function 두뇌(질문) {
  if (!GEMINI_KEY || GEMINI_KEY.indexOf("여기에") === 0) return null;
  const res = UrlFetchApp.fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + GEMINI_KEY,
    { method: "post", contentType: "application/json", payload: JSON.stringify({ contents: [{ parts: [{ text: 질문 }] }] }), muteHttpExceptions: true });
  const json = JSON.parse(res.getContentText());
  if (!json.candidates) throw new Error("Gemini 키 문제: " + ((json.error && json.error.message) || "").slice(0, 100));
  return json.candidates[0].content.parts.map(p => p.text).join("").trim();
}
function 보내기(chat, thread, 글) {
  const body = { chat_id: chat, text: String(글).slice(0, 4000) }; if (thread) body.message_thread_id = thread;
  const r = JSON.parse(UrlFetchApp.fetch(API + "/sendMessage", { method: "post", contentType: "application/json", payload: JSON.stringify(body), muteHttpExceptions: true }).getContentText());
  return r.ok ? r.result : null;
}
function 부서이름(m) {
  const r = m.reply_to_message; if (r && r.forum_topic_created) return r.forum_topic_created.name.replace(/\s/g, "");
  if (m.forum_topic_created) return m.forum_topic_created.name.replace(/\s/g, "");
  return m.message_thread_id ? (저장소.getProperty("이름:" + m.message_thread_id) || "General") : "General";
}
function 방저장(부서, chat, thread) { 저장소.setProperty("방:" + 부서, JSON.stringify({ chat: chat, thread: thread })); if (thread) 저장소.setProperty("이름:" + thread, 부서); }
function 방찾기(부서) { const s = 저장소.getProperty("방:" + 부서); return s ? JSON.parse(s) : null; }
function 시트() { return SpreadsheetApp.openByUrl(SHEET_URL); }
function 회사정보() { const o = {}; 시트().getSheets()[0].getRange("A2:B12").getValues().forEach(r => { if (r[0]) o[String(r[0]).trim()] = String(r[1] || "").trim(); }); return o; }
function 정보문장(정보) { return Object.keys(정보).map(k => k + ": " + (정보[k] || "(비어 있음)")).join("\n"); }
function 설정읽기() { const o = {}; const s = 시트().getSheetByName("설정"); if (s) s.getRange("A2:B10").getValues().forEach(r => { if (r[0]) o[String(r[0]).trim()] = String(r[1] || "").trim(); }); return o; }
function 탭준비() {
  const ss = 시트();
  const 틀 = { "설정": ["항목", "값"], "보고기록": ["시각", "종류", "내용", "메시지번호"], "결재": ["시각", "보고 제목", "사장님 답장"], "문의": ["시각", "손님 문의", "답변 초안"], "소재": ["시각", "종류", "요청", "결과"], "게시": ["시각", "내용"], "메모": ["시각", "원문", "정리"], "조사": ["시각", "링크", "결과"], "광고": ["시각", "숫자", "해석"], "정산": ["시각", "매출", "지출", "남는 돈", "원문"] };
  Object.keys(틀).forEach(이름 => { let s = ss.getSheetByName(이름); if (!s) { s = ss.insertSheet(이름); s.appendRow(틀[이름]); s.getRange(1, 1, 1, 틀[이름].length).setFontWeight("bold"); } });
  const 설 = ss.getSheetByName("설정"); if (설.getLastRow() < 2) { 설.getRange("A2:B4").setValues([["보고 시각", "8"], ["말투", "짧고 공손하게, 존댓말"], ["호칭", "사장님"]]); }
}
function 기록(탭, 행) { let s = 시트().getSheetByName(탭); if (!s) { 탭준비(); s = 시트().getSheetByName(탭); } s.appendRow(행); }
function 최근행(탭, n) { const s = 시트().getSheetByName(탭); if (!s || s.getLastRow() < 2) return []; const from = Math.max(2, s.getLastRow() - n + 1); return s.getRange(from, 1, s.getLastRow() - from + 1, s.getLastColumn()).getValues(); }
function 지금() { return Utilities.formatDate(new Date(), "Asia/Seoul", "yyyy-MM-dd HH:mm"); }
function 숫자(t, re) { const m = t.match(re); if (!m) return null; let v = Number(m[1].replace(/,/g, "")); if (m[2]) v *= 10000; return v; }
function 원(v) { return (Number(v) || 0).toLocaleString("ko-KR") + "원"; }
function 이번달합계() { const 달 = Utilities.formatDate(new Date(), "Asia/Seoul", "yyyy-MM"); let 매출 = 0, 지출 = 0; 최근행("정산", 200).forEach(r => { if (String(r[0]).indexOf(달) === 0) { 매출 += Number(r[1]) || 0; 지출 += Number(r[2]) || 0; } }); return { 매출, 지출 }; }
function 본문추출(html) { return String(html).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim(); }
