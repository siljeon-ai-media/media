# Day 5 — 직원에게 두뇌 달기: Gemini 키 + 첫 자기소개

> **오늘 만드는 것**: 직원이 **우리 회사 정보(Day 3 시트)를 읽고, 보고팀에 자기소개**를 올리는 것. 오늘부터 직원이 "생각"을 합니다.
> **걸리는 시간**: 약 25분
> **필요한 것**: 컴퓨터(크롬) + Day 2 메모(토큰·시트 주소) + Day 4에서 만든 Apps Script

> ✅ 2026-09-13 운영자 실제 화면으로 확정 (3단계 코드 화면·권한 팝업 캡처만 개강 전 추가).

## 오늘 할 일 3가지
1. 구글 **AI Studio**에서 **Gemini 키**(직원의 두뇌 사용권, 무료)를 받아 메모에 적습니다.
2. Day 4의 Apps Script 코드를 새 코드로 바꾸고, **값 3줄**(토큰·Gemini 키·시트 주소)을 채웁니다.
3. `자기소개`를 실행 → 보고팀에 직원이 우리 가게에 맞춘 자기소개를 올리면 끝.

> Gemini가 뭔가요? 구글이 만든 AI(챗GPT 같은 것)입니다. 이 과정에서는 직원의 "두뇌"로 씁니다. 개인 사용 범위에서는 **무료**입니다(하루 사용량 제한 있음 — 우리 직원 업무량으로는 충분합니다. 정확한 한도는 개강 전 다시 확인해 드립니다).

## 순서

### 1단계 · AI Studio 열고 약관 동의 (3분)
크롬 주소창에 아래 주소를 넣고 엔터. (Day 3·4의 구글 계정으로.)

```text
aistudio.google.com/apikey
```

![처음 열면 나오는 환영 창 — 첫 번째 체크 ① → 계속 ②](/public/guide/d05p-01.jpg)

처음이면 "AI Studio에 오신 것을 환영합니다" 창이 뜹니다. **첫 번째 네모 ①**(별표 붙은 것, 필수)에 체크하고 **"계속" ②**을 누릅니다. 두 번째(이메일 소식 받기)는 안 해도 됩니다.

### 2단계 · Gemini 키 만들기 (5분)
"API 키" 화면이 열립니다. 처음이라 목록이 비어 있습니다.

![API 키 화면 — 오른쪽 위 "API 키 만들기" ①](/public/guide/d05p-02.jpg)

오른쪽 위 **"API 키 만들기" ①**을 눌러 보면 "가져온 프로젝트 선택" 칸에 **No Cloud Projects Available**(고를 프로젝트가 없음)이라고 나옵니다. 키를 담을 **"프로젝트"(서류함)를 먼저 하나 만들어야** 합니다. **취소**를 누르고 아래로.

![왼쪽 "프로젝트" ① → 오른쪽 위 "새 프로젝트 만들기" ②](/public/guide/d05p-03.jpg)

왼쪽 메뉴의 **"프로젝트" ①**을 누른 뒤 오른쪽 위 **"+ 새 프로젝트 만들기" ②**.

![이름 칸 ① → "프로젝트 만들기" ②](/public/guide/d05p-04.jpg)

이름 칸 ①에 처음 들어 있는 "Gemini 프로젝트"를 지우고 **영문으로** `AI staff`라고 적습니다(한글이 섞이면 빨간 글씨로 거절됩니다 — 영문·숫자·공백만 됩니다). **"프로젝트 만들기" ②**.

![프로젝트가 골라진 "새 키 만들기" 창 — ① 확인 → "키 만들기" ②](/public/guide/d05p-05.jpg)

프로젝트가 만들어지면 **"새 키 만들기" 창이 저절로** 뜹니다. "가져온 프로젝트 선택" 칸 ①에 방금 만든 **AI staff**가 들어 있는지 보고 **"키 만들기" ②**. (창이 안 뜨면 왼쪽 "API 키" → "API 키 만들기"를 다시 누르면 이번엔 AI staff가 골라져 있습니다.)

![키 목록 — 키 이름 ① 클릭](/public/guide/d05p-06.jpg)

왼쪽 **"API 키"** 화면으로 돌아오면 목록에 키가 한 줄 생겼습니다(끝 네 글자만 보입니다). 그 **키 이름 ①**을 누릅니다.

![키 세부정보 — "키 복사" ① (키 부분은 이 책에서 가렸습니다)](/public/guide/d05p-07.jpg)

"API 키 세부정보" 창의 아래 **"키 복사" ①**을 누르면 긴 영문 문자열(`AQ.`로 시작, 예전 계정은 `AIza`로 시작)이 복사됩니다. Day 2 메모에 붙입니다.

```text
Gemini 키: [여기에 붙여넣기]
```

> 이 키도 토큰처럼 **비밀번호**입니다. 캡처·단톡방에 올리지 않습니다.
> "결제 등급: 무료 등급"이라고 보이면 정상입니다 — 카드 등록 없이 그대로 씁니다.

### 3단계 · 새 코드로 바꾸기 (8분)
Day 4에서 만든 Apps Script 프로젝트를 엽니다(script.google.com → 내 프로젝트 → 제목 없는 프로젝트). 코드 칸을 누르고 **Ctrl + A → Delete**로 전부 지운 뒤, 아래 상자를 **복사하기 → Ctrl + V**.

```javascript
// ===== 여기 3줄만 내 값으로 바꿉니다 (따옴표 안만) =====
const BOT_TOKEN  = "여기에_토큰_붙여넣기";      // Day 2 메모의 토큰
const GEMINI_KEY = "여기에_Gemini키_붙여넣기";  // Day 5 메모의 Gemini 키 (AQ.… 또는 AIza…)
const SHEET_URL  = "여기에_시트주소_붙여넣기";   // Day 3 메모의 우리 회사 정보 시트 주소
// ======================================================

// 우리 회사 정보 시트를 읽어서 한 덩어리 글로 만듭니다
function 회사정보() {
  const rows = SpreadsheetApp.openByUrl(SHEET_URL).getSheets()[0].getRange("A2:B10").getValues();
  return rows.filter(r => r[0]).map(r => r[0] + ": " + (r[1] || "(비어 있음)")).join("\n");
}

// Gemini(두뇌)에게 물어보고 답을 받습니다
function 두뇌(질문) {
  const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=" + GEMINI_KEY;
  const res = UrlFetchApp.fetch(url, { method: "post", contentType: "application/json", payload: JSON.stringify({ contents: [{ parts: [{ text: 질문 }] }] }), muteHttpExceptions: true });
  const json = JSON.parse(res.getContentText());
  if (!json.candidates) throw new Error("Gemini 키가 틀렸거나 아직 안 열렸어요: " + (json.error ? json.error.message : res.getContentText()).slice(0, 120));
  return json.candidates[0].content.parts.map(p => p.text).join("");
}

// 텔레그램 보고팀에 글을 올립니다 (Day 4에서 알아낸 방을 다시 찾습니다)
function 보고팀에(글) {
  const api = "https://api.telegram.org/bot" + BOT_TOKEN;
  const upd = JSON.parse(UrlFetchApp.fetch(api + "/getUpdates?limit=100", { muteHttpExceptions: true }).getContentText());
  const msgs = (upd.result || []).map(u => u.message).filter(m => m && m.chat && m.text && m.text.indexOf("/start") === 0 && m.chat.type !== "private");
  if (!msgs.length) throw new Error("보고팀에 /start@내직원아이디 를 먼저 보내세요 (Day 4 1단계)");
  const last = msgs[msgs.length - 1];
  const body = { chat_id: last.chat.id, text: 글 };
  if (last.message_thread_id) body.message_thread_id = last.message_thread_id;
  UrlFetchApp.fetch(api + "/sendMessage", { method: "post", contentType: "application/json", payload: JSON.stringify(body), muteHttpExceptions: true });
}

function 자기소개() {
  try {
    const 정보 = 회사정보();
    const 답 = 두뇌("너는 아래 가게의 '보고팀 김대리'라는 AI 직원이다. 사장님께 첫 출근 인사를 5줄 이내로 해라. 가게 이름과 손님 특징을 한 번씩 언급하고, '매일 반복하는 일' 중 하나를 골라 '이건 제가 맡겠습니다'라고 말해라. 사장님 호칭과 바라는 말투를 지켜라. 인사말만 출력해라.\n\n[가게 정보]\n" + 정보);
    보고팀에(답);
    Logger.log("✅ 성공! 보고팀에 자기소개가 올라갔습니다.");
  } catch (e) {
    Logger.log("❌ " + e.message);
    Logger.log("→ 시트 주소가 틀리면 '권한' 또는 'openByUrl' 오류, Gemini 키가 틀리면 'Gemini 키' 오류가 납니다. 그 줄만 고치고 다시 실행하세요.");
  }
}
```

2·3·4번 줄 따옴표 안을 각각 **토큰 / Gemini 키 / 시트 주소**로 바꿉니다. **Ctrl + S** 저장.

### 4단계 · 자기소개 실행 (5분)
Day 4를 어제 했다면, 텔레그램 **보고팀**에 `/start@내직원아이디`를 **한 번 더** 보냅니다(텔레그램은 하루가 지난 메시지를 직원에게 넘겨주지 않습니다). 그다음 도구 줄의 함수 칸(Day 4의 ⑦ 자리)을 눌러 **자기소개**를 고르고 **▶ 실행**. 이번엔 "구글 시트" 권한을 새로 묻는 창이 한 번 더 뜹니다 — Day 4와 똑같이 **고급 → 이동 → 모두 선택 체크 → 계속** (이번엔 항목이 2개: 스프레드시트 + 외부 서비스).

![실행 로그 — "✅ 성공!"이 보이면 됩니다](/public/guide/d05p-08.jpg)

![보고팀에 올라온 직원의 첫 자기소개 (운영자 화면, 가게 이름은 예시)](/public/guide/d05p-09.jpg)

> 이렇게 보이면 성공: 실행 로그에 `✅ 성공! 보고팀에 자기소개가 올라갔습니다.` 그리고 텔레그램 **보고팀**에 직원이 **우리 가게 이름을 넣어서** 쓴 인사가 올라옵니다. 매번 문장이 조금씩 다릅니다 — AI라서 그렇습니다. **이 화면이 오늘 제출할 캡처입니다.**

## 💡 조금 더 매끄럽게 (선택 · 유료)
이 과정은 **전부 무료 도구**로 끝까지 갑니다. 다만 아래는 "돈을 조금 쓰면 확실히 편해지는" 것들이라 알려만 드립니다. 안 사도 20일 완주에 지장 없습니다.
- **Claude 유료 키(쓴 만큼 과금, 1인 가게 기준 월 몇천 원~1만 원대 예상 — 확인 필요)**: Gemini 대신 Claude를 두뇌로 쓰면 한국어 글맛(문의 답변·SNS 글)이 더 자연스럽다는 평이 많습니다. 2주차 콘텐츠팀 미션 때 "Claude로 바꾸는 법"을 따로 드립니다.
- **Gemini 유료 등급**: 무료 한도(하루 요청 수)를 넘길 정도로 직원이 바빠지면 그때 켜면 됩니다. 1인 가게 기준으로는 1~2주차에 넘길 일이 거의 없습니다.

## 미션 체크리스트
- [ ] AI Studio 약관에 동의하고 Gemini 키를 메모에 적었다
- [ ] 새 코드를 붙여넣고 값 3줄을 바꿨다
- [ ] `자기소개` 실행 → 시트 권한 창에서 "모두 선택 → 계속"을 했다
- [ ] 보고팀에 우리 가게 이름이 들어간 자기소개가 올라왔다

## 제출할 캡처는 이 화면
보고팀에 올라온 **직원의 자기소개** 1장. (키·토큰이 보이는 코드 화면은 올리지 마세요.)

## 안 보이면 / 안 되면
| 이런 상황 | 이렇게 |
|---|---|
| 로그: `Gemini 키가 틀렸거나 아직 안 열렸어요` | 3번 줄 따옴표 안을 다시 봅니다(`AQ.` 또는 `AIza`로 시작, 앞뒤 공백 없이). 키를 방금 만들었다면 1~2분 뒤 다시 실행. |
| 로그: `You do not have permission to access the requested document` (문서 접근 권한 없음) | Day 3 사본이 **다른 구글 계정**에 만들어진 경우입니다(구글에 계정 두 개 이상 로그인돼 있으면 흔합니다 — 운영자도 겪었습니다). 시트를 열어 오른쪽 위 동그라미 계정이 Apps Script와 같은지 확인하고, 다르면 그 계정으로 Day 3 사본을 다시 만들어 4번 줄 주소를 바꿉니다. |
| 로그: `openByUrl` / `권한` / `찾을 수 없음` | 4번 줄 시트 주소가 Day 3 "링크 복사"로 복사한 것과 같은지 확인. 다른 구글 계정으로 로그인돼 있으면 시트가 안 열립니다 — Day 3과 같은 계정인지 확인. |
| 로그: `보고팀에 /start@내직원아이디 를 먼저 보내세요` | Day 4 1단계를 다시 합니다. |
| 프로젝트 만들기에서 `Failed to create project, The request is suspicious` | 구글이 "사람이 맞나" 의심한 것입니다. 창을 닫고 **1~2분 뒤 직접 마우스로** 다시 누르면 됩니다(운영자도 겪었습니다). 계속 그러면 단톡방에 캡처를 올려 주세요. |
| 자기소개가 영어로 왔어요 | 시트의 "AI 직원에게 바라는 말투" 칸에 "한국어 존댓말"을 적고 다시 실행. |
| 자기소개가 이상해요(엉뚱한 가게 이름 등) | 시트 "내용" 열이 비어 있으면 AI가 지어냅니다. Day 3 시트를 채우고 다시 실행. |

## 용어 한 줄
- **Gemini**: 구글의 AI. 우리 직원의 두뇌.
- **AI Studio**: Gemini 키를 발급받는 구글 사이트.
- **키(API 키)**: AI를 쓸 수 있는 사용권 번호. 비밀번호처럼 다룹니다.
- **함수**: 코드 안의 "업무 하나". `출근확인`, `자기소개`처럼 이름이 붙어 있고, 도구 줄에서 골라 실행합니다.
