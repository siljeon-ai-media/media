# Day 5 — 진단 스크립트로 "봇 → 부서 토픽" 첫 전송 성공하기

## 오늘 할 일
직원 봇이 우리 회사 **보고팀 토픽**에 메시지를 한 번 보내게 합니다. 값을 잘못 넣어도 스크립트가 **"어느 값이 틀렸는지 한국어로"** 알려주므로 겁내지 않아도 됩니다. PC의 크롬에서 진행하세요(폰 불가).

## 준비물 (값 3개)
| 값 | 어디서 구하나 | 모양 |
|---|---|---|
| 봇 토큰 | Day 2 메모 | `1234567890:AAH...` |
| 채팅 ID | 그룹을 PC 웹(web.telegram.org/a)에서 열면 주소창 끝 숫자. `-100`으로 시작하게 만듭니다. 예: 주소가 `#-1234567890`이면 채팅 ID는 `-1001234567890` | `-100...` 숫자 |
| 토픽 ID | 보고팀 토픽을 열었을 때 주소창 `_숫자` 부분 (`#-1234567890_2`면 `2`) | 숫자 |

## 순서
1. 크롬에서 `script.google.com` 접속 → **새 프로젝트**.
2. 편집창의 기존 내용을 모두 지우고 아래 코드를 **복사하기** 버튼으로 복사해 붙여넣습니다.
3. 맨 위 3줄의 따옴표 안만 내 값으로 바꿉니다. (토픽을 안 쓰는 일반 그룹이면 `TOPIC_ID`는 빈 따옴표 `""` 그대로)
4. 위쪽 함수 선택 상자에서 `diagnose`를 고르고 **실행(▶)**. 처음 한 번 "승인 필요" 창이 뜨면: **권한 검토 → 계정 선택 → 고급 → (프로젝트명)으로 이동(안전하지 않음) → 허용**. 3번 클릭이면 됩니다.
5. 아래 **실행 로그**에 `✅ 성공`이 뜨고, 텔레그램 보고팀 토픽에 메시지가 도착하면 끝.

```javascript
// ===== 여기 3줄만 내 값으로 바꾸세요 =====
const BOT_TOKEN = "여기에_봇토큰";          // Day 2에서 받은 긴 문자열
const CHAT_ID   = "여기에_채팅ID";          // 예: -1001234567890
const TOPIC_ID  = "여기에_토픽ID";          // 예: 2  (일반 그룹이면 "" 로 비우기)
// =========================================

function diagnose() {
  const 문제 = [];
  if (!/^\d{6,}:[A-Za-z0-9_-]{30,}$/.test(BOT_TOKEN)) 문제.push("① 봇 토큰 모양이 이상해요. BotFather가 준 값(숫자:영문숫자)을 그대로 붙여넣으세요.");
  if (!/^-?\d+$/.test(CHAT_ID)) 문제.push("② 채팅 ID는 숫자여야 해요. 그룹은 보통 -100으로 시작합니다.");
  if (TOPIC_ID !== "" && !/^\d+$/.test(TOPIC_ID)) 문제.push("③ 토픽 ID는 숫자여야 해요. 일반 그룹이면 빈칸(\"\")으로 두세요.");
  if (문제.length) { 문제.forEach(m => Logger.log(m)); return; }

  const api = "https://api.telegram.org/bot" + BOT_TOKEN;
  const me = UrlFetchApp.fetch(api + "/getMe", { muteHttpExceptions: true });
  if (me.getResponseCode() !== 200) { Logger.log("① 봇 토큰이 틀렸어요. BotFather → /mybots → API Token 을 다시 확인하세요."); return; }

  const body = { chat_id: CHAT_ID, text: "✅ 진단 성공! AI 직원 출근 준비가 끝났습니다. (" + new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" }) + ")" };
  if (TOPIC_ID !== "") body.message_thread_id = Number(TOPIC_ID);
  const res = UrlFetchApp.fetch(api + "/sendMessage", { method: "post", contentType: "application/json", payload: JSON.stringify(body), muteHttpExceptions: true });
  const json = JSON.parse(res.getContentText());
  if (json.ok) { Logger.log("✅ 성공! 텔레그램 보고팀 토픽을 확인하세요."); return; }

  const d = String(json.description || "");
  if (d.includes("chat not found")) Logger.log("② 채팅 ID가 틀렸어요. -100 으로 시작하는지, 숫자를 빠뜨리지 않았는지 확인하세요.");
  else if (d.includes("thread not found") || d.includes("TOPIC")) Logger.log("③ 토픽 ID가 틀렸어요. 보고팀 토픽 주소창의 _뒤 숫자를 다시 보세요.");
  else if (d.includes("not a member") || d.includes("Forbidden") || d.includes("kicked")) Logger.log("봇이 그룹에 없어요. Day 2처럼 그룹 멤버로 다시 초대하세요.");
  else Logger.log("알 수 없는 오류: " + d + " — 이 문장을 그대로 메모에 붙여 제출하세요.");
}
```

## 미션 체크리스트
- [ ] Apps Script 프로젝트를 만들고 코드를 붙여넣었다
- [ ] 값 3개를 교체했다 (토큰은 캡처에 안 보이게)
- [ ] 실행 로그에 `✅ 성공`이 떴다
- [ ] 보고팀 토픽에 메시지가 도착했다

## 제출물
캡처 2장: **① 토픽에 도착한 "진단 성공" 메시지** **② Apps Script 실행 로그**(토큰 줄은 가리기). 실패했다면 로그의 한국어 안내 문장과 함께 그대로 제출하세요 — 그것도 정상 제출입니다.
